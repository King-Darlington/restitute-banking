import { r as __toESM } from "../_runtime.mjs";
import { i as getServerFnById, r as createServerFn, s as __exportAll, t as TSS_SERVER_FUNCTION } from "./server-BLyHOJXt.mjs";
import { a as require_react, i as require_jsx_runtime, n as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, l as useRouterState, m as createFileRoute, p as lazyRouteComponent, s as Scripts, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/createSsrRpc-tIzqwCDr.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/settings.functions-BR3hZc6M.js
var getSiteSettings = createServerFn({ method: "GET" }).handler(createSsrRpc("631b4bee8a2790181206c8ff6bb48b151bfe33ae03068f166869bca5a3f5fcb1"));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-R_2ReNa2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-DB4o_B8W.css";
var DEFAULT_DURATION_MS = 2e3;
var FADE_MS = 300;
var particleStyles = [
	{
		top: "14%",
		left: "20%",
		size: "4px",
		delay: "0s",
		duration: "3.2s"
	},
	{
		top: "24%",
		left: "76%",
		size: "5px",
		delay: "0.15s",
		duration: "3.6s"
	},
	{
		top: "40%",
		left: "12%",
		size: "3px",
		delay: "0.3s",
		duration: "2.8s"
	},
	{
		top: "52%",
		left: "86%",
		size: "4px",
		delay: "0.45s",
		duration: "3.4s"
	},
	{
		top: "66%",
		left: "24%",
		size: "4px",
		delay: "0.6s",
		duration: "3s"
	},
	{
		top: "78%",
		left: "70%",
		size: "5px",
		delay: "0.75s",
		duration: "3.8s"
	},
	{
		top: "18%",
		left: "50%",
		size: "3px",
		delay: "0.9s",
		duration: "2.6s"
	},
	{
		top: "60%",
		left: "50%",
		size: "4px",
		delay: "1.05s",
		duration: "3.5s"
	}
];
function PageLoader({ durationMs = DEFAULT_DURATION_MS, onFinish }) {
	const [visible, setVisible] = (0, import_react.useState)(true);
	const [exiting, setExiting] = (0, import_react.useState)(false);
	const resolvedRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		let hideTimer;
		const resolve = () => {
			if (resolvedRef.current) return;
			resolvedRef.current = true;
			setExiting(true);
			hideTimer = window.setTimeout(() => {
				setVisible(false);
				if (onFinish) onFinish();
			}, FADE_MS);
		};
		const maxTimer = window.setTimeout(resolve, durationMs);
		if (document.readyState === "complete" || document.readyState === "interactive") {} else window.addEventListener("load", resolve, { once: true });
		return () => {
			window.clearTimeout(maxTimer);
			if (hideTimer !== void 0) window.clearTimeout(hideTimer);
			window.removeEventListener("load", resolve);
		};
	}, [durationMs, onFinish]);
	if (!visible) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `page-loader${exiting ? " page-loader--exit" : ""}`,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "page-loader__field",
				children: particleStyles.map(({ top, left, size, delay, duration }, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "page-loader__mote",
					style: {
						top,
						left,
						width: size,
						height: size,
						animationDelay: delay,
						animationDuration: duration
					}
				}, index))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "page-loader__stage",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "page-loader__spinner",
					"aria-hidden": "true",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "page-loader__comet page-loader__comet--a" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "page-loader__comet page-loader__comet--b" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "page-loader__core" })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "page-loader__wordmark",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "page-loader__wordmark-fill",
						children: "Restitute Banking"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "page-loader__wordmark-ghost",
						"aria-hidden": "true",
						children: "Restitute Banking"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: `
        .page-loader {
          position: fixed;
          inset: 0;
          z-index: 9999;
          display: flex;
          align-items: center;
          justify-content: center;
          background: radial-gradient(circle at 50% 42%, color-mix(in srgb, var(--primary) 16%, transparent) 0%, color-mix(in srgb, var(--ink) 38%, transparent) 70%);
          backdrop-filter: blur(6px) saturate(1.1);
          -webkit-backdrop-filter: blur(6px) saturate(1.1);
          opacity: 1;
          transition: opacity ${FADE_MS}ms ease, transform ${FADE_MS}ms ease, backdrop-filter ${FADE_MS}ms ease;
          pointer-events: none;
          overflow: hidden;
        }

        .page-loader--exit {
          opacity: 0;
          transform: scale(1.02);
          backdrop-filter: blur(0px) saturate(1);
          -webkit-backdrop-filter: blur(0px) saturate(1);
        }

        .page-loader__field {
          position: absolute;
          inset: 0;
        }

        .page-loader__mote {
          position: absolute;
          border-radius: 9999px;
          background: var(--action);
          opacity: 0;
          animation-name: page-loader-drift;
          animation-timing-function: ease-in-out;
          animation-iteration-count: infinite;
          filter: blur(0.5px);
        }

        .page-loader__stage {
          position: relative;
          z-index: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 1.6rem;
        }

        .page-loader__spinner {
          position: relative;
          width: 96px;
          height: 96px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .page-loader__comet {
          position: absolute;
          inset: 0;
          border-radius: 50%;
          -webkit-mask: radial-gradient(farthest-side, transparent calc(100% - 3px), #000 calc(100% - 3px));
          mask: radial-gradient(farthest-side, transparent calc(100% - 3px), #000 calc(100% - 3px));
          background: conic-gradient(from 0deg, transparent 0deg, var(--primary) 60deg, var(--action) 130deg, transparent 200deg);
          animation: page-loader-spin 1.1s linear infinite;
        }

        .page-loader__comet--b {
          inset: 16px;
          opacity: 0.55;
          animation-duration: 1.6s;
          animation-direction: reverse;
        }

        .page-loader__core {
          width: 22px;
          height: 22px;
          border-radius: 42% 58% 60% 40% / 48% 42% 58% 52%;
          background: radial-gradient(circle at 32% 28%, #fff, var(--action) 45%, var(--primary) 100%);
          box-shadow: 0 0 22px color-mix(in srgb, var(--action) 65%, transparent),
            0 0 44px color-mix(in srgb, var(--primary) 40%, transparent);
          animation: page-loader-breathe 1.1s ease-in-out infinite,
            page-loader-liquify 2.2s ease-in-out infinite;
        }

        .page-loader__wordmark {
          position: relative;
          font-family: var(--font-display);
          font-size: clamp(1.05rem, 2.2vw, 1.6rem);
          font-weight: 800;
          letter-spacing: 0.14em;
          text-transform: uppercase;
        }

        .page-loader__wordmark-ghost {
          color: color-mix(in srgb, var(--ink-foreground) 30%, transparent);
          text-shadow: 0 1px 12px rgba(0, 0, 0, 0.35);
        }

        .page-loader__wordmark-fill {
          position: absolute;
          inset: 0;
          overflow: hidden;
          white-space: nowrap;
          background: linear-gradient(90deg, var(--action), var(--primary));
          -webkit-background-clip: text;
          background-clip: text;
          color: transparent;
          filter: drop-shadow(0 1px 10px rgba(0, 0, 0, 0.25));
          animation: page-loader-reveal 1.1s cubic-bezier(0.65, 0, 0.35, 1) infinite;
        }

        @keyframes page-loader-spin {
          to { transform: rotate(360deg); }
        }

        @keyframes page-loader-breathe {
          0%, 100% { transform: scale(0.9); }
          50% { transform: scale(1.12); }
        }

        @keyframes page-loader-liquify {
          0%, 100% { border-radius: 42% 58% 60% 40% / 48% 42% 58% 52%; }
          33% { border-radius: 58% 42% 45% 55% / 55% 60% 40% 45%; }
          66% { border-radius: 48% 52% 55% 45% / 40% 48% 52% 60%; }
        }

        @keyframes page-loader-reveal {
          0% { clip-path: inset(0 100% 0 0); }
          45% { clip-path: inset(0 0 0 0); }
          80% { clip-path: inset(0 0 0 0); }
          100% { clip-path: inset(0 0 0 100%); }
        }

        @keyframes page-loader-drift {
          0% { opacity: 0; transform: translateY(0); }
          15% { opacity: 0.85; }
          85% { opacity: 0.85; }
          100% { opacity: 0; transform: translateY(-26px); }
        }

        @media (prefers-reduced-motion: reduce) {
          .page-loader__comet,
          .page-loader__core,
          .page-loader__wordmark-fill,
          .page-loader__mote {
            animation: none;
          }
          .page-loader__wordmark-fill {
            clip-path: inset(0 0 0 0);
          }
        }
      ` })
		]
	});
}
function SiteTransition({ routeKey, children }) {
	const [activeChildren, setActiveChildren] = (0, import_react.useState)(children);
	const [exitingChildren, setExitingChildren] = (0, import_react.useState)(null);
	const [isTransitioning, setIsTransitioning] = (0, import_react.useState)(false);
	const nextChildrenRef = (0, import_react.useRef)(null);
	const previousKey = (0, import_react.useRef)(routeKey);
	(0, import_react.useEffect)(() => {
		if (routeKey == null || routeKey === previousKey.current) return;
		nextChildrenRef.current = children;
		setExitingChildren(activeChildren);
		setIsTransitioning(true);
		previousKey.current = routeKey;
	}, [
		children,
		routeKey,
		activeChildren
	]);
	const handleLoaderFinish = () => {
		setActiveChildren(nextChildrenRef.current);
		setExitingChildren(null);
		setIsTransitioning(false);
		nextChildrenRef.current = null;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative isolate min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: `
        @keyframes rb-pulse { 0% { transform: scale(1); opacity: .9 } 50% { transform: scale(1.06); opacity: .6 } 100% { transform: scale(1); opacity: .9 } }
        @keyframes rb-float { 0% { transform: translateY(0) } 50% { transform: translateY(-12px) } 100% { transform: translateY(0) } }
        @keyframes rb-page-enter { 0% { opacity: 0; transform: translateY(18px); } 100% { opacity: 1; transform: translateY(0); } }
        @keyframes rb-page-exit { 0% { opacity: 1; transform: translateY(0); } 100% { opacity: 0; transform: translateY(-18px); } }
        .rb-shine { position: absolute; top: -50%; left: -50%; width: 200%; height: 200%; background-image: linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.12) 50%, rgba(255,255,255,0) 100%); transform: rotate(25deg); opacity: 0; transition: opacity .45s; }
        .rb-shine-visible { opacity: 1; animation: rb-float 3.5s ease-in-out infinite; }
        .rb-page-enter { animation: rb-page-enter 300ms ease both; }
        .rb-page-exit { animation: rb-page-exit 300ms ease both; }
      ` }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0 pointer-events-none overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute -right-24 -top-24 h-80 w-80 rounded-full blur-3xl",
						style: {
							background: "linear-gradient(135deg, rgba(59,130,246,0.22), rgba(168,85,247,0.18))",
							opacity: .16,
							animation: "rb-pulse 6s ease-in-out infinite"
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute left-8 top-1/4 w-56 h-56 rounded-full blur-2xl",
						style: {
							background: "linear-gradient(135deg, rgba(16,185,129,0.12), rgba(79,70,229,0.12))",
							animation: "rb-float 8s ease-in-out infinite"
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0",
						style: {
							background: "linear-gradient(180deg, rgba(255,255,255,0.02), rgba(0,0,0,0.04))",
							mixBlendMode: "overlay"
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rb-shine rb-shine-visible" })
				]
			}),
			exitingChildren ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 z-20 rb-page-exit",
				children: exitingChildren
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `${exitingChildren ? "z-10 rb-page-enter" : ""}`,
				children: activeChildren
			}),
			isTransitioning ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-auto absolute inset-0 z-40 flex items-center justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageLoader, {
					durationMs: 1200,
					onFinish: handleLoaderFinish
				})
			}) : null
		]
	});
}
var STORAGE_KEY = "rb-dark";
var ThemeContext = (0, import_react.createContext)(void 0);
function ThemeProvider({ children }) {
	const [dark, setDark] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined") return;
		try {
			const stored = localStorage.getItem(STORAGE_KEY);
			if (stored === "1") setDark(true);
			else if (stored === "0") setDark(false);
			else setDark(window.matchMedia?.("(prefers-color-scheme: dark)")?.matches ?? false);
		} catch {
			setDark(false);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		if (typeof document === "undefined") return;
		document.documentElement.classList.toggle("dark", dark);
		try {
			localStorage.setItem(STORAGE_KEY, dark ? "1" : "0");
		} catch {}
	}, [dark]);
	const toggleTheme = (0, import_react.useCallback)(() => {
		setDark((value) => !value);
	}, []);
	return (0, import_react.createElement)(ThemeContext.Provider, { value: {
		dark,
		toggleTheme
	} }, children);
}
function useTheme() {
	const context = (0, import_react.useContext)(ThemeContext);
	if (!context) throw new Error("useTheme must be used within a ThemeProvider");
	return context;
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$24 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Restitute Banking" },
			{
				name: "description",
				content: "Refund recovery and everyday banking, with live claim tracking and no upfront fees."
			},
			{
				name: "author",
				content: "Restitute Banking"
			},
			{
				name: "theme-color",
				content: "#0f2545"
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:site_name",
				content: "Restitute Banking"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.svg",
				type: "image/svg+xml"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("body", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ThemeProvider, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageLoader, {}),
			children,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] }) })]
	});
}
function RootComponent() {
	const { queryClient } = Route$24.useRouteContext();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteTransition, {
			routeKey: pathname,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {})]
	});
}
var $$splitComponentImporter$23 = () => import("./routes-DrDw9jCR.mjs");
var Route$23 = createFileRoute("/")({
	loader: () => getSiteSettings(),
	head: () => ({ meta: [
		{ title: "Restitute Banking | Refund Recovery & Everyday Banking" },
		{
			name: "description",
			content: "File a refund claim in five minutes, track every stage in real time and pay nothing until your money is returned. Banking built around recovery."
		},
		{
			property: "og:title",
			content: "Restitute Banking | Refund Recovery & Everyday Banking"
		},
		{
			property: "og:description",
			content: "Refund recovery with no upfront fees, live claim tracking and a named specialist on every file."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$23, "component")
});
var $$splitComponentImporter$22 = () => import("./about-DSgoNnod.mjs");
var Route$22 = createFileRoute("/about")({
	head: () => ({ meta: [
		{ title: "About Restitute Banking | Member-Owned Refund Recovery" },
		{
			name: "description",
			content: "Restitute Banking is member-owned and built around a recovery desk. Meet the people, the principles and the numbers behind the claims we win."
		},
		{
			property: "og:title",
			content: "About Restitute Banking"
		},
		{
			property: "og:description",
			content: "Member-owned banking with a dedicated refund recovery desk at its centre."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$22, "component")
});
var $$splitComponentImporter$21 = () => import("./admin-CzFfAKo1.mjs");
var Route$21 = createFileRoute("/admin")({
	head: () => ({ meta: [
		{ title: "Staff console — Restitute Banking" },
		{
			name: "description",
			content: "Restricted Restitute Banking back office for recovery staff."
		},
		{
			name: "robots",
			content: "noindex"
		},
		{
			property: "og:title",
			content: "Staff console — Restitute Banking"
		},
		{
			property: "og:description",
			content: "Restricted Restitute Banking back office."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$21, "component")
});
var $$splitComponentImporter$20 = () => import("./app-CX2kfI86.mjs");
var Route$20 = createFileRoute("/app")({
	head: () => ({ meta: [
		{ title: "Restitute Mobile App | Claims, Cards & Alerts" },
		{
			name: "description",
			content: "Track claims, freeze cards, message your specialist and get real-time alerts. The Restitute app puts the recovery desk in your pocket."
		},
		{
			property: "og:title",
			content: "Restitute Mobile App"
		},
		{
			property: "og:description",
			content: "Claim tracking, instant card controls and real-time alerts in one app."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$20, "component")
});
var $$splitComponentImporter$19 = () => import("./business-banking-VXesgXCe.mjs");
var Route$19 = createFileRoute("/business-banking")({
	head: () => ({ meta: [
		{ title: "Business Banking & Chargeback Defence | Restitute Banking" },
		{
			name: "description",
			content: "Merchant accounts with chargeback defence built in: automatic evidence packs, representment deadlines tracked and settlement reporting."
		},
		{
			property: "og:title",
			content: "Business Banking & Chargeback Defence"
		},
		{
			property: "og:description",
			content: "Merchant banking with automatic chargeback evidence packs and deadline tracking."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$19, "component")
});
var $$splitComponentImporter$18 = () => import("./cards-C7pU5bs0.mjs");
var Route$18 = createFileRoute("/cards")({
	head: () => ({ meta: [
		{ title: "Debit & Credit Cards with Dispute Controls | Restitute Banking" },
		{
			name: "description",
			content: "Cards with instant freeze, virtual numbers for risky merchants and a dispute button on every transaction — protection before the loss, not after."
		},
		{
			property: "og:title",
			content: "Cards with Dispute Controls"
		},
		{
			property: "og:description",
			content: "Instant freeze, virtual card numbers and one-tap disputes on every transaction."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./contact-Btj3shc2.mjs");
var Route$17 = createFileRoute("/contact")({
	head: () => ({ meta: [
		{ title: "Contact the Restitute recovery desk" },
		{
			name: "description",
			content: "Speak to a Restitute Banking recovery specialist by phone, email or secure message — seven days a week."
		},
		{
			property: "og:title",
			content: "Contact the Restitute recovery desk"
		},
		{
			property: "og:description",
			content: "Speak to a Restitute Banking recovery specialist by phone, email or secure message."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
var $$splitComponentImporter$16 = () => import("./dashboard-CDbw_0fe.mjs");
var Route$16 = createFileRoute("/dashboard")({
	head: () => ({ meta: [
		{ title: "Your recovery dashboard — Restitute Banking" },
		{
			name: "description",
			content: "Track every refund claim you have filed with Restitute Banking, see recovered amounts and message your specialist."
		},
		{
			name: "robots",
			content: "noindex"
		},
		{
			property: "og:title",
			content: "Your recovery dashboard — Restitute Banking"
		},
		{
			property: "og:description",
			content: "Track every refund claim you have filed."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./forgot-password-DgqNOcH1.mjs");
var Route$15 = createFileRoute("/forgot-password")({
	head: () => ({ meta: [
		{ title: "Reset your password — Restitute Banking" },
		{
			name: "description",
			content: "Request a secure password reset link for your Restitute Banking member account."
		},
		{
			property: "og:title",
			content: "Reset your password — Restitute Banking"
		},
		{
			property: "og:description",
			content: "Request a secure password reset link."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./grants-n0tNfBxT.mjs");
var Route$14 = createFileRoute("/grants")({
	head: () => ({ meta: [
		{ title: "Hardship Grants & Aid | Restitute Banking" },
		{
			name: "description",
			content: "Non-repayable hardship grants for members waiting on a refund claim: housing, medical, childcare, education and emergency relief."
		},
		{
			property: "og:title",
			content: "Hardship Grants & Aid"
		},
		{
			property: "og:description",
			content: "Non-repayable grants that carry members through the wait for a refund."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./how-it-works-B9nFzZqn.mjs");
var Route$13 = createFileRoute("/how-it-works")({
	head: () => ({ meta: [
		{ title: "How Refund Recovery Works | Restitute Banking" },
		{
			name: "description",
			content: "The six stages of a Restitute Banking refund claim: report, verify, evidence, file, negotiate and return. Timelines, evidence lists and fees explained."
		},
		{
			property: "og:title",
			content: "How Refund Recovery Works"
		},
		{
			property: "og:description",
			content: "Six transparent stages, published timelines and a fee taken only from recovered funds."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./loans-CMjkIfMq.mjs");
var Route$12 = createFileRoute("/loans")({
	loader: () => getSiteSettings(),
	head: () => ({ meta: [
		{ title: "Loans & Bridging Credit While You Wait | Restitute Banking" },
		{
			name: "description",
			content: "Personal, auto and home loans at member rates — plus claim bridging credit that covers you while a refund is still in recovery."
		},
		{
			property: "og:title",
			content: "Loans & Claim Bridging Credit"
		},
		{
			property: "og:description",
			content: "Member-rate lending and interest-free bridging credit against an open refund claim."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./login-DM9Fwy5a.mjs");
var Route$11 = createFileRoute("/login")({
	head: () => ({ meta: [
		{ title: "Member login — Restitute Banking" },
		{
			name: "description",
			content: "Sign in to your Restitute Banking account to manage claims, track recoveries and message your specialist."
		},
		{
			property: "og:title",
			content: "Member login — Restitute Banking"
		},
		{
			property: "og:description",
			content: "Sign in to manage your claims and recoveries."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./personal-banking-BfWzDYDM.mjs");
var Route$10 = createFileRoute("/personal-banking")({
	loader: () => getSiteSettings(),
	head: () => ({ meta: [
		{ title: "Personal Banking with Refund Cover | Restitute Banking" },
		{
			name: "description",
			content: "Everyday checking and high-yield savings where every transaction has a one-tap dispute button and a recovery desk behind it."
		},
		{
			property: "og:title",
			content: "Personal Banking with Refund Cover"
		},
		{
			property: "og:description",
			content: "Checking and savings accounts with instant dispute controls and 3.75% APY."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./privacy-HEcEmK9D.mjs");
var Route$9 = createFileRoute("/privacy")({
	head: () => ({ meta: [
		{ title: "Privacy policy — Restitute Banking" },
		{
			name: "description",
			content: "How Restitute Banking collects, uses and protects the personal and financial data you share when filing a refund claim."
		},
		{
			property: "og:title",
			content: "Privacy policy — Restitute Banking"
		},
		{
			property: "og:description",
			content: "How Restitute Banking collects, uses and protects your data."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./register-jp9SwNfO.mjs");
var Route$8 = createFileRoute("/register")({
	head: () => ({ meta: [
		{ title: "Open a Restitute Banking account" },
		{
			name: "description",
			content: "Create a free Restitute Banking account to file refund claims, track recoveries live and hold everyday funds with dispute cover."
		},
		{
			property: "og:title",
			content: "Open a Restitute Banking account"
		},
		{
			property: "og:description",
			content: "Create a free account to file and track refund claims."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./reset-password-6QXg4ldd.mjs");
var Route$7 = createFileRoute("/reset-password")({
	head: () => ({ meta: [
		{ title: "Set a new password — Restitute Banking" },
		{
			name: "description",
			content: "Choose a new password for your Restitute Banking member account."
		},
		{
			property: "og:title",
			content: "Set a new password — Restitute Banking"
		},
		{
			property: "og:description",
			content: "Choose a new password for your member account."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./terms-BFsttDu9.mjs");
var Route$6 = createFileRoute("/terms")({
	head: () => ({ meta: [
		{ title: "Terms of service — Restitute Banking" },
		{
			name: "description",
			content: "The terms that govern Restitute Banking accounts, refund recovery claims and our no-win-no-fee success fee."
		},
		{
			property: "og:title",
			content: "Terms of service — Restitute Banking"
		},
		{
			property: "og:description",
			content: "Account terms, claim handling rules and our no-win-no-fee structure."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./admin.index-BSaY1Ium.mjs");
var Route$5 = createFileRoute("/admin/")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./admin.claims-DGv0f7eR.mjs");
var Route$4 = createFileRoute("/admin/claims")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./admin.members-CAgfoX3S.mjs");
var Route$3 = createFileRoute("/admin/members")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./admin.settings-BHenvuzA.mjs");
var Route$2 = createFileRoute("/admin/settings")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./claims.new-CNWO0LHX.mjs");
var Route$1 = createFileRoute("/claims/new")({
	head: () => ({ meta: [
		{ title: "File a refund claim — Restitute Banking" },
		{
			name: "description",
			content: "Start a refund recovery file in under five minutes. No upfront fees, no account required, live tracking from the moment you submit."
		},
		{
			property: "og:title",
			content: "File a refund claim"
		},
		{
			property: "og:description",
			content: "Start a refund recovery file in under five minutes. No upfront fees."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./claims.track-Byyn-7Fg.mjs");
var Route = createFileRoute("/claims/track")({
	head: () => ({ meta: [
		{ title: "Track your refund claim — Restitute Banking" },
		{
			name: "description",
			content: "Enter your RB reference and email to see exactly where your refund claim stands, stage by stage, in real time."
		},
		{
			property: "og:title",
			content: "Track your refund claim"
		},
		{
			property: "og:description",
			content: "Live status for every Restitute Banking recovery file."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$23.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$24
});
var AboutRoute = Route$22.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$24
});
var AdminRoute = Route$21.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$24
});
var AppRoute = Route$20.update({
	id: "/app",
	path: "/app",
	getParentRoute: () => Route$24
});
var BusinessBankingRoute = Route$19.update({
	id: "/business-banking",
	path: "/business-banking",
	getParentRoute: () => Route$24
});
var CardsRoute = Route$18.update({
	id: "/cards",
	path: "/cards",
	getParentRoute: () => Route$24
});
var ContactRoute = Route$17.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$24
});
var DashboardRoute = Route$16.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => Route$24
});
var ForgotPasswordRoute = Route$15.update({
	id: "/forgot-password",
	path: "/forgot-password",
	getParentRoute: () => Route$24
});
var GrantsRoute = Route$14.update({
	id: "/grants",
	path: "/grants",
	getParentRoute: () => Route$24
});
var HowItWorksRoute = Route$13.update({
	id: "/how-it-works",
	path: "/how-it-works",
	getParentRoute: () => Route$24
});
var LoansRoute = Route$12.update({
	id: "/loans",
	path: "/loans",
	getParentRoute: () => Route$24
});
var LoginRoute = Route$11.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$24
});
var PersonalBankingRoute = Route$10.update({
	id: "/personal-banking",
	path: "/personal-banking",
	getParentRoute: () => Route$24
});
var PrivacyRoute = Route$9.update({
	id: "/privacy",
	path: "/privacy",
	getParentRoute: () => Route$24
});
var RegisterRoute = Route$8.update({
	id: "/register",
	path: "/register",
	getParentRoute: () => Route$24
});
var ResetPasswordRoute = Route$7.update({
	id: "/reset-password",
	path: "/reset-password",
	getParentRoute: () => Route$24
});
var TermsRoute = Route$6.update({
	id: "/terms",
	path: "/terms",
	getParentRoute: () => Route$24
});
var AdminIndexRoute = Route$5.update({
	id: "/",
	path: "/",
	getParentRoute: () => AdminRoute
});
var AdminClaimsRoute = Route$4.update({
	id: "/claims",
	path: "/claims",
	getParentRoute: () => AdminRoute
});
var AdminMembersRoute = Route$3.update({
	id: "/members",
	path: "/members",
	getParentRoute: () => AdminRoute
});
var AdminSettingsRoute = Route$2.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => AdminRoute
});
var ClaimsNewRoute = Route$1.update({
	id: "/claims/new",
	path: "/claims/new",
	getParentRoute: () => Route$24
});
var ClaimsTrackRoute = Route.update({
	id: "/claims/track",
	path: "/claims/track",
	getParentRoute: () => Route$24
});
var AdminRouteChildren = {
	AdminClaimsRoute,
	AdminMembersRoute,
	AdminSettingsRoute,
	AdminIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AboutRoute,
	AdminRoute: AdminRoute._addFileChildren(AdminRouteChildren),
	AppRoute,
	BusinessBankingRoute,
	CardsRoute,
	ContactRoute,
	DashboardRoute,
	ForgotPasswordRoute,
	GrantsRoute,
	HowItWorksRoute,
	LoansRoute,
	LoginRoute,
	PersonalBankingRoute,
	PrivacyRoute,
	RegisterRoute,
	ResetPasswordRoute,
	TermsRoute,
	ClaimsNewRoute,
	ClaimsTrackRoute
};
var routeTree = Route$24._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { useTheme as a, Route$23 as i, Route$10 as n, PageLoader as o, Route$12 as r, createSsrRpc as s, router_exports as t };
