import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as supabase } from "./client-C6aK345z.mjs";
import { P as LoaderCircle } from "../_libs/lucide-react.mjs";
import { n as authInput, r as authLabel, t as AuthCard } from "./AuthCard-BKtXiDZ8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/forgot-password-DgqNOcH1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ForgotPasswordPage() {
	const [email, setEmail] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [sent, setSent] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	async function onSubmit(event) {
		event.preventDefault();
		setLoading(true);
		setError(null);
		const { error: resetError } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/reset-password` });
		setLoading(false);
		if (resetError) {
			setError(resetError.message);
			return;
		}
		setSent(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthCard, {
		title: "Forgot your password?",
		intro: "Enter the email on your account and we will send a secure reset link.",
		footer: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/login",
			className: "font-semibold text-primary hover:underline",
			children: "Back to sign in"
		}),
		children: sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "rounded-2xl border border-border bg-secondary px-5 py-4 text-sm text-muted-foreground",
			children: [
				"If an account exists for ",
				email,
				", a reset link is on its way."
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: authLabel,
						children: "Email"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "email",
						className: `${authInput} mt-2`,
						value: email,
						onChange: (e) => setEmail(e.target.value),
						required: true
					})]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-xl border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "submit",
					disabled: loading,
					className: "shine inline-flex w-full items-center justify-center gap-2 rounded-xl bg-action px-6 py-3.5 text-sm font-semibold text-action-foreground disabled:opacity-60",
					children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : null, "Send reset link"]
				})
			]
		})
	});
}
//#endregion
export { ForgotPasswordPage as component };
