//#region node_modules/.nitro/vite/services/ssr/assets/secure-digital-xe_ZiwrF.js
var secure_digital_default = "/assets/secure-digital-KTjhxEjx.jpg";
//#endregion
export { secure_digital_default as t };
