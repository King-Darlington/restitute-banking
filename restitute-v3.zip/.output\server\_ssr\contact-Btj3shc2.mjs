import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { A as MapPin, E as Phone, Q as Clock3, j as Mail } from "../_libs/lucide-react.mjs";
import { t as SiteShell } from "./SiteShell-D04mdz6U.mjs";
import { n as PageHero } from "./PageHero-BCURtH2L.mjs";
import { r as FeatureGrid, t as CtaBanner } from "./blocks-Bu9Yj3IW.mjs";
import { t as ClaimLookup } from "./ClaimLookup-HT1xnjmb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-Btj3shc2.js
var import_jsx_runtime = require_jsx_runtime();
var customer_support_default = "/assets/customer-support-BRGBlAD6.jpg";
function ContactPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			image: customer_support_default,
			eyebrow: "Contact",
			title: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "Talk to a specialist, not a script." }),
			intro: "Every message reaches a named recovery specialist. Urgent fraud is handled around the clock, and existing claims are answered inside one business day.",
			breadcrumb: "Contact"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeatureGrid, {
			eyebrow: "Reach us",
			title: "Four direct lines into the recovery desk",
			items: [
				{
					icon: Phone,
					title: "24/7 fraud line",
					body: "1-800-RESTITUTE — report unauthorised movement the moment you see it.",
					meta: "Always open"
				},
				{
					icon: Mail,
					title: "Claims email",
					body: "claims@restitutebanking.com — attach evidence and quote your RB reference.",
					meta: "Reply < 24h"
				},
				{
					icon: Clock3,
					title: "Recovery desk",
					body: "Mon–Fri 8AM–8PM, Sat 9AM–1PM. Callback slots bookable inside your dashboard."
				},
				{
					icon: MapPin,
					title: "Registered office",
					body: "1200 Harbour Exchange, Suite 400, Wilmington, DE 19801."
				}
			],
			columns: 4
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-secondary py-16 lg:py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-5xl gap-8 px-4 sm:px-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl font-extrabold text-foreground",
					children: "Already filed with us?"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted-foreground",
					children: "Check the live status of any claim without signing in. You only need the RB reference from your confirmation email and the address the claim was filed under."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClaimLookup, { compact: true })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBanner, {
			title: "Money missing? Start the file now.",
			body: "Filing takes five minutes and costs nothing. You only pay if we recover your funds.",
			primary: {
				label: "Request a refund",
				to: "/claims/new"
			},
			secondary: {
				label: "How recovery works",
				to: "/how-it-works"
			}
		})
	] });
}
//#endregion
export { ContactPage as component };
