import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Brand-Di5xrbLi.js
var import_jsx_runtime = require_jsx_runtime();
function BrandLockup({ className, tone = "default" }) {
	const inverse = tone === "inverse";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("group/brand inline-flex flex-col leading-none", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-baseline gap-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("font-display text-[1.35rem] font-extrabold tracking-[-0.02em] sm:text-[1.5rem]", inverse ? "text-ink-foreground" : "text-gradient-brand"),
				children: "Restitute"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("font-display text-[1.35rem] font-light tracking-[-0.01em] sm:text-[1.5rem]", inverse ? "text-ink-foreground/70" : "text-foreground/70"),
				children: "Banking"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "mt-1 flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": "true",
				className: "h-[2px] w-8 rounded-full bg-action transition-all duration-300 group-hover/brand:w-12"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("text-[0.55rem] font-semibold uppercase tracking-[0.3em]", inverse ? "text-ink-foreground/55" : "text-muted-foreground"),
				children: "Refund recovery"
			})]
		})]
	});
}
//#endregion
export { BrandLockup as t };
