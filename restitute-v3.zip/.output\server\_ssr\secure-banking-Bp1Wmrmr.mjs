//#region node_modules/.nitro/vite/services/ssr/assets/secure-banking-Bp1Wmrmr.js
var secure_banking_default = "/assets/secure-banking-Al-U6jUg.jpg";
//#endregion
export { secure_banking_default as t };
