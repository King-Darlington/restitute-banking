import { r as __toESM } from "../_runtime.mjs";
import { r as createServerFn } from "./server-BLyHOJXt.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { f as Outlet, k as isRedirect, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as createSsrRpc } from "./router-R_2ReNa2.mjs";
import { t as supabase } from "./client-C6aK345z.mjs";
import { n as useIsStaff } from "./useAuth-Doc0DxK3.mjs";
import { P as LoaderCircle, m as ShieldCheck } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-CzFfAKo1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
var seedBuiltInAdmin = createServerFn({ method: "POST" }).handler(createSsrRpc("dc05c40b28178cbc350567c3e6230b26297116d267f074ebd50c28c8bf789019"));
var checkBuiltInAdmin = createServerFn({ method: "POST" }).handler(createSsrRpc("4b5157e99b9dee35de1101f03188daa3465c981f242a18d2cf4445a443f89c0d"));
function AdminGate({ children }) {
	const { isStaff, loading, user } = useIsStaff();
	const seed = useServerFn(seedBuiltInAdmin);
	const checkAdmin = useServerFn(checkBuiltInAdmin);
	const [adminExists, setAdminExists] = (0, import_react.useState)(null);
	const [showCreate, setShowCreate] = (0, import_react.useState)(false);
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const load = async () => {
			try {
				const result = await checkAdmin({});
				setAdminExists(result.exists);
			} catch {
				setAdminExists(true);
			}
		};
		load();
	}, [checkAdmin]);
	(0, import_react.useEffect)(() => {
		if (adminExists === false) setShowCreate(true);
	}, [adminExists]);
	if (loading || adminExists === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-secondary",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-6 w-6 animate-spin text-primary" })
	});
	if (user && isStaff) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
	async function onSubmit(event) {
		event.preventDefault();
		setBusy(true);
		setError(null);
		if (showCreate) {
			const { ok, message } = await seed({});
			setBusy(false);
			if (!ok) {
				setError(message ?? "Could not create admin account.");
				return;
			}
			setShowCreate(false);
			setAdminExists(true);
			return;
		}
		const { error: signInError } = await supabase.auth.signInWithPassword({
			email,
			password
		});
		setBusy(false);
		if (signInError) setError("Those credentials were not accepted.");
	}
	const input = "w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-foreground outline-none focus:border-primary focus:ring-2 focus:ring-primary/20";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "surface-ink relative flex min-h-screen items-center justify-center overflow-hidden px-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-grid text-ink-foreground/40 opacity-20" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative w-full max-w-sm rounded-3xl border border-border bg-card p-7 shadow-lift",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex h-11 w-11 items-center justify-center rounded-xl bg-primary-soft text-primary-deep",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-5 w-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-5 text-xl font-extrabold text-foreground",
					children: "Staff sign in"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Restricted area. Authorised Restitute Banking staff only."
				}),
				adminExists === false ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 rounded-xl border border-primary/40 bg-primary/10 px-4 py-3 text-sm text-primary",
					children: "No admin account was found. Create the built-in administrator account once and then sign in normally."
				}) : null,
				user && !isStaff ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 rounded-xl border border-warn/40 bg-warn/10 px-4 py-3 text-xs text-foreground",
					children: "You are signed in, but this account has no staff role."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "mt-6 space-y-3",
					children: [
						!showCreate ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "email",
							className: input,
							placeholder: "Staff email",
							value: email,
							onChange: (e) => setEmail(e.target.value),
							required: true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "password",
							className: input,
							placeholder: "Password",
							value: password,
							onChange: (e) => setPassword(e.target.value),
							required: true
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-primary/40 bg-primary/5 px-4 py-3 text-sm text-primary",
							children: [
								"This will create the default admin account at",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "block mt-2",
									children: "admin@restitutebanking.com"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "block",
									children: "Restitute@Admin2026"
								})
							]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-xl border border-destructive/30 bg-destructive/10 px-4 py-2.5 text-xs text-destructive",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "submit",
							disabled: busy,
							className: "inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground disabled:opacity-60",
							children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : null, showCreate ? "Create admin account" : "Sign in"]
						})
					]
				})
			]
		})]
	});
}
function AdminLayout() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) });
}
//#endregion
export { AdminLayout as component };
