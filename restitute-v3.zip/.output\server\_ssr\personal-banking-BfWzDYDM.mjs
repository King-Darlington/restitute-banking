import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Route$10 } from "./router-R_2ReNa2.mjs";
import { T as PiggyBank, dt as BadgeCheck, h as ShieldAlert, i as Wallet, lt as Bell, x as Repeat } from "../_libs/lucide-react.mjs";
import { t as SiteShell } from "./SiteShell-D04mdz6U.mjs";
import { t as Reveal } from "./Reveal-ogx-87vx.mjs";
import { n as PageHero, t as CtaButton } from "./PageHero-BCURtH2L.mjs";
import { t as SectionHeading } from "./SectionHeading-Bpr_dcs8.mjs";
import { a as StatBand, n as FaqList, r as FeatureGrid, t as CtaBanner } from "./blocks-Bu9Yj3IW.mjs";
import { t as secure_digital_default } from "./secure-digital-xe_ZiwrF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/personal-banking-BfWzDYDM.js
var import_jsx_runtime = require_jsx_runtime();
function PersonalBankingPage() {
	const settings = Route$10.useLoaderData();
	const accounts = [
		{
			name: "Everyday Checking",
			rate: "$0",
			unit: "monthly fee",
			points: [
				"No minimum balance",
				"One-tap dispute on every line",
				"Overdraft grace of 48 hours",
				"Free debit card replacement"
			],
			featured: false
		},
		{
			name: "Restitute Savings",
			rate: `${settings["rate_savings_apy"] ?? "3.75"}%`,
			unit: "APY*",
			points: [
				"Recovered funds earn from day one",
				"No tiered rate games",
				"Automatic round-up saving",
				"Withdraw any time"
			],
			featured: true
		},
		{
			name: "18-Month Certificate",
			rate: `${settings["rate_certificate_apy"] ?? "3.65"}%`,
			unit: "APY*",
			points: [
				"Fixed rate for the full term",
				"$500 minimum opening",
				"Early access if a claim resolves",
				"Automatic renewal option"
			],
			featured: false
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHero, {
			image: secure_digital_default,
			eyebrow: "Personal banking",
			title: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "Accounts that assume something might go wrong." }),
			intro: "Most banks treat a disputed payment as an exception. We built the account around it — every transaction line carries a dispute button that opens a real recovery file, not a ticket.",
			breadcrumb: "Personal banking",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaButton, {
				to: "/register",
				children: "Open an account"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaButton, {
				to: "/claims/new",
				variant: "ghost",
				children: "File a claim"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBand, { stats: [
			{
				value: `${settings["rate_savings_apy"] ?? "3.75"}%`,
				label: "Savings APY"
			},
			{
				value: "$0",
				label: "Monthly fees"
			},
			{
				value: "60 sec",
				label: "Card freeze to dispute"
			},
			{
				value: "24/7",
				label: "Fraud line"
			}
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-background py-16 lg:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
						eyebrow: "Choose an account",
						title: "Three accounts, no hidden tiers",
						intro: "Published rates, published fees. What you read here is what our staff console publishes."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-14 grid gap-6 lg:grid-cols-3",
						children: accounts.map((account, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: index * 90,
							direction: "scale",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: `lift relative flex h-full flex-col rounded-3xl border p-8 ${account.featured ? "border-primary/40 bg-card shadow-lift" : "border-border bg-card shadow-soft"}`,
								children: [
									account.featured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "absolute right-6 top-6 rounded-full bg-action px-3 py-1 text-[0.62rem] font-bold uppercase tracking-[0.14em] text-action-foreground",
										children: "Most opened"
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-lg font-bold text-foreground",
										children: account.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-4 flex items-baseline gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-4xl font-extrabold text-gradient-brand",
											children: account.rate
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-semibold text-muted-foreground",
											children: account.unit
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-6 flex-1 space-y-3",
										children: account.points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex gap-2.5 text-sm text-foreground/85",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "mt-0.5 h-4 w-4 shrink-0 text-action" }), point]
										}, point))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: "/register",
										className: `mt-8 rounded-xl px-5 py-3 text-center text-sm font-semibold transition-transform hover:-translate-y-0.5 ${account.featured ? "shine bg-action text-action-foreground" : "border border-border text-foreground hover:bg-primary-soft hover:text-primary-deep"}`,
										children: ["Open ", account.name]
									})
								]
							})
						}, account.name))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-center text-xs text-muted-foreground",
						children: "*Annual Percentage Yield. Rates subject to change. Terms and conditions apply."
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeatureGrid, {
			eyebrow: "Built in",
			title: "Controls that shorten a claim before it starts",
			tone: "dark",
			columns: 3,
			items: [
				{
					icon: ShieldAlert,
					title: "One-tap dispute",
					body: "Raise a claim from the transaction itself — merchant, amount and date are prefilled."
				},
				{
					icon: Bell,
					title: "Real-time alerts",
					body: "Every card authorisation pings your phone, so fraud is caught in minutes not statements."
				},
				{
					icon: Wallet,
					title: "Instant freeze",
					body: "Lock the card, keep the direct debits running, unfreeze when you are sure."
				},
				{
					icon: Repeat,
					title: "Subscription radar",
					body: "We flag recurring charges that changed price or restarted after a cancellation."
				},
				{
					icon: PiggyBank,
					title: "Recovery vault",
					body: "Recovered funds land in a separate pot so they do not disappear into everyday spending."
				},
				{
					icon: BadgeCheck,
					title: "Verified payees",
					body: "Name-check every new payee against the receiving bank before the money moves."
				}
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqList, {
			eyebrow: "Personal banking FAQ",
			title: "The practical questions",
			items: [
				{
					q: "How long does opening an account take?",
					a: "About four minutes online. You will need one photo ID and a proof of address; most applications are approved the same day."
				},
				{
					q: "Is my money insured?",
					a: "Yes. Deposits are federally insured to the standard limit per depositor, per ownership category."
				},
				{
					q: "Can I dispute a payment made from another bank?",
					a: "Yes. Our recovery desk takes claims regardless of where the money left from — a Restitute account is not a requirement."
				},
				{
					q: "Do you charge for card replacement?",
					a: "No. Replacements after fraud or loss are free and dispatched the same working day."
				}
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBanner, {
			title: "Open an account that has your back",
			body: "Four minutes to apply, same-day approval for most members, and a recovery desk from the moment you are in.",
			primary: {
				label: "Open an account",
				to: "/register"
			},
			secondary: {
				label: "Compare cards",
				to: "/cards"
			}
		})
	] });
}
//#endregion
export { PersonalBankingPage as component };
