import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { X as Compass, a as Users, y as Scale, z as HeartHandshake } from "../_libs/lucide-react.mjs";
import { t as SiteShell } from "./SiteShell-D04mdz6U.mjs";
import { t as Reveal } from "./Reveal-ogx-87vx.mjs";
import { n as PageHero, t as CtaButton } from "./PageHero-BCURtH2L.mjs";
import { t as SectionHeading } from "./SectionHeading-Bpr_dcs8.mjs";
import { a as StatBand, r as FeatureGrid, t as CtaBanner } from "./blocks-Bu9Yj3IW.mjs";
import { t as team_office_default } from "./team-office-DtTFGU89.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-DSgoNnod.js
var import_jsx_runtime = require_jsx_runtime();
var timeline = [
	{
		year: "2016",
		title: "Founded as a credit union",
		body: "Twelve members pooled deposits after a local payments processor collapsed owing them money."
	},
	{
		year: "2019",
		title: "The recovery desk opens",
		body: "We hired our first dispute specialists rather than outsourcing claims to a call centre."
	},
	{
		year: "2022",
		title: "Live claim tracking ships",
		body: "Members stopped calling to ask 'any update?' because the answer was already on screen."
	},
	{
		year: "2026",
		title: "$412M returned",
		body: "Over sixty-one thousand claims resolved, with an 87% recovery rate across all categories."
	}
];
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHero, {
			image: team_office_default,
			eyebrow: "About us",
			title: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "We are the bank that fights to get your money back." }),
			intro: "Restitute Banking exists because the institutions holding people's money are rarely the ones willing to chase it. We put both jobs under one roof, owned by the members we serve.",
			breadcrumb: "About",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaButton, {
				to: "/claims/new",
				children: "Start a claim"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaButton, {
				to: "/contact",
				variant: "ghost",
				children: "Talk to a specialist"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBand, { stats: [
			{
				value: "$412M",
				label: "Recovered for members"
			},
			{
				value: "61,840",
				label: "Claims resolved"
			},
			{
				value: "87%",
				label: "Recovery rate"
			},
			{
				value: "19 days",
				label: "Median resolution"
			}
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-background py-16 lg:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl items-center gap-14 px-4 sm:px-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					direction: "left",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: team_office_default,
						alt: "Restitute Banking specialists working through a claim file",
						loading: "lazy",
						width: 1600,
						height: 1008,
						className: "rounded-3xl border border-border object-cover shadow-lift"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					direction: "right",
					delay: 110,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
						align: "left",
						eyebrow: "Our mission",
						title: "Owned by members, not shareholders.",
						intro: "Every surplus we make is reinvested into better rates, faster recoveries and hardship grants. There is no external investor waiting to be paid before you are."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-sm leading-relaxed text-muted-foreground",
						children: "We are regulated as a full-service financial institution and hold deposits under federal insurance limits. Our recovery specialists are trained on card scheme rules, payment services regulations and ombudsman procedure — because winning a claim is a matter of filing correctly, not of shouting loudly."
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeatureGrid, {
			eyebrow: "What we stand for",
			title: "Three principles we will not trade away",
			items: [
				{
					icon: Scale,
					title: "Fee only on success",
					body: "We never invoice a member for a claim that did not recover money. There is no retainer, no admin charge, no exit fee."
				},
				{
					icon: Compass,
					title: "Visible at every stage",
					body: "You can see the exact stage, the named owner and the last action on your file at any hour, without asking us."
				},
				{
					icon: HeartHandshake,
					title: "Support while you wait",
					body: "Hardship grants and bridging credit exist so a pending claim never becomes a missed rent payment."
				}
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-secondary py-16 lg:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-5xl px-4 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Our history",
					title: "From twelve members to a national desk"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-14 space-y-4",
					children: timeline.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: index * 90,
						direction: index % 2 ? "right" : "left",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "lift flex flex-col gap-4 rounded-3xl border border-border bg-card p-7 shadow-soft sm:flex-row sm:items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-24 shrink-0 font-mono text-lg font-bold text-primary",
								children: item.year
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-bold text-foreground",
								children: item.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm leading-relaxed text-muted-foreground",
								children: item.body
							})] })]
						})
					}, item.year))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeatureGrid, {
			eyebrow: "The team",
			title: "Who actually works your file",
			tone: "dark",
			columns: 4,
			items: [
				{
					icon: Users,
					title: "Intake analysts",
					body: "Verify identity and build the transaction trail within one business day."
				},
				{
					icon: Scale,
					title: "Dispute specialists",
					body: "File under the correct scheme rules and drive the counterparty response."
				},
				{
					icon: Compass,
					title: "Escalation counsel",
					body: "Take unresolved claims to the ombudsman or regulator on your behalf."
				},
				{
					icon: HeartHandshake,
					title: "Member care",
					body: "Handle grants, bridging credit and anything else the wait creates."
				}
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBanner, {
			title: "Bank with the people who chase it down",
			body: "Open an account in minutes, or file a claim first and open the account when your funds land.",
			primary: {
				label: "Open an account",
				to: "/register"
			},
			secondary: {
				label: "File a claim",
				to: "/claims/new"
			}
		})
	] });
}
//#endregion
export { AboutPage as component };
