import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as supabase } from "./client-C6aK345z.mjs";
import { P as LoaderCircle, v as Search } from "../_libs/lucide-react.mjs";
import { a as statusMeta } from "./claims-B4EsFPLl.mjs";
import { n as money, r as shortDate } from "./format--W0ZbsWV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ClaimLookup-HT1xnjmb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ClaimLookup({ compact = false }) {
	const [reference, setReference] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [claim, setClaim] = (0, import_react.useState)(null);
	const [timeline, setTimeline] = (0, import_react.useState)([]);
	async function onSubmit(event) {
		event.preventDefault();
		setLoading(true);
		setError(null);
		setClaim(null);
		setTimeline([]);
		const { data, error: rpcError } = await supabase.rpc("track_claim", {
			_reference: reference,
			_email: email
		});
		if (rpcError) setError("We could not reach the claims service. Please try again.");
		else if (!data || data.length === 0) setError("No claim matches that reference and email. Check both and try again.");
		else {
			setClaim(data[0]);
			const { data: events } = await supabase.rpc("track_claim_timeline", {
				_reference: reference,
				_email: email
			});
			setTimeline(events ?? []);
		}
		setLoading(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("rounded-3xl border border-border bg-card p-6 shadow-soft sm:p-8"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex h-10 w-10 items-center justify-center rounded-xl bg-primary-soft text-primary-deep",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-5 w-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-lg font-bold text-foreground",
					children: "Track a claim"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Enter your reference code and the email on the claim."
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: cn("mt-6 grid gap-3", !compact && "sm:grid-cols-2"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mb-1.5 block text-xs font-semibold uppercase tracking-[0.12em] text-muted-foreground",
							children: "Reference"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: true,
							value: reference,
							onChange: (event) => setReference(event.target.value),
							placeholder: "RB-104217",
							className: "w-full rounded-xl border border-input bg-background px-4 py-3 font-mono text-sm uppercase tracking-wider outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/20"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mb-1.5 block text-xs font-semibold uppercase tracking-[0.12em] text-muted-foreground",
							children: "Email on the claim"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: true,
							type: "email",
							value: email,
							onChange: (event) => setEmail(event.target.value),
							placeholder: "you@example.com",
							className: "w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/20"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "submit",
						disabled: loading,
						className: cn("shine flex items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-transform hover:-translate-y-0.5 disabled:opacity-60", !compact && "sm:col-span-2"),
						children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : null, loading ? "Checking…" : "Check status"]
					})
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 rounded-xl border border-destructive/25 bg-destructive/10 px-4 py-3 text-sm text-destructive",
				children: error
			}) : null,
			claim ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-2xl border border-border bg-secondary/60 p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs uppercase tracking-widest text-muted-foreground",
							children: claim.reference
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-lg font-bold text-foreground",
							children: claim.claimant_name
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("rounded-full border px-3 py-1 text-xs font-bold uppercase tracking-[0.1em]", statusMeta[claim.status].tone),
							children: statusMeta[claim.status].label
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted-foreground",
						children: statusMeta[claim.status].blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "mt-5 grid grid-cols-2 gap-4 border-t border-border pt-4 sm:grid-cols-4",
						children: [
							{
								label: "Claimed",
								value: money(claim.amount, claim.currency)
							},
							{
								label: "Recovered",
								value: money(claim.recovered_amount, claim.currency)
							},
							{
								label: "Submitted",
								value: shortDate(claim.submitted_at)
							},
							{
								label: "Last update",
								value: shortDate(claim.updated_at)
							}
						].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-[0.65rem] font-semibold uppercase tracking-[0.12em] text-muted-foreground",
							children: item.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 text-sm font-bold text-foreground",
							children: item.value
						})] }, item.label))
					}),
					timeline.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-6 space-y-4 border-t border-border pt-5",
						children: timeline.map((entry, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1 h-2.5 w-2.5 shrink-0 rounded-full bg-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold text-foreground",
									children: entry.title
								}),
								entry.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 text-xs text-muted-foreground",
									children: entry.note
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-[0.65rem] uppercase tracking-[0.12em] text-muted-foreground",
									children: shortDate(entry.created_at)
								})
							] })]
						}, `${entry.title}-${index}`))
					}) : null
				]
			}) : null
		]
	});
}
//#endregion
export { ClaimLookup as t };
