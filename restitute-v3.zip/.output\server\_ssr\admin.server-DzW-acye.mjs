import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.server-DzW-acye.js
function isNewSupabaseApiKey(value) {
	return value.startsWith("sb_publishable_") || value.startsWith("sb_secret_");
}
function createSupabaseFetch(supabaseKey) {
	return (input, init) => {
		const headers = new Headers(typeof Request !== "undefined" && input instanceof Request ? input.headers : void 0);
		if (init?.headers) new Headers(init.headers).forEach((value, key) => headers.set(key, value));
		if (isNewSupabaseApiKey(supabaseKey) && headers.get("Authorization") === `Bearer ${supabaseKey}`) headers.delete("Authorization");
		headers.set("apikey", supabaseKey);
		return fetch(input, {
			...init,
			headers
		});
	};
}
function createSupabaseAdminClient() {
	const SUPABASE_URL = process.env["SUPABASE_URL"];
	const SUPABASE_SERVICE_ROLE_KEY = process.env["SUPABASE_SERVICE_ROLE_KEY"];
	if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
		const message = `Missing Supabase environment variable(s): ${[...!SUPABASE_URL ? ["SUPABASE_URL"] : [], ...!SUPABASE_SERVICE_ROLE_KEY ? ["SUPABASE_SERVICE_ROLE_KEY"] : []].join(", ")}.`;
		console.error(`[Supabase] ${message}`);
		throw new Error(message);
	}
	return createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
		global: { fetch: createSupabaseFetch(SUPABASE_SERVICE_ROLE_KEY) },
		auth: {
			storage: void 0,
			persistSession: false,
			autoRefreshToken: false
		}
	});
}
var _supabaseAdmin;
var supabaseAdmin = new Proxy({}, { get(_, prop, receiver) {
	if (!_supabaseAdmin) _supabaseAdmin = createSupabaseAdminClient();
	return Reflect.get(_supabaseAdmin, prop, receiver);
} });
var DEFAULT_ADMIN_EMAIL = "admin@restitutebanking.org";
var DEFAULT_ADMIN_PASSWORD = "Restitute@Admin2026";
/**
* Ensures the built-in staff account exists, the WordPress-style way:
* one known administrator that can sign in at /admin on a fresh install.
*/
async function ensureBuiltInAdmin() {
	const supabase = supabaseAdmin;
	const { data: list, error: listError } = await supabase.auth.admin.listUsers({
		page: 1,
		perPage: 200
	});
	if (listError) return {
		ok: false,
		message: listError.message
	};
	let user = list?.users.find((u) => u.email?.toLowerCase() === DEFAULT_ADMIN_EMAIL);
	if (!user) {
		const { data: created, error: createError } = await supabase.auth.admin.createUser({
			email: DEFAULT_ADMIN_EMAIL,
			password: DEFAULT_ADMIN_PASSWORD,
			email_confirm: true,
			user_metadata: {
				first_name: "Restitute",
				last_name: "Administrator"
			}
		});
		if (createError) return {
			ok: false,
			message: createError.message
		};
		user = created.user ?? void 0;
	}
	if (!user) return {
		ok: false,
		message: "Could not provision the administrator account."
	};
	const { error: upsertError } = await supabase.from("user_roles").upsert({
		user_id: user.id,
		role: "admin"
	}, { onConflict: "user_id,role" });
	if (upsertError) return {
		ok: false,
		message: upsertError.message
	};
	return {
		ok: true,
		message: "ready"
	};
}
async function adminAccountExists() {
	const { data: list, error } = await supabaseAdmin.auth.admin.listUsers({
		page: 1,
		perPage: 200
	});
	if (error) throw error;
	return list?.users.some((user) => user.email?.toLowerCase() === "admin@restitutebanking.org") ?? false;
}
//#endregion
export { adminAccountExists, ensureBuiltInAdmin };
