import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as SiteShell } from "./SiteShell-D04mdz6U.mjs";
import { n as PageHero } from "./PageHero-BCURtH2L.mjs";
import { i as ProseSection } from "./blocks-Bu9Yj3IW.mjs";
import { t as secure_banking_default } from "./secure-banking-Bp1Wmrmr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-BFsttDu9.js
var import_jsx_runtime = require_jsx_runtime();
function TermsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			image: secure_banking_default,
			eyebrow: "Legal",
			title: "Terms of service",
			intro: "Plain terms for a service built on trust: what we do, what we charge, and what we will not promise.",
			breadcrumb: "Terms"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProseSection, {
			title: "1. The service",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Restitute Banking provides everyday deposit accounts and a refund recovery service. We act as your representative in raising disputes with paying institutions. We are not a law firm and do not provide legal advice." })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProseSection, {
			title: "2. Fees",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Filing a claim is free. If, and only if, funds are recovered, a success fee of 15% of the recovered amount is deducted before payout. No recovery, no fee, no hidden charges." })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProseSection, {
			title: "3. Your responsibilities",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You confirm that the information and evidence you submit is accurate and that you are the rightful owner of the funds claimed. Knowingly false claims are reported to the relevant authorities and terminate your account." })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProseSection, {
			title: "4. Outcomes",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We do not guarantee recovery. Scheme rules, time limits and the counterparty's solvency all affect outcomes. We will always tell you in writing why a claim was declined." })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProseSection, {
			title: "5. Closing your file",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You may withdraw a claim at any time before settlement at no cost. Accounts can be closed on written request once no claim is active." })
		})
	] });
}
//#endregion
export { TermsPage as component };
