//#region node_modules/.nitro/vite/services/ssr/assets/team-office-DtTFGU89.js
var team_office_default = "/assets/team-office-DvTFFPbt.jpg";
//#endregion
export { team_office_default as t };
