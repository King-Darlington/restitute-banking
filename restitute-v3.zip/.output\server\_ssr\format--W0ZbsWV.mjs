//#region node_modules/.nitro/vite/services/ssr/assets/format--W0ZbsWV.js
function money(value, currency = "USD") {
	const amount = typeof value === "string" ? Number(value) : value ?? 0;
	return new Intl.NumberFormat("en-US", {
		style: "currency",
		currency,
		maximumFractionDigits: Number.isInteger(amount) ? 0 : 2
	}).format(Number.isFinite(amount) ? amount : 0);
}
function compactMoney(value, currency = "USD") {
	const symbol = currency === "USD" ? "$" : currency === "GBP" ? "£" : currency === "EUR" ? "€" : "";
	const abs = Math.abs(value);
	for (const [size, suffix] of [
		[1e9, "B"],
		[1e6, "M"],
		[1e3, "K"]
	]) if (abs >= size) {
		const scaled = value / size;
		return `${symbol}${Math.abs(scaled) >= 100 ? Math.round(scaled).toString() : scaled.toFixed(1).replace(/\.0$/, "")}${suffix}`;
	}
	return `${symbol}${Math.round(value)}`;
}
function shortDate(value) {
	if (!value) return "—";
	const date = typeof value === "string" ? new Date(value) : value;
	if (Number.isNaN(date.getTime())) return "—";
	return date.toLocaleDateString("en-US", {
		month: "short",
		day: "numeric",
		year: "numeric"
	});
}
//#endregion
export { money as n, shortDate as r, compactMoney as t };
