import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as SiteShell } from "./SiteShell-D04mdz6U.mjs";
import { t as Reveal } from "./Reveal-ogx-87vx.mjs";
import { n as PageHero } from "./PageHero-BCURtH2L.mjs";
import { n as FaqList } from "./blocks-Bu9Yj3IW.mjs";
import { i as RECOVERY_STAGES } from "./claims-B4EsFPLl.mjs";
import { t as ClaimLookup } from "./ClaimLookup-HT1xnjmb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/claims.track-Byyn-7Fg.js
var import_jsx_runtime = require_jsx_runtime();
var financial_recovery_default = "/assets/financial-recovery-BKu6k0Lz.jpg";
function TrackPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			image: financial_recovery_default,
			eyebrow: "Claim tracking",
			title: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "Know exactly where your money is." }),
			intro: "No hold music, no chasing. Every stage of your recovery is timestamped and visible the moment it changes.",
			breadcrumb: "Track a claim"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-background py-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto max-w-3xl px-4 sm:px-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClaimLookup, {})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-secondary py-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-5xl px-4 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl font-extrabold text-foreground",
					children: "The six stages"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
					children: RECOVERY_STAGES.map((stage, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: index * 70,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "lift h-full rounded-2xl border border-border bg-card p-6 shadow-soft",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-bold uppercase tracking-[0.2em] text-action",
									children: ["Stage ", index + 1]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-2 text-lg font-bold text-foreground",
									children: stage.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-muted-foreground",
									children: stage.body
								})
							]
						})
					}, stage.title))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqList, {
			eyebrow: "Tracking FAQ",
			title: "Questions about your claim status",
			items: [
				{
					q: "Where do I find my reference?",
					a: "It is in your filing confirmation email and starts with RB-. It is also shown on your member dashboard."
				},
				{
					q: "How often does the status update?",
					a: "In real time. Whenever a specialist advances your file, the stage and timeline update immediately."
				},
				{
					q: "What does 'evidence requested' mean?",
					a: "We need one more document to file or escalate. The timeline note names exactly which one."
				},
				{
					q: "Can someone else track my claim?",
					a: "Only with both the reference and the email the claim was filed under. Nothing sensitive is exposed by reference alone."
				}
			]
		})
	] });
}
//#endregion
export { TrackPage as component };
