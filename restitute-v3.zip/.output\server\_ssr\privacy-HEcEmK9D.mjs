import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as SiteShell } from "./SiteShell-D04mdz6U.mjs";
import { n as PageHero } from "./PageHero-BCURtH2L.mjs";
import { i as ProseSection } from "./blocks-Bu9Yj3IW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-HEcEmK9D.js
var import_jsx_runtime = require_jsx_runtime();
var data_privacy_default = "/assets/data-privacy--x5ijWny.jpg";
function PrivacyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			image: data_privacy_default,
			eyebrow: "Legal",
			title: "Privacy policy",
			intro: "We only collect what a recovery genuinely requires, we tell you why, and we delete it on schedule.",
			breadcrumb: "Privacy"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProseSection, {
			title: "What we collect",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Identity details (name, date of birth, address), contact details, and the transaction evidence you attach to a claim. Where a scheme requires proof of identity we collect a government document reference, never the full document image beyond the retention window." })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProseSection, {
			title: "Why we use it",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "To verify you are the account holder, to raise disputes with the paying institution under the correct scheme rules, and to meet anti-money-laundering obligations. We never sell personal data and we do not use claim evidence for marketing." })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProseSection, {
			title: "Who sees it",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Your assigned recovery specialist, the counterparty institution strictly as needed to file the dispute, and regulators or an ombudsman when a case is escalated." })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProseSection, {
			title: "How long we keep it",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Claim files are retained for six years after closure, as required for financial dispute records. Uploaded identity documents are purged 90 days after verification." })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProseSection, {
			title: "Your rights",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You can request a copy, correction or erasure of your data at any time by emailing privacy@restitutebanking.com. We respond within 30 days." })
		})
	] });
}
//#endregion
export { PrivacyPage as component };
