import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { B as HandCoins, R as House, a as Users, ct as BookOpen, ft as Baby, l as Stethoscope } from "../_libs/lucide-react.mjs";
import { t as SiteShell } from "./SiteShell-D04mdz6U.mjs";
import { t as Reveal } from "./Reveal-ogx-87vx.mjs";
import { n as PageHero, t as CtaButton } from "./PageHero-BCURtH2L.mjs";
import { t as SectionHeading } from "./SectionHeading-Bpr_dcs8.mjs";
import { a as StatBand, n as FaqList, t as CtaBanner } from "./blocks-Bu9Yj3IW.mjs";
import { n as money } from "./format--W0ZbsWV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/grants-n0tNfBxT.js
var import_jsx_runtime = require_jsx_runtime();
var community_grant_default = "/assets/community-grant-B3MYxf-7.jpg";
var grants = [
	{
		icon: House,
		name: "Housing Stability Grant",
		max: 3500,
		body: "Covers rent or mortgage arrears created by a loss that is still in recovery.",
		window: "Decision in 5 working days"
	},
	{
		icon: Stethoscope,
		name: "Medical Relief Grant",
		max: 5e3,
		body: "Treatment, prescriptions and travel-to-care costs for members and dependants.",
		window: "Decision in 3 working days"
	},
	{
		icon: Baby,
		name: "Childcare Continuity Grant",
		max: 2e3,
		body: "Keeps a childcare place open so a parent does not have to leave work.",
		window: "Decision in 5 working days"
	},
	{
		icon: BookOpen,
		name: "Education Access Grant",
		max: 4e3,
		body: "Tuition, exam fees and equipment for members or their children.",
		window: "Termly assessment"
	},
	{
		icon: HandCoins,
		name: "Emergency Relief Grant",
		max: 1500,
		body: "Food, utilities and immediate essentials, paid within 48 hours of approval.",
		window: "Decision in 48 hours"
	},
	{
		icon: Users,
		name: "Community Fund",
		max: 1e4,
		body: "For local groups running financial-literacy or fraud-prevention work.",
		window: "Quarterly rounds"
	}
];
function GrantsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHero, {
			image: community_grant_default,
			eyebrow: "Grants & aid",
			title: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "Money you never pay back, while you wait for money you are owed." }),
			intro: "A claim can take weeks. Rent does not wait. Our grant programme is funded from member surplus and exists so that a pending recovery never turns into a crisis.",
			breadcrumb: "Grants & aid",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaButton, {
				to: "/claims/new",
				children: "Apply for support"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaButton, {
				to: "/contact",
				variant: "ghost",
				children: "Ask about eligibility"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBand, { stats: [
			{
				value: "$8.4M",
				label: "Granted since 2019"
			},
			{
				value: "6,120",
				label: "Households supported"
			},
			{
				value: "48 hrs",
				label: "Fastest decision"
			},
			{
				value: "$0",
				label: "Repayable"
			}
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-background py-16 lg:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Programmes",
					title: "Six grants, all non-repayable",
					intro: "Awards are assessed on need, not on credit history. Applying has no effect on any claim, loan or account you hold."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3",
					children: grants.map((grant, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: index * 80,
						direction: "scale",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "lift flex h-full flex-col rounded-3xl border border-border bg-card p-7 shadow-soft",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex h-12 w-12 items-center justify-center rounded-2xl bg-action-soft text-action",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(grant.icon, { className: "h-5.5 w-5.5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-5 text-lg font-bold text-foreground",
									children: grant.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 text-2xl font-extrabold text-gradient-brand",
									children: ["up to ", money(grant.max)]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 flex-1 text-sm leading-relaxed text-muted-foreground",
									children: grant.body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 rounded-full bg-secondary px-3 py-1.5 text-center text-[0.65rem] font-bold uppercase tracking-[0.12em] text-muted-foreground",
									children: grant.window
								})
							]
						})
					}, grant.name))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "surface-ink relative overflow-hidden py-16 lg:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-grid text-ink-foreground/40 opacity-20" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto max-w-4xl px-4 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					tone: "dark",
					eyebrow: "Eligibility",
					title: "Who can apply"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-4 sm:grid-cols-2",
					children: [
						"You hold a Restitute account, or have an open claim with us",
						"The need is current and evidenced — not historic or speculative",
						"You have not received the same grant in the last twelve months",
						"The amount requested is proportionate to the documented need"
					].map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: index * 80,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-2xl border border-ink-foreground/12 bg-ink-foreground/[0.06] p-5 text-sm leading-relaxed text-ink-foreground/80",
							children: item
						})
					}, item))
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqList, {
			eyebrow: "Grants FAQ",
			title: "What applicants ask",
			items: [
				{
					q: "Is a grant really not repayable?",
					a: "Correct. A grant is an award from member surplus. It is not a loan, it carries no interest and it is never recovered from a later claim payout."
				},
				{
					q: "Does a grant reduce my claim?",
					a: "No. The two are assessed separately and a grant does not affect the amount we pursue on your behalf."
				},
				{
					q: "What evidence is required?",
					a: "Typically a bill, arrears letter or invoice showing the need, plus your claim reference if one exists. Our team will list exactly what applies to your programme."
				},
				{
					q: "Can I apply for more than one?",
					a: "Yes, where the needs are genuinely distinct. Combined awards are capped at $10,000 per household per year."
				}
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBanner, {
			title: "If the wait is hurting, tell us now",
			body: "Support applications are assessed by people, not scorecards, and the fastest programme decides in forty-eight hours.",
			primary: {
				label: "Apply for support",
				to: "/claims/new"
			},
			secondary: {
				label: "Talk to member care",
				to: "/contact"
			}
		})
	] });
}
//#endregion
export { GrantsPage as component };
