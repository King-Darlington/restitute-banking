import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { J as Eye, N as Lock, Y as CreditCard, b as RotateCcw, f as Snowflake, w as Plane } from "../_libs/lucide-react.mjs";
import { t as SiteShell } from "./SiteShell-D04mdz6U.mjs";
import { t as Reveal } from "./Reveal-ogx-87vx.mjs";
import { n as PageHero, t as CtaButton } from "./PageHero-BCURtH2L.mjs";
import { t as SectionHeading } from "./SectionHeading-Bpr_dcs8.mjs";
import { a as StatBand, n as FaqList, r as FeatureGrid, t as CtaBanner } from "./blocks-Bu9Yj3IW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cards-C7pU5bs0.js
var import_jsx_runtime = require_jsx_runtime();
var card_payment_default = "/assets/card-payment-CL4PRqNa.jpg";
var cards = [
	{
		name: "Restitute Debit",
		tone: "from-primary-deep to-primary",
		body: "Free with every checking account. One-tap disputes, instant freeze and real-time alerts as standard.",
		points: [
			"No foreign transaction fee",
			"Virtual numbers on demand",
			"Same-day replacement"
		]
	},
	{
		name: "Shield Credit",
		tone: "from-ink to-primary-deep",
		body: "Purchase protection to $10,000 per claim, plus extended warranty on eligible goods.",
		points: [
			"0% on balance transfers for 15 months",
			"Purchase protection built in",
			"No annual fee"
		]
	},
	{
		name: "Voyage Rewards",
		tone: "from-action-deep to-action",
		body: "For members who spend abroad — 2% back on travel and dining, with trip disruption cover.",
		points: [
			"2% travel and dining rewards",
			"Trip disruption cover",
			"Airport lounge credits"
		]
	}
];
function CardsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHero, {
			image: card_payment_default,
			eyebrow: "Cards",
			title: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "The dispute button lives on the card, not in a call queue." }),
			intro: "Every Restitute card puts freeze, virtual numbers and one-tap disputes directly on the transaction. Protection that works before the loss is the only protection that matters.",
			breadcrumb: "Cards",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaButton, {
				to: "/register",
				children: "Apply for a card"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaButton, {
				to: "/personal-banking",
				variant: "ghost",
				children: "Compare accounts"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBand, { stats: [
			{
				value: "$10,000",
				label: "Purchase protection"
			},
			{
				value: "0%",
				label: "Foreign transaction fee"
			},
			{
				value: "60 sec",
				label: "Freeze to dispute"
			},
			{
				value: "24 hrs",
				label: "Replacement dispatch"
			}
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-background py-16 lg:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "The range",
					title: "Three cards, one protection standard"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-14 grid gap-6 lg:grid-cols-3",
					children: cards.map((card, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: index * 100,
						direction: "up",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "lift flex h-full flex-col rounded-3xl border border-border bg-card p-7 shadow-soft",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `relative aspect-[1.586/1] overflow-hidden rounded-2xl bg-gradient-to-br ${card.tone} p-5 shadow-lift`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-grid text-ink-foreground/40 opacity-25" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex h-full flex-col justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-bold uppercase tracking-[0.2em] text-ink-foreground/85",
												children: "Restitute"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "h-5 w-5 text-ink-foreground/70" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-mono text-sm tracking-[0.24em] text-ink-foreground/90",
											children: "•••• •••• •••• 4217"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1.5 text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-ink-foreground/60",
											children: card.name
										})] })]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-6 text-lg font-bold text-foreground",
									children: card.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-muted-foreground",
									children: card.body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-5 flex-1 space-y-2.5",
									children: card.points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex gap-2.5 text-sm text-foreground/85",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-action" }), point]
									}, point))
								})
							]
						})
					}, card.name))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeatureGrid, {
			eyebrow: "Card controls",
			title: "Six controls that stop losses early",
			tone: "dark",
			items: [
				{
					icon: Snowflake,
					title: "Instant freeze",
					body: "Lock the card in one tap while keeping standing orders and direct debits alive."
				},
				{
					icon: Eye,
					title: "Virtual numbers",
					body: "Generate a single-merchant card number for anything you are not sure about."
				},
				{
					icon: RotateCcw,
					title: "One-tap dispute",
					body: "Open a recovery file directly from the transaction with the details prefilled."
				},
				{
					icon: Lock,
					title: "Channel limits",
					body: "Turn online, contactless, ATM or overseas use on and off independently."
				},
				{
					icon: Plane,
					title: "Travel mode",
					body: "Tell us where you are going and we stop blocking legitimate spend abroad."
				},
				{
					icon: CreditCard,
					title: "Merchant blocks",
					body: "Permanently block a merchant that keeps charging after cancellation."
				}
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqList, {
			eyebrow: "Card FAQ",
			title: "Card questions, answered",
			items: [
				{
					q: "How fast is a fraud refund?",
					a: "Provisional credit for confirmed card fraud is applied within one business day while the full dispute runs."
				},
				{
					q: "Does freezing cancel my subscriptions?",
					a: "No. A freeze blocks new authorisations but leaves existing mandates in place, so nothing breaks unintentionally."
				},
				{
					q: "Is there a credit check?",
					a: "Debit cards, no. Shield Credit and Voyage Rewards require a credit assessment, starting with a soft search."
				},
				{
					q: "Can I have more than one card?",
					a: "Yes — one debit plus up to two credit cards per member, subject to affordability."
				}
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBanner, {
			title: "Carry a card that can fight back",
			body: "Apply in minutes and get a virtual card number immediately, with the physical card in the post.",
			primary: {
				label: "Apply for a card",
				to: "/register"
			},
			secondary: {
				label: "See the mobile app",
				to: "/app"
			}
		})
	] });
}
//#endregion
export { CardsPage as component };
