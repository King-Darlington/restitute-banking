import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as BrandLockup } from "./Brand-Di5xrbLi.mjs";
import { N as Lock, Q as Clock3, m as ShieldCheck } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/AuthCard-BKtXiDZ8.js
var import_jsx_runtime = require_jsx_runtime();
var authInput = "w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-foreground outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/20";
var authLabel = "block text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground";
function AuthCard({ title, intro, children, footer }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid min-h-screen lg:grid-cols-[1fr_1.05fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface-ink relative hidden overflow-hidden lg:flex lg:flex-col lg:justify-between lg:p-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-grid text-ink-foreground/40 opacity-20" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "float-slow pointer-events-none absolute -left-20 top-20 h-72 w-72 rounded-full blur-3xl",
					style: {
						background: "var(--gradient-brand)",
						opacity: .3
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "relative",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandLockup, { tone: "inverse" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-3xl font-extrabold leading-tight text-ink-foreground",
						children: "Money that left wrongly belongs back with you."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-8 space-y-4 text-sm text-ink-foreground/75",
						children: [
							{
								icon: ShieldCheck,
								text: "No upfront fees — you pay only on recovery."
							},
							{
								icon: Lock,
								text: "Bank-grade encryption on every document you share."
							},
							{
								icon: Clock3,
								text: "Live claim tracking, updated the moment anything changes."
							}
						].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "mt-0.5 h-4 w-4 shrink-0 text-action" }), item.text]
						}, item.text))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "relative text-xs text-ink-foreground/45",
					children: "Routing 251480576 · Member protections apply"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center justify-center bg-background px-4 py-14 sm:px-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "lg:hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandLockup, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-8 text-3xl font-extrabold text-foreground lg:mt-0",
						children: title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted-foreground",
						children: intro
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8",
						children
					}),
					footer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 text-sm text-muted-foreground",
						children: footer
					}) : null
				]
			})
		})]
	});
}
//#endregion
export { authInput as n, authLabel as r, AuthCard as t };
