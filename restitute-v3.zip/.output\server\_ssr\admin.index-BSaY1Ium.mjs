import { i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as supabase } from "./client-C6aK345z.mjs";
import { n as AdminShell, t as AdminCard } from "./AdminShell-DfqDGwjx.mjs";
import { a as statusMeta } from "./claims-B4EsFPLl.mjs";
import { n as money } from "./format--W0ZbsWV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.index-BSaY1Ium.js
var import_jsx_runtime = require_jsx_runtime();
function AdminOverview() {
	const { data, isLoading } = useQuery({
		queryKey: ["admin", "overview"],
		queryFn: async () => {
			const { data: claims } = await supabase.from("claims").select("id, reference, claimant_name, amount, recovered_amount, currency, status, created_at").order("created_at", { ascending: false }).limit(200);
			return claims ?? [];
		}
	});
	const claims = data ?? [];
	const open = claims.filter((c) => !["disbursed", "declined"].includes(c.status));
	const recovered = claims.reduce((sum, c) => sum + Number(c.recovered_amount ?? 0), 0);
	const exposure = open.reduce((sum, c) => sum + Number(c.amount ?? 0), 0);
	const stats = [
		{
			label: "Open cases",
			value: open.length.toLocaleString("en-US")
		},
		{
			label: "Total claims",
			value: claims.length.toLocaleString("en-US")
		},
		{
			label: "Recovered",
			value: money(recovered)
		},
		{
			label: "Amount in play",
			value: money(exposure)
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminShell, {
		title: "Overview",
		subtitle: "Live picture of the recovery desk.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
			children: stats.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-card p-5 shadow-soft",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-muted-foreground",
					children: stat.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-2xl font-extrabold text-foreground",
					children: stat.value
				})]
			}, stat.label))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-4 lg:grid-cols-[1.4fr_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminCard, {
				title: "Latest claims",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/admin/claims",
					className: "text-xs font-semibold text-primary hover:underline",
					children: "View all"
				}),
				children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Loading…"
				}) : claims.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "No claims filed yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-border",
					children: claims.slice(0, 8).map((claim) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-semibold text-foreground",
								children: claim.claimant_name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate font-mono text-xs text-muted-foreground",
								children: [
									claim.reference,
									" · ",
									money(Number(claim.amount), claim.currency)
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `shrink-0 rounded-full border px-2.5 py-1 text-[0.65rem] font-semibold ${statusMeta[claim.status].tone}`,
							children: statusMeta[claim.status].label
						})]
					}, claim.id))
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminCard, {
				title: "Pipeline by stage",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: Object.entries(statusMeta).map(([key, meta]) => {
						const count = claims.filter((c) => c.status === key).length;
						const pct = claims.length ? Math.round(count / claims.length * 100) : 0;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-foreground",
								children: meta.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: count
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 h-1.5 overflow-hidden rounded-full bg-secondary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full rounded-full bg-primary",
								style: { width: `${pct}%` }
							})
						})] }, key);
					})
				})
			})]
		})]
	});
}
//#endregion
export { AdminOverview as component };
