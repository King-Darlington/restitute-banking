import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { et as ChevronDown } from "../_libs/lucide-react.mjs";
import { t as Reveal } from "./Reveal-ogx-87vx.mjs";
import { t as SectionHeading } from "./SectionHeading-Bpr_dcs8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/blocks-Bu9Yj3IW.js
var import_jsx_runtime = require_jsx_runtime();
function FeatureGrid({ eyebrow, title, intro, items, columns = 3, tone = "light" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("relative overflow-hidden py-16 lg:py-24", tone === "dark" ? "surface-ink" : "bg-background"),
		children: [tone === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-grid text-ink-foreground/40 opacity-20" }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto max-w-7xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow,
				title,
				...intro ? { intro } : {},
				tone
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("mt-14 grid gap-6", columns === 2 && "md:grid-cols-2", columns === 3 && "md:grid-cols-2 lg:grid-cols-3", columns === 4 && "sm:grid-cols-2 lg:grid-cols-4"),
				children: items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: index * 80,
					direction: "scale",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: cn("lift h-full rounded-3xl border p-7", tone === "dark" ? "border-ink-foreground/12 bg-ink-foreground/[0.06]" : "border-border bg-card shadow-soft"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("flex h-12 w-12 items-center justify-center rounded-2xl", tone === "dark" ? "bg-action/15 text-action" : "bg-primary-soft text-primary-deep"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "h-5.5 w-5.5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: cn("mt-5 text-lg font-bold", tone === "dark" ? "text-ink-foreground" : "text-foreground"),
								children: item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: cn("mt-2 text-sm leading-relaxed", tone === "dark" ? "text-ink-foreground/70" : "text-muted-foreground"),
								children: item.body
							}),
							item.meta ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 inline-flex rounded-full bg-action-soft px-2.5 py-1 text-[0.65rem] font-bold uppercase tracking-[0.12em] text-action",
								children: item.meta
							}) : null
						]
					})
				}, item.title))
			})]
		})]
	});
}
function StatBand({ stats }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-y border-border bg-secondary py-12",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto grid max-w-7xl gap-8 px-4 sm:grid-cols-2 sm:px-6 lg:grid-cols-4",
			children: stats.map((stat, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				delay: index * 80,
				className: "text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-3xl font-extrabold text-gradient-brand sm:text-4xl",
					children: stat.value
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground",
					children: stat.label
				})]
			}, stat.label))
		})
	});
}
function CtaBanner({ title, body, primary, secondary }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "relative overflow-hidden bg-background py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				direction: "scale",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-ink relative overflow-hidden rounded-[2rem] px-8 py-14 text-center shadow-lift sm:px-14",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-grid text-ink-foreground/40 opacity-20" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "float-slow pointer-events-none absolute -right-16 -top-16 h-64 w-64 rounded-full blur-3xl",
							style: {
								background: "var(--gradient-action)",
								opacity: .22
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative mx-auto max-w-2xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-3xl font-extrabold leading-tight text-ink-foreground sm:text-4xl",
									children: title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-base leading-relaxed text-ink-foreground/70",
									children: body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-9 flex flex-wrap justify-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: primary.to,
										className: "shine rounded-xl bg-action px-6 py-3.5 text-sm font-semibold text-action-foreground transition-transform hover:-translate-y-0.5",
										children: primary.label
									}), secondary ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: secondary.to,
										className: "rounded-xl border border-ink-foreground/25 px-6 py-3.5 text-sm font-semibold text-ink-foreground transition-colors hover:bg-ink-foreground/10",
										children: secondary.label
									}) : null]
								})
							]
						})
					]
				})
			})
		})
	});
}
function FaqList({ eyebrow, title, items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-secondary py-16 lg:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-4xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow,
				title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 space-y-3",
				children: items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: index * 60,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
						className: "group rounded-2xl border border-border bg-card px-6 py-5 shadow-soft transition-colors open:border-primary/30",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
							className: "flex cursor-pointer list-none items-center justify-between gap-4 text-sm font-bold text-foreground",
							children: [item.q, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-300 group-open:rotate-180" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted-foreground",
							children: item.a
						})]
					})
				}, item.q))
			})]
		})
	});
}
function ProseSection({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-background py-16 lg:py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-extrabold text-foreground",
				children: title
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 80,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 space-y-4 text-sm leading-relaxed text-muted-foreground",
					children
				})
			})]
		})
	});
}
//#endregion
export { StatBand as a, ProseSection as i, FaqList as n, FeatureGrid as r, CtaBanner as t };
