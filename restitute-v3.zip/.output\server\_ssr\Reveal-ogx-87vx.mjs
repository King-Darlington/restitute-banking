import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Reveal-ogx-87vx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var baseClass = {
	up: "reveal",
	left: "reveal-left",
	right: "reveal-right",
	scale: "reveal-scale"
};
function Reveal({ children, className, delay = 0, direction = "up", as: Tag = "div" }) {
	const ref = (0, import_react.useRef)(null);
	const [shown, setShown] = (0, import_react.useState)(true);
	const [shouldAnimate, setShouldAnimate] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const node = ref.current;
		if (!node) return;
		if (typeof IntersectionObserver === "undefined") {
			setShown(true);
			return;
		}
		const rect = node.getBoundingClientRect();
		if (rect.top < window.innerHeight * .95 && rect.bottom > 0) {
			setShown(true);
			setShouldAnimate(false);
			return;
		}
		setShown(false);
		setShouldAnimate(true);
		const observer = new IntersectionObserver((entries) => {
			for (const entry of entries) if (entry.isIntersecting) {
				setShown(true);
				observer.disconnect();
			}
		}, {
			rootMargin: "0px 0px -6% 0px",
			threshold: .05
		});
		observer.observe(node);
		return () => observer.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
		ref,
		className: cn(shouldAnimate && baseClass[direction], shouldAnimate && shown && "is-revealed", className),
		style: shouldAnimate ? { transitionDelay: `${delay}ms` } : void 0,
		children
	});
}
//#endregion
export { Reveal as t };
