import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link, l as useRouterState, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as supabase } from "./client-C6aK345z.mjs";
import { I as LayoutDashboard, M as LogOut, W as FolderKanban, a as Users, g as Settings, k as Menu, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/AdminShell-DfqDGwjx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var links = [
	{
		to: "/admin",
		label: "Overview",
		icon: LayoutDashboard,
		exact: true
	},
	{
		to: "/admin/claims",
		label: "Claims",
		icon: FolderKanban
	},
	{
		to: "/admin/members",
		label: "Members",
		icon: Users
	},
	{
		to: "/admin/settings",
		label: "Settings",
		icon: Settings
	}
];
function AdminShell({ title, subtitle, children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const navigate = useNavigate();
	const [open, setOpen] = (0, import_react.useState)(false);
	const isActive = (to, exact) => exact ? pathname === to : pathname.startsWith(to);
	async function signOut() {
		await supabase.auth.signOut();
		navigate({ to: "/admin" });
	}
	const nav = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "space-y-1",
		children: links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: link.to,
			onClick: () => setOpen(false),
			className: cn("flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors", isActive(link.to, link.exact) ? "bg-ink-foreground/12 text-ink-foreground" : "text-ink-foreground/65 hover:bg-ink-foreground/8 hover:text-ink-foreground"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(link.icon, { className: "h-4 w-4 shrink-0" }), link.label]
		}, link.to))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-secondary lg:grid lg:grid-cols-[16rem_minmax(0,1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "surface-ink hidden flex-col justify-between p-5 lg:flex",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "px-3 text-sm font-extrabold tracking-tight text-ink-foreground",
					children: ["Restitute ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-light",
						children: "Back office"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-6 mt-1 px-3 text-[0.65rem] uppercase tracking-[0.18em] text-ink-foreground/45",
					children: "Staff console"
				}),
				nav
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-ink-foreground/65 hover:text-ink-foreground",
					children: "View public site"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: signOut,
					className: "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-ink-foreground/65 hover:text-ink-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4" }), " Sign out"]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-screen flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "surface-ink flex items-center justify-between gap-4 px-4 py-3 lg:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-bold text-ink-foreground",
						children: "Restitute Back office"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setOpen((v) => !v),
						"aria-label": open ? "Close menu" : "Open menu",
						className: "inline-flex h-9 w-9 items-center justify-center rounded-lg border border-ink-foreground/20 text-ink-foreground",
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-4 w-4" })
					})]
				}),
				open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-ink border-t border-ink-foreground/10 p-4 lg:hidden",
					children: [nav, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: signOut,
						className: "mt-2 flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-ink-foreground/65",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4" }), " Sign out"]
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 px-4 py-8 sm:px-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-6xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "truncate text-2xl font-extrabold text-foreground sm:text-3xl",
									children: title
								}), subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted-foreground",
									children: subtitle
								}) : null]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8",
							children
						})]
					})
				})
			]
		})]
	});
}
function AdminCard({ title, children, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-border bg-card p-5 shadow-soft",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "truncate text-sm font-semibold uppercase tracking-[0.14em] text-muted-foreground",
				children: title
			}), action]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4",
			children
		})]
	});
}
//#endregion
export { AdminShell as n, AdminCard as t };
