import { i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { t as supabase } from "./client-C6aK345z.mjs";
import { n as AdminShell } from "./AdminShell-DfqDGwjx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.members-CAgfoX3S.js
var import_jsx_runtime = require_jsx_runtime();
function AdminMembers() {
	const { data } = useQuery({
		queryKey: ["admin", "members"],
		queryFn: async () => {
			const { data: profiles } = await supabase.from("profiles").select("id, first_name, last_name, email, phone, country, created_at").order("created_at", { ascending: false });
			return profiles ?? [];
		}
	});
	const members = data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminShell, {
		title: "Members",
		subtitle: "Everyone with a Restitute Banking account.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto rounded-2xl border border-border bg-card shadow-soft",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[38rem] text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "border-b border-border text-[0.65rem] uppercase tracking-[0.16em] text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-semibold",
							children: "Name"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-semibold",
							children: "Email"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-semibold",
							children: "Phone"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-semibold",
							children: "Joined"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
					className: "divide-y divide-border",
					children: [members.map((member) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3 font-medium text-foreground",
							children: [member.first_name, member.last_name].filter(Boolean).join(" ") || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3 text-muted-foreground",
							children: member.email || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3 text-muted-foreground",
							children: member.phone || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3 text-muted-foreground",
							children: new Date(member.created_at).toLocaleDateString("en-US")
						})
					] }, member.id)), members.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 4,
						className: "px-4 py-6 text-center text-muted-foreground",
						children: "No members yet."
					}) }) : null]
				})]
			})
		})
	});
}
//#endregion
export { AdminMembers as component };
