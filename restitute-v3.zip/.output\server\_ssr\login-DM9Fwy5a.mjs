import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useTheme } from "./router-R_2ReNa2.mjs";
import { t as supabase } from "./client-C6aK345z.mjs";
import { A as MapPin, N as Lock, P as LoaderCircle, c as SunMoon, d as Sparkles, j as Mail, m as ShieldCheck, y as Scale } from "../_libs/lucide-react.mjs";
import { n as authInput, r as authLabel } from "./AuthCard-BKtXiDZ8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-DM9Fwy5a.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var features = [
	{
		icon: ShieldCheck,
		title: "Bank-Grade Security",
		subtitle: "Encrypted access and secure account controls across every session."
	},
	{
		icon: Sparkles,
		title: "Instant Recovery",
		subtitle: "Fast refund workflows designed to recover funds quickly."
	},
	{
		icon: MapPin,
		title: "Live Tracking",
		subtitle: "See your claim status update in real time as progress happens."
	},
	{
		icon: Scale,
		title: "No Win No Fee",
		subtitle: "Only pay when recovery is successful — no upfront charge."
	}
];
function LoginPage() {
	const navigate = useNavigate();
	const { dark, toggleTheme } = useTheme();
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	async function onSubmit(event) {
		event.preventDefault();
		setLoading(true);
		setError(null);
		const { error: signInError } = await supabase.auth.signInWithPassword({
			email,
			password
		});
		setLoading(false);
		if (signInError) {
			setError(signInError.message);
			return;
		}
		navigate({ to: "/dashboard" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-screen bg-background text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: toggleTheme,
			className: "fixed right-4 top-4 z-30 inline-flex h-12 w-12 items-center justify-center rounded-2xl border border-border bg-background/90 text-foreground shadow-lg shadow-black/5 backdrop-blur-md transition hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-primary/40 dark:bg-slate-950/90 dark:border-slate-700",
			"aria-label": "Toggle dark mode",
			children: dark ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SunMoon, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-5 w-5" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative flex min-h-screen flex-col lg:flex-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "relative hidden w-full overflow-hidden px-10 py-14 text-white lg:flex lg:w-1/2 lg:flex-col",
				style: { background: "linear-gradient(180deg, var(--ink) 0%, var(--primary-deep) 100%)" },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_left,_rgba(255,255,255,0.18),_transparent_20%),radial-gradient(circle_at_60%_20%,_rgba(255,255,255,0.1),_transparent_18%),radial-gradient(circle_at_bottom_left,_rgba(255,255,255,0.1),_transparent_20%)]" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-[linear-gradient(90deg,rgba(255,255,255,0.08)_1px,transparent_1px),linear-gradient(rgba(255,255,255,0.08)_1px,transparent_1px)] bg-[length:28px_28px] opacity-60" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-10 top-16 h-64 w-64 rounded-full bg-white/10 blur-3xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute right-10 top-28 h-44 w-44 rounded-full bg-white/5 blur-2xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-24 bottom-16 h-52 w-52 rounded-full bg-white/10 blur-3xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 flex grow flex-col justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm uppercase tracking-[0.28em] text-white/70",
							children: "Restitute Banking"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-8 max-w-lg text-5xl font-extrabold leading-tight text-white sm:text-6xl",
							children: "Secure recovery for every refund and claim."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: features.map((feature) => {
								const Icon = feature.icon;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-[1.75rem] border border-white/20 bg-white/10 p-5 backdrop-blur-xl",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "inline-flex h-12 w-12 items-center justify-center rounded-3xl bg-white/10 text-white shadow-lg shadow-black/10",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "mt-5 text-base font-semibold text-white",
											children: feature.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm leading-6 text-white/75",
											children: feature.subtitle
										})
									]
								}, feature.title);
							})
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex w-full items-center justify-center px-4 py-12 sm:px-6 lg:w-1/2 lg:px-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md rounded-[2rem] border border-gray-200/50 bg-white/90 p-8 shadow-2xl shadow-slate-900/10 backdrop-blur-xl dark:border-slate-700/50 dark:bg-slate-950/90",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold uppercase tracking-[0.24em] text-muted-foreground",
									children: "Welcome back"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 text-3xl font-extrabold text-foreground",
									children: "Member login"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-relaxed text-muted-foreground",
									children: "Sign in to see live claim progress, message your specialist and manage your accounts."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit,
							className: "space-y-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: authLabel,
										children: "Email"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative mt-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "email",
											className: `${authInput} mt-0 pl-12 transition-transform duration-200 ease-out focus:-translate-y-1`,
											value: email,
											onChange: (e) => setEmail(e.target.value),
											required: true
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: authLabel,
										children: "Password"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative mt-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "password",
											className: `${authInput} mt-0 pl-12 transition-transform duration-200 ease-out focus:-translate-y-1`,
											value: password,
											onChange: (e) => setPassword(e.target.value),
											required: true
										})]
									})]
								}),
								error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "rounded-3xl border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive",
									children: error
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "submit",
									disabled: loading,
									className: "inline-flex w-full items-center justify-center gap-2 rounded-3xl bg-action px-6 py-3 text-sm font-semibold text-action-foreground transition hover:bg-action/90 disabled:cursor-not-allowed disabled:opacity-60",
									children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : null, "Sign in"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-3 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/forgot-password",
										className: "font-semibold text-primary hover:underline",
										children: "Forgot password?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/claims/track",
										className: "hover:text-foreground",
										children: "Track without signing in"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-6 text-center text-sm text-muted-foreground",
							children: [
								"New here? ",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/register",
									className: "font-semibold text-primary hover:underline",
									children: "Create an account"
								})
							]
						})
					]
				})
			})]
		})]
	});
}
//#endregion
export { LoginPage as component };
