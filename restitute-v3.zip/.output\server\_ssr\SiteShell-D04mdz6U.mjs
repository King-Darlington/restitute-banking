import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useTheme } from "./router-R_2ReNa2.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as BrandLockup } from "./Brand-Di5xrbLi.mjs";
import { t as useAuth } from "./useAuth-Doc0DxK3.mjs";
import { $ as ChevronRight, A as MapPin, E as Phone, c as SunMoon, d as Sparkles, et as ChevronDown, j as Mail, k as Menu, m as ShieldCheck, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/SiteShell-D04mdz6U.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var navGroups = [
	{
		label: "Home",
		to: "/"
	},
	{
		label: "Refunds",
		links: [
			{
				label: "File a claim",
				to: "/claims/new",
				description: "Start a recovery file in under 5 minutes"
			},
			{
				label: "Track a claim",
				to: "/claims/track",
				description: "Check progress with your reference code"
			},
			{
				label: "How recovery works",
				to: "/how-it-works",
				description: "The six stages of every claim"
			},
			{
				label: "Grants & aid",
				to: "/grants",
				description: "Hardship support while you wait"
			}
		]
	},
	{
		label: "Banking",
		links: [
			{
				label: "Personal banking",
				to: "/personal-banking",
				description: "Everyday accounts with refund cover"
			},
			{
				label: "Business banking",
				to: "/business-banking",
				description: "Chargeback defence for merchants"
			},
			{
				label: "Loans & credit",
				to: "/loans",
				description: "Bridging funds against pending claims"
			},
			{
				label: "Cards",
				to: "/cards",
				description: "Cards with instant dispute controls"
			}
		]
	},
	{
		label: "Mobile app",
		to: "/app"
	},
	{
		label: "About",
		to: "/about"
	},
	{
		label: "Contact",
		to: "/contact"
	}
];
var footerColumns = [
	{
		title: "Refunds",
		links: [
			{
				label: "File a claim",
				to: "/claims/new"
			},
			{
				label: "Track a claim",
				to: "/claims/track"
			},
			{
				label: "How recovery works",
				to: "/how-it-works"
			},
			{
				label: "Grants & aid",
				to: "/grants"
			}
		]
	},
	{
		title: "Banking",
		links: [
			{
				label: "Personal banking",
				to: "/personal-banking"
			},
			{
				label: "Business banking",
				to: "/business-banking"
			},
			{
				label: "Loans & credit",
				to: "/loans"
			},
			{
				label: "Cards",
				to: "/cards"
			}
		]
	},
	{
		title: "Company",
		links: [
			{
				label: "About us",
				to: "/about"
			},
			{
				label: "Mobile app",
				to: "/app"
			},
			{
				label: "Contact",
				to: "/contact"
			},
			{
				label: "Member login",
				to: "/login"
			}
		]
	},
	{
		title: "Legal",
		links: [
			{
				label: "Privacy policy",
				to: "/privacy"
			},
			{
				label: "Terms of service",
				to: "/terms"
			},
			{
				label: "Open an account",
				to: "/register"
			},
			{
				label: "Staff console",
				to: "/admin"
			}
		]
	}
];
function SiteHeader() {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [expanded, setExpanded] = (0, import_react.useState)(null);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const { user } = useAuth();
	const { dark, toggleTheme } = useTheme();
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 12);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	(0, import_react.useEffect)(() => {
		setOpen(false);
		setExpanded(null);
	}, [pathname]);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = open ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [open]);
	const isActive = (to) => to === "/" ? pathname === "/" : pathname.startsWith(to);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "hidden bg-ink text-ink-foreground lg:block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-7xl items-center justify-between gap-6 px-6 py-2 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center gap-2 text-ink-foreground/80",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-3.5 w-3.5 text-action" }), "No upfront fees — you only pay when we recover your money."]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-6 text-ink-foreground/75",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "tel:18007378488",
						className: "flex items-center gap-1.5 hover:text-ink-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-3.5 w-3.5" }), " 1-800-RESTITUTE"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono tracking-wider",
						children: "ROUTING 251480576"
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: cn("sticky top-0 z-50 w-full border-b transition-all duration-300", scrolled ? "border-border bg-background/85 shadow-soft backdrop-blur-xl" : "border-transparent bg-background/60 backdrop-blur-md"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:h-[4.5rem]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						"aria-label": "Restitute Banking home",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandLockup, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "hidden items-center gap-1 lg:flex",
						"aria-label": "Primary",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "pointer-events-none absolute left-16 top-1/2 h-32 w-32 -translate-y-1/2 rounded-full bg-primary/20 blur-xl opacity-90 animate-pulse",
								style: { animationDelay: "0s" }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "pointer-events-none absolute left-1/2 top-2 h-24 w-24 -translate-x-1/2 rounded-full bg-primary/15 blur-xl opacity-90 animate-pulse",
								style: { animationDelay: "0.25s" }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "pointer-events-none absolute right-16 top-1/3 h-36 w-36 -translate-y-1/2 rounded-full bg-primary/20 blur-xl opacity-90 animate-pulse",
								style: { animationDelay: "0.5s" }
							}),
							navGroups.map((group) => group.links ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "group relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "flex items-center gap-1 rounded-lg px-3 py-2 text-sm font-medium text-foreground/80 transition-colors hover:text-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "relative overflow-hidden",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-0 scale-0 rounded-md bg-primary-soft transition-transform duration-300 group-hover:scale-100" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "relative",
											children: group.label
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-3.5 w-3.5 transition-transform duration-300 group-hover:rotate-180" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "invisible absolute left-0 top-full w-80 translate-y-2 pt-2 opacity-0 transition-all duration-300 group-hover:visible group-hover:translate-y-0 group-hover:opacity-100",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "overflow-hidden rounded-2xl border border-border bg-popover p-2 shadow-lift",
										children: group.links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: link.to,
											className: "block rounded-xl px-3 py-2.5 transition-colors hover:bg-muted",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block text-sm font-semibold text-foreground",
												children: link.label
											}), link.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-0.5 block text-xs text-muted-foreground",
												children: link.description
											}) : null]
										}, link.to))
									})
								})]
							}, group.label) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: group.to,
								"data-active": isActive(group.to),
								className: "group relative overflow-hidden rounded-lg px-3 py-2 text-sm font-medium text-foreground/80 transition-colors hover:text-foreground data-[active=true]:text-primary",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-0 scale-0 rounded-md bg-primary-soft transition-transform duration-300 group-hover:scale-100" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "relative",
									children: group.label
								})]
							}, group.to))
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden items-center gap-2 lg:flex",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								"aria-label": "Toggle theme",
								onClick: toggleTheme,
								className: "inline-flex h-10 w-10 items-center justify-center rounded-xl border border-border text-foreground",
								children: dark ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SunMoon, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-5 w-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: user ? "/dashboard" : "/login",
								className: "rounded-xl px-3 py-2 text-sm font-semibold text-foreground/80 transition-colors hover:text-primary",
								children: user ? "My dashboard" : "Login"
							}),
							!user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/register",
								className: "rounded-xl border border-primary/35 bg-primary-soft px-4 py-2 text-sm font-semibold text-primary-deep transition-colors hover:border-primary/60",
								children: "Sign up"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/claims/new",
								className: "group relative overflow-hidden rounded-xl bg-action px-4 py-2 text-sm font-semibold text-action-foreground shadow-soft transition-transform hover:-translate-y-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent transition-transform duration-700 group-hover:translate-x-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "relative inline-flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4" }), "Request refund"]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setOpen((v) => !v),
						"aria-label": open ? "Close menu" : "Open menu",
						"aria-expanded": open,
						className: "inline-flex h-10 w-10 items-center justify-center rounded-xl border border-border text-foreground lg:hidden",
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-5 w-5" })
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("fixed inset-x-0 top-16 z-40 origin-top overflow-y-auto border-b border-border bg-background transition-all duration-300 lg:hidden", open ? "max-h-[calc(100dvh-4rem)] opacity-100 animate-open-menu" : "pointer-events-none max-h-0 opacity-0"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "space-y-1 px-4 py-5",
				"aria-label": "Mobile",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-2 pb-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							"aria-label": "Toggle theme",
							onClick: toggleTheme,
							className: "inline-flex h-10 w-10 items-center justify-center rounded-xl border border-border text-foreground",
							children: dark ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SunMoon, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-5 w-5" })
						})
					}),
					navGroups.map((group) => group.links ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-border/70",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setExpanded((v) => v === group.label ? null : group.label),
							className: "flex w-full items-center justify-between px-4 py-3 text-sm font-semibold",
							children: [group.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("h-4 w-4 transition-transform duration-300", expanded === group.label && "rotate-180") })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: cn("grid transition-all duration-300", expanded === group.label ? "grid-rows-[1fr]" : "grid-rows-[0fr]"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-1 px-2 pb-3",
									children: group.links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: link.to,
										className: "group block rounded-lg px-3 py-2 text-sm text-muted-foreground transition-all duration-200 hover:bg-muted hover:text-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center justify-between gap-2 transition-transform duration-200 group-hover:translate-x-2",
											children: [link.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4 opacity-0 transition-opacity duration-200 group-hover:opacity-100" })]
										})
									}, link.to))
								})
							})
						})]
					}, group.label) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: group.to,
						className: "block rounded-xl px-4 py-3 text-sm font-semibold hover:bg-muted",
						children: group.label
					}, group.to)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 pt-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: user ? "/dashboard" : "/login",
								className: "rounded-xl border border-border px-4 py-3 text-center text-sm font-semibold",
								children: user ? "My dashboard" : "Login"
							}),
							!user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/register",
								className: "rounded-xl border border-primary/35 bg-primary-soft px-4 py-3 text-center text-sm font-semibold text-primary-deep",
								children: "Sign up"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/claims/new",
								className: "rounded-xl bg-action px-4 py-3 text-center text-sm font-semibold text-action-foreground",
								children: "Request refund"
							})
						]
					})
				]
			})
		})
	] });
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "surface-ink relative overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-grid text-ink-foreground/40 opacity-30" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto max-w-7xl px-4 py-16 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-12 lg:grid-cols-[1.3fr_2.7fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandLockup, { tone: "inverse" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-sm text-sm leading-relaxed text-ink-foreground/70",
						children: "Restitute Banking is a member-owned institution built around one promise: money that left your account wrongly should come back. We combine everyday banking with a dedicated recovery desk."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-6 space-y-3 text-sm text-ink-foreground/70",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-4 w-4 text-action" }), " 1-800-RESTITUTE (24/7)"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4 text-action" }), " claims@restitutebanking.com"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 h-4 w-4 text-action" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"118 Recovery Row, Financial District",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"New York, NY 10001"
								] })]
							})
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-8 sm:grid-cols-4",
					children: footerColumns.map((column) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-xs font-semibold uppercase tracking-[0.18em] text-ink-foreground/50",
						children: column.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-2.5",
						children: column.links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: link.to,
							className: "text-sm text-ink-foreground/75 transition-colors hover:text-ink-foreground",
							children: link.label
						}) }, link.to))
					})] }, column.title))
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-14 flex flex-col gap-4 border-t border-ink-foreground/15 pt-8 text-xs text-ink-foreground/55 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" Restitute Banking. All rights reserved."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono tracking-wider",
					children: "Routing 251480576 · Deposits federally insured · Equal Housing Lender"
				})]
			})]
		})]
	});
}
function SiteShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen flex-col bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { SiteShell as t };
