import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { G as FingerprintPattern, S as Radar, _ as Send, lt as Bell, nt as ChartLine, p as Smartphone } from "../_libs/lucide-react.mjs";
import { t as SiteShell } from "./SiteShell-D04mdz6U.mjs";
import { t as Reveal } from "./Reveal-ogx-87vx.mjs";
import { n as PageHero, t as CtaButton } from "./PageHero-BCURtH2L.mjs";
import { t as SectionHeading } from "./SectionHeading-Bpr_dcs8.mjs";
import { a as StatBand, n as FaqList, r as FeatureGrid, t as CtaBanner } from "./blocks-Bu9Yj3IW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-CX2kfI86.js
var import_jsx_runtime = require_jsx_runtime();
var mobile_banking_default = "/assets/mobile-banking-BUzDrwXn.jpg";
function AppPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHero, {
			image: mobile_banking_default,
			eyebrow: "Mobile app",
			title: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "Your claim, your cards and your specialist — in one place." }),
			intro: "The app is not a shrunken website. It is the fastest route to the two things that matter in a loss: freezing the card and opening the file.",
			breadcrumb: "Mobile app",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaButton, {
				to: "/register",
				children: "Create your login"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaButton, {
				to: "/claims/track",
				variant: "ghost",
				children: "Track without an account"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBand, { stats: [
			{
				value: "4.9",
				label: "Average store rating"
			},
			{
				value: "60 sec",
				label: "Freeze to dispute"
			},
			{
				value: "Face ID",
				label: "Biometric login"
			},
			{
				value: "Real time",
				label: "Transaction alerts"
			}
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-background py-16 lg:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl items-center gap-14 px-4 sm:px-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					direction: "left",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: mobile_banking_default,
						alt: "Restitute Banking mobile app showing a claim timeline",
						loading: "lazy",
						width: 1400,
						height: 1400,
						className: "rounded-3xl border border-border object-cover shadow-lift"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					direction: "right",
					delay: 110,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
						align: "left",
						eyebrow: "Designed for the bad day",
						title: "Built for the moment you notice the money is gone",
						intro: "Most banking apps optimise for balance-checking. We optimised for the panic minute: three taps from opening the app to a frozen card and a live claim."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-8 space-y-4",
						children: [
							"Open the app — biometric login, no password to remember",
							"Tap the transaction and freeze the card instantly",
							"Press dispute; merchant, amount and date are already filled",
							"Watch the stage change as your specialist works the file"
						].map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
							delay: index * 80,
							as: "li",
							className: "flex gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground",
								children: index + 1
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pt-0.5 text-sm leading-relaxed text-foreground/85",
								children: step
							})]
						}, step))
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeatureGrid, {
			eyebrow: "In the app",
			title: "Everything the desk can see, you can see",
			tone: "dark",
			items: [
				{
					icon: ChartLine,
					title: "Live claim timeline",
					body: "Stage, owner, last action and next expected step, updated as it happens."
				},
				{
					icon: Send,
					title: "Message your specialist",
					body: "Reply in-thread and attach documents straight from your camera roll."
				},
				{
					icon: Bell,
					title: "Alerts that matter",
					body: "Authorisations, stage changes and evidence requests — nothing else."
				},
				{
					icon: Radar,
					title: "Subscription radar",
					body: "Spot price rises and zombie subscriptions before they cost you again."
				},
				{
					icon: FingerprintPattern,
					title: "Biometric security",
					body: "Face and fingerprint login, with device binding and session alerts."
				},
				{
					icon: Smartphone,
					title: "Offline receipts",
					body: "Snap and store evidence even without signal; it syncs when you reconnect."
				}
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqList, {
			eyebrow: "App FAQ",
			title: "Getting started",
			items: [
				{
					q: "Do I need an account to use the app?",
					a: "Yes for the full app, but anyone can track an existing claim on the web with a reference code and email."
				},
				{
					q: "Which devices are supported?",
					a: "iOS 15 and later, and Android 10 and later, on phone and tablet."
				},
				{
					q: "Is my data safe on a shared device?",
					a: "Sessions are bound to the device and time out automatically. You can revoke any device instantly from settings."
				},
				{
					q: "Does it work outside the country?",
					a: "Yes, including card controls and claim tracking. Travel mode reduces false declines abroad."
				}
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBanner, {
			title: "Set it up before you need it",
			body: "Creating a login takes two minutes. It is the difference between a frozen card in seconds and a phone queue at midnight.",
			primary: {
				label: "Create your login",
				to: "/register"
			},
			secondary: {
				label: "See card controls",
				to: "/cards"
			}
		})
	] });
}
//#endregion
export { AppPage as component };
