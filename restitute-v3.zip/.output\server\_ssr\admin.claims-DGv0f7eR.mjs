import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime, r as useQueryClient, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { t as supabase } from "./client-C6aK345z.mjs";
import { v as Search } from "../_libs/lucide-react.mjs";
import { n as AdminShell } from "./AdminShell-DfqDGwjx.mjs";
import { a as statusMeta, t as CLAIM_STATUSES } from "./claims-B4EsFPLl.mjs";
import { n as money } from "./format--W0ZbsWV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.claims-DGv0f7eR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminClaims() {
	const queryClient = useQueryClient();
	const [query, setQuery] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const { data } = useQuery({
		queryKey: ["admin", "claims"],
		queryFn: async () => {
			const { data: claims } = await supabase.from("claims").select("*").order("created_at", { ascending: false });
			return claims ?? [];
		}
	});
	const claims = (data ?? []).filter((claim) => {
		const matchesStatus = filter === "all" || claim.status === filter;
		const term = query.trim().toLowerCase();
		const matchesTerm = !term || claim.reference.toLowerCase().includes(term) || claim.claimant_name.toLowerCase().includes(term) || claim.claimant_email.toLowerCase().includes(term);
		return matchesStatus && matchesTerm;
	});
	async function updateClaim(id, patch, eventTitle) {
		await supabase.from("claims").update(patch).eq("id", id);
		await supabase.from("claim_events").insert({
			claim_id: id,
			title: eventTitle,
			status: patch.status ?? null
		});
		await queryClient.invalidateQueries({ queryKey: ["admin"] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminShell, {
		title: "Claims",
		subtitle: "Every recovery file, newest first.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-[minmax(0,1fr)_auto]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "relative block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: "Search reference, name or email",
					className: "w-full rounded-xl border border-border bg-card py-2.5 pl-9 pr-4 text-sm outline-none focus:border-primary"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				value: filter,
				onChange: (e) => setFilter(e.target.value),
				className: "rounded-xl border border-border bg-card px-4 py-2.5 text-sm outline-none focus:border-primary",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "all",
					children: "All statuses"
				}), CLAIM_STATUSES.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: status,
					children: statusMeta[status].label
				}, status))]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 space-y-3",
			children: [claims.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-2xl border border-border bg-card p-6 text-sm text-muted-foreground",
				children: "No claims match this view."
			}) : null, claims.map((claim) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-2xl border border-border bg-card p-5 shadow-soft",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm font-bold text-foreground",
									children: claim.claimant_name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-xs text-muted-foreground",
									children: claim.claimant_email
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-mono text-xs text-primary-deep",
									children: claim.reference
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "shrink-0 text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-extrabold text-foreground",
								children: money(Number(claim.amount), claim.currency)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `mt-1 inline-block rounded-full border px-2.5 py-1 text-[0.65rem] font-semibold ${statusMeta[claim.status].tone}`,
								children: statusMeta[claim.status].label
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setOpenId(openId === claim.id ? null : claim.id),
						className: "mt-3 text-xs font-semibold text-primary hover:underline",
						children: openId === claim.id ? "Hide case" : "Manage case"
					}),
					openId === claim.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-4 border-t border-border pt-4 lg:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-muted-foreground",
								children: "Member statement"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 whitespace-pre-line text-sm leading-relaxed text-foreground",
								children: claim.description || "No statement supplied."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-4 grid grid-cols-2 gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted-foreground",
									children: "Counterparty"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-medium text-foreground",
									children: claim.counterparty || "—"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted-foreground",
									children: "Incident date"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-medium text-foreground",
									children: claim.incident_date || "—"
								})] })]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-muted-foreground",
										children: "Status"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										value: claim.status,
										onChange: (e) => updateClaim(claim.id, { status: e.target.value }, `Status changed to ${statusMeta[e.target.value].label}`),
										className: "mt-1 w-full rounded-xl border border-border bg-background px-3 py-2 text-sm",
										children: CLAIM_STATUSES.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: status,
											children: statusMeta[status].label
										}, status))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-muted-foreground",
										children: "Recovered amount"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										defaultValue: Number(claim.recovered_amount ?? 0),
										onBlur: (e) => updateClaim(claim.id, { recovered_amount: Number(e.target.value) }, `Recovered amount set to ${money(Number(e.target.value), claim.currency)}`),
										className: "mt-1 w-full rounded-xl border border-border bg-background px-3 py-2 text-sm"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-muted-foreground",
										children: "Internal notes"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										rows: 3,
										defaultValue: claim.internal_notes ?? "",
										onBlur: (e) => updateClaim(claim.id, { internal_notes: e.target.value }, "Internal note updated"),
										className: "mt-1 w-full resize-y rounded-xl border border-border bg-background px-3 py-2 text-sm"
									})]
								})
							]
						})]
					}) : null
				]
			}, claim.id))]
		})]
	});
}
//#endregion
export { AdminClaims as component };
