import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { r as Route$12 } from "./router-R_2ReNa2.mjs";
import { F as LifeBuoy, O as Percent, R as House, V as GraduationCap, at as CalendarClock, it as Car } from "../_libs/lucide-react.mjs";
import { t as SiteShell } from "./SiteShell-D04mdz6U.mjs";
import { t as Reveal } from "./Reveal-ogx-87vx.mjs";
import { n as PageHero, t as CtaButton } from "./PageHero-BCURtH2L.mjs";
import { t as SectionHeading } from "./SectionHeading-Bpr_dcs8.mjs";
import { a as StatBand, n as FaqList, r as FeatureGrid, t as CtaBanner } from "./blocks-Bu9Yj3IW.mjs";
import { t as secure_banking_default } from "./secure-banking-Bp1Wmrmr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/loans-CMjkIfMq.js
var import_jsx_runtime = require_jsx_runtime();
function LoansPage() {
	const settings = Route$12.useLoaderData();
	const products = [
		{
			icon: LifeBuoy,
			name: "Claim Bridge",
			rate: "0%",
			term: "Until your claim resolves",
			body: "Borrow up to 40% of a verified open claim, interest free, repaid automatically from the recovery."
		},
		{
			icon: Percent,
			name: "Personal Loan",
			rate: `${settings["rate_personal_loan_apr"] ?? "6.90"}%`,
			term: "12 – 60 months",
			body: "Fixed APR from, no origination fee, and no penalty for settling the balance early."
		},
		{
			icon: Car,
			name: "Auto Loan",
			rate: `${settings["rate_auto_loan_apr"] ?? "5.25"}%`,
			term: "24 – 72 months",
			body: "New and used vehicles, with pre-approval that holds for thirty days while you shop."
		},
		{
			icon: House,
			name: "Home Loan",
			rate: `${settings["rate_mortgage_apr"] ?? "5.85"}%`,
			term: "10 – 30 years",
			body: "Fixed and tracker options with a named underwriter from application to completion."
		},
		{
			icon: GraduationCap,
			name: "Education Loan",
			rate: "4.40%",
			term: "Deferred to graduation",
			body: "Tuition and living costs, with repayments that only begin six months after you finish."
		},
		{
			icon: CalendarClock,
			name: "Hardship Line",
			rate: "0%",
			term: "Up to 6 months",
			body: "A short interest-free line for members in verified financial difficulty, assessed in 48 hours."
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHero, {
			image: secure_banking_default,
			eyebrow: "Borrowing",
			title: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "Credit that understands a pending claim is money too." }),
			intro: "When a refund is stuck in recovery, the bills do not pause. Claim Bridge lends against your verified claim at zero interest, and repays itself the day the funds land.",
			breadcrumb: "Loans",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaButton, {
				to: "/register",
				children: "Check your rate"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaButton, {
				to: "/how-it-works",
				variant: "ghost",
				children: "How bridging works"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBand, { stats: [
			{
				value: "0%",
				label: "Claim Bridge APR"
			},
			{
				value: `${settings["rate_personal_loan_apr"] ?? "6.90"}%`,
				label: "Personal loan from"
			},
			{
				value: "48 hrs",
				label: "Hardship decision"
			},
			{
				value: "$0",
				label: "Early settlement fee"
			}
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-background py-16 lg:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Lending",
					title: "Six ways to borrow, one set of published rates",
					intro: "Rates shown are the current member rates from our staff console. Your offer depends on affordability and credit assessment."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3",
					children: products.map((product, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: index * 80,
						direction: "scale",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "lift flex h-full flex-col rounded-3xl border border-border bg-card p-7 shadow-soft",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-soft text-primary-deep",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(product.icon, { className: "h-5.5 w-5.5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-5 text-lg font-bold text-foreground",
									children: product.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 flex items-baseline gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-3xl font-extrabold text-gradient-brand",
										children: product.rate
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-semibold text-muted-foreground",
										children: "APR from"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs font-semibold uppercase tracking-[0.12em] text-muted-foreground",
									children: product.term
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 flex-1 text-sm leading-relaxed text-muted-foreground",
									children: product.body
								})
							]
						})
					}, product.name))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeatureGrid, {
			eyebrow: "How we lend",
			title: "Underwriting you can actually follow",
			tone: "dark",
			columns: 3,
			items: [
				{
					icon: CalendarClock,
					title: "Decision in 24 hours",
					body: "Most applications are decided within one business day, with the reasons written out in plain language."
				},
				{
					icon: Percent,
					title: "No rate surprises",
					body: "The rate on your offer is the rate you sign. We do not re-price after acceptance."
				},
				{
					icon: LifeBuoy,
					title: "Missed payment support",
					body: "Tell us before it happens and we will restructure rather than default you."
				}
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqList, {
			eyebrow: "Borrowing FAQ",
			title: "Questions before you apply",
			items: [
				{
					q: "How much can Claim Bridge advance?",
					a: "Up to 40% of the verified claim value, capped at $10,000, once the claim has passed evidence review."
				},
				{
					q: "What if the claim recovers nothing?",
					a: "The bridge converts to a standard personal loan at your assessed rate, with the first three months interest free while we agree a plan."
				},
				{
					q: "Does checking my rate affect my credit?",
					a: "No. The initial rate check is a soft search that is not visible to other lenders."
				},
				{
					q: "Can I overpay?",
					a: "Yes, at any time and in any amount, with no early settlement charge on any Restitute loan."
				}
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBanner, {
			title: "See your rate without touching your credit file",
			body: "A soft check takes two minutes and shows the exact APR, term and monthly payment you would be offered.",
			primary: {
				label: "Check your rate",
				to: "/register"
			},
			secondary: {
				label: "Speak to lending",
				to: "/contact"
			}
		})
	] });
}
//#endregion
export { LoansPage as component };
