import { r as __toESM } from "../_runtime.mjs";
import { a as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { t as supabase } from "./client-C6aK345z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useAuth-Doc0DxK3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function useAuth() {
	const [session, setSession] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		const { data: sub } = supabase.auth.onAuthStateChange((_event, next) => {
			setSession(next);
			setLoading(false);
		});
		supabase.auth.getSession().then(({ data }) => {
			setSession(data.session);
			setLoading(false);
		});
		return () => sub.subscription.unsubscribe();
	}, []);
	return {
		session,
		user: session?.user ?? null,
		loading
	};
}
function useIsStaff() {
	const { user, loading } = useAuth();
	const [isStaff, setIsStaff] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let active = true;
		if (!user) {
			setIsStaff(loading ? null : false);
			return;
		}
		supabase.from("user_roles").select("role").eq("user_id", user.id).then(({ data }) => {
			if (!active) return;
			const roles = (data ?? []).map((row) => row.role);
			setIsStaff(roles.includes("admin") || roles.includes("staff"));
		});
		return () => {
			active = false;
		};
	}, [user, loading]);
	return {
		isStaff,
		loading: loading || isStaff === null,
		user
	};
}
//#endregion
export { useIsStaff as n, useAuth as t };
