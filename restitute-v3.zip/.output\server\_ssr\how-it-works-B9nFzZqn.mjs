import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { H as Gavel, K as FileText, _ as Send, i as Wallet, m as ShieldCheck, v as Search } from "../_libs/lucide-react.mjs";
import { t as SiteShell } from "./SiteShell-D04mdz6U.mjs";
import { t as Reveal } from "./Reveal-ogx-87vx.mjs";
import { n as PageHero, t as CtaButton } from "./PageHero-BCURtH2L.mjs";
import { t as SectionHeading } from "./SectionHeading-Bpr_dcs8.mjs";
import { a as StatBand, n as FaqList, t as CtaBanner } from "./blocks-Bu9Yj3IW.mjs";
import { i as RECOVERY_STAGES } from "./claims-B4EsFPLl.mjs";
import { t as secure_digital_default } from "./secure-digital-xe_ZiwrF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/how-it-works-B9nFzZqn.js
var import_jsx_runtime = require_jsx_runtime();
var icons = [
	FileText,
	Search,
	ShieldCheck,
	Send,
	Gavel,
	Wallet
];
var evidence = [
	"Bank or card statement showing the disputed line",
	"Any receipt, invoice or order confirmation",
	"Messages with the merchant, broker or counterparty",
	"The date and channel you first reported the loss",
	"Police or fraud-report reference, if one exists"
];
function HowItWorksPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHero, {
			image: secure_digital_default,
			eyebrow: "How recovery works",
			title: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "A claim is a process, not a phone call." }),
			intro: "Here is exactly what happens after you press submit — who touches your file, what we need from you, how long each stage usually takes, and when a fee applies.",
			breadcrumb: "How recovery works",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaButton, {
				to: "/claims/new",
				children: "File a claim now"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaButton, {
				to: "/claims/track",
				variant: "ghost",
				children: "Track an existing claim"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBand, { stats: [
			{
				value: "5 min",
				label: "Average intake time"
			},
			{
				value: "1 day",
				label: "To a named specialist"
			},
			{
				value: "19 days",
				label: "Median resolution"
			},
			{
				value: "0%",
				label: "Upfront fee"
			}
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-background py-16 lg:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-5xl px-4 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "The six stages",
					title: "Every claim follows the same published path",
					intro: "Your dashboard shows which of these six stages you are in, at all times."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "relative mt-14 space-y-6 border-l border-border pl-8",
					children: RECOVERY_STAGES.map((stage, index) => {
						const Icon = icons[index] ?? FileText;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: index * 80,
							direction: "right",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "lift relative rounded-3xl border border-border bg-card p-7 shadow-soft",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "absolute -left-[3.15rem] top-7 flex h-10 w-10 items-center justify-center rounded-full border-4 border-background bg-primary text-primary-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4.5 w-4.5" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs font-bold uppercase tracking-[0.18em] text-primary",
										children: ["Stage ", index + 1]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-2 text-xl font-bold text-foreground",
										children: stage.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-muted-foreground",
										children: stage.body
									})
								]
							})
						}, stage.title);
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-secondary py-16 lg:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl gap-10 px-4 sm:px-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					direction: "left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
						align: "left",
						eyebrow: "What to gather",
						title: "Evidence that makes a claim win",
						intro: "You do not need all of this to start — file first, and we will tell you which items actually matter for your case type."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-8 space-y-3",
						children: evidence.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
							delay: index * 70,
							as: "li",
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1.5 h-2 w-2 shrink-0 rounded-full bg-action" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm leading-relaxed text-foreground/85",
								children: item
							})]
						}, item))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					direction: "right",
					delay: 120,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-3xl border border-border bg-card p-8 shadow-soft",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-bold text-foreground",
								children: "What it costs"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted-foreground",
								children: "Nothing to open a claim. Nothing while it runs. If — and only if — money reaches your account, our success fee is deducted from the recovered amount."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
								className: "mt-6 space-y-4 border-t border-border pt-6 text-sm",
								children: [
									["Intake and assessment", "Free"],
									["Evidence review and filing", "Free"],
									["Ombudsman escalation", "Free"],
									["Success fee", "15% of recovered funds"],
									["If nothing is recovered", "$0"]
								].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted-foreground",
										children: label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-bold text-foreground",
										children: value
									})]
								}, label))
							})
						]
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqList, {
			eyebrow: "Common questions",
			title: "Before you file",
			items: [
				{
					q: "Do I need an account with Restitute to claim?",
					a: "No. Anyone can file a claim and track it with a reference code. Opening a member account simply gives you a dashboard, document uploads and messaging on the file."
				},
				{
					q: "How far back can a claim go?",
					a: "Most card scheme disputes run to 120 days from the transaction or the expected delivery date, and regulated payment claims often stretch to six years. File anyway — our intake team checks the applicable window for you."
				},
				{
					q: "Will claiming hurt my credit?",
					a: "No. A refund claim is a dispute against a payment, not a credit application, and it is not reported to credit bureaus."
				},
				{
					q: "What if the counterparty refuses?",
					a: "We escalate. Depending on the case that means the scheme's arbitration process, the financial ombudsman or the regulator — all included, at no extra cost."
				},
				{
					q: "How do I get the money?",
					a: "Recovered funds are paid to your nominated account, usually within two working days of the counterparty releasing them, with a written outcome letter attached to your file."
				}
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBanner, {
			title: "Five minutes now, or another month of waiting",
			body: "Filing costs nothing and commits you to nothing. Most members are matched to a specialist by the next business day.",
			primary: {
				label: "Request a refund",
				to: "/claims/new"
			},
			secondary: {
				label: "Ask a question first",
				to: "/contact"
			}
		})
	] });
}
//#endregion
export { HowItWorksPage as component };
