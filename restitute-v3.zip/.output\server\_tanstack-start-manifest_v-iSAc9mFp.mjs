//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-iSAc9mFp.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/admin",
			"/app",
			"/business-banking",
			"/cards",
			"/contact",
			"/dashboard",
			"/forgot-password",
			"/grants",
			"/how-it-works",
			"/loans",
			"/login",
			"/personal-banking",
			"/privacy",
			"/register",
			"/reset-password",
			"/terms",
			"/claims/new",
			"/claims/track"
		],
		preloads: [
			"/assets/index-P8QXxMCQ.js",
			"/assets/useStore-B9WcefOa.js",
			"/assets/link-XeYqOrFb.js",
			"/assets/createServerFn-cfNI5Xxw.js",
			"/assets/matchContext-BRN1Rnka.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-P8QXxMCQ.js"
		} }]
	},
	"/": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BzYvAYi4.js",
			"/assets/createLucideIcon-DkWbMhVc.js",
			"/assets/arrow-right-xUn83Vfs.js",
			"/assets/bell-Bd7wWMvv.js",
			"/assets/check-jj-1xQqf.js",
			"/assets/SiteShell-DIy__-3_.js",
			"/assets/clock-3-tkYi195m.js",
			"/assets/credit-card-dvUeqdRd.js",
			"/assets/hand-coins-BKB5jhnV.js",
			"/assets/life-buoy-CnHXK-3z.js",
			"/assets/map-pin-C8l1jbxq.js",
			"/assets/piggy-bank-BfIz-O6f.js",
			"/assets/shield-check-CKqJmURg.js",
			"/assets/Reveal-CsE1F7EZ.js",
			"/assets/SectionHeading-fmoyDt_U.js",
			"/assets/team-office-BqXICvdz.js",
			"/assets/claims-7V0aedky.js",
			"/assets/format-B6qeKsoW.js",
			"/assets/ClaimLookup-XmOi4OJ8.js"
		]
	},
	"/about": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-CEvc5lPE.js",
			"/assets/createLucideIcon-DkWbMhVc.js",
			"/assets/SiteShell-DIy__-3_.js",
			"/assets/scale-Chnt1ket.js",
			"/assets/users-P61xlGv8.js",
			"/assets/Reveal-CsE1F7EZ.js",
			"/assets/PageHero-Chl8O1C7.js",
			"/assets/SectionHeading-fmoyDt_U.js",
			"/assets/blocks-Cj5_MwKD.js",
			"/assets/team-office-BqXICvdz.js"
		]
	},
	"/admin": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/admin.tsx",
		children: [
			"/admin/claims",
			"/admin/members",
			"/admin/settings",
			"/admin/"
		],
		preloads: [
			"/assets/admin-LJdym-AG.js",
			"/assets/loader-circle-Bek7o8H0.js",
			"/assets/shield-check-CKqJmURg.js",
			"/assets/useAuth-CuHPcBTx.js"
		]
	},
	"/app": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/app.tsx",
		children: void 0,
		preloads: [
			"/assets/app-1tpzRcbt.js",
			"/assets/createLucideIcon-DkWbMhVc.js",
			"/assets/bell-Bd7wWMvv.js",
			"/assets/SiteShell-DIy__-3_.js",
			"/assets/send-CtOtihK0.js",
			"/assets/Reveal-CsE1F7EZ.js",
			"/assets/PageHero-Chl8O1C7.js",
			"/assets/SectionHeading-fmoyDt_U.js",
			"/assets/blocks-Cj5_MwKD.js"
		]
	},
	"/business-banking": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/business-banking.tsx",
		children: void 0,
		preloads: [
			"/assets/business-banking-DAb9Dp-z.js",
			"/assets/createLucideIcon-DkWbMhVc.js",
			"/assets/SiteShell-DIy__-3_.js",
			"/assets/gavel-DcBTAS09.js",
			"/assets/Reveal-CsE1F7EZ.js",
			"/assets/PageHero-Chl8O1C7.js",
			"/assets/SectionHeading-fmoyDt_U.js",
			"/assets/blocks-Cj5_MwKD.js"
		]
	},
	"/cards": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/cards.tsx",
		children: void 0,
		preloads: [
			"/assets/cards-DImocxg3.js",
			"/assets/createLucideIcon-DkWbMhVc.js",
			"/assets/SiteShell-DIy__-3_.js",
			"/assets/credit-card-dvUeqdRd.js",
			"/assets/lock-Bk53cM7B.js",
			"/assets/Reveal-CsE1F7EZ.js",
			"/assets/PageHero-Chl8O1C7.js",
			"/assets/SectionHeading-fmoyDt_U.js",
			"/assets/blocks-Cj5_MwKD.js"
		]
	},
	"/contact": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-D7eN_E_u.js",
			"/assets/SiteShell-DIy__-3_.js",
			"/assets/clock-3-tkYi195m.js",
			"/assets/map-pin-C8l1jbxq.js",
			"/assets/PageHero-Chl8O1C7.js",
			"/assets/blocks-Cj5_MwKD.js",
			"/assets/ClaimLookup-XmOi4OJ8.js"
		]
	},
	"/dashboard": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-H0jCPXuu.js",
			"/assets/log-out-2cBCrz1s.js",
			"/assets/arrow-right-xUn83Vfs.js",
			"/assets/SiteShell-DIy__-3_.js",
			"/assets/loader-circle-Bek7o8H0.js",
			"/assets/useAuth-CuHPcBTx.js",
			"/assets/claims-7V0aedky.js",
			"/assets/format-B6qeKsoW.js"
		]
	},
	"/forgot-password": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/forgot-password.tsx",
		children: void 0,
		preloads: [
			"/assets/forgot-password-B1qaXp5v.js",
			"/assets/loader-circle-Bek7o8H0.js",
			"/assets/AuthCard-BIwfwLy6.js"
		]
	},
	"/grants": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/grants.tsx",
		children: void 0,
		preloads: [
			"/assets/grants-B0ooabgh.js",
			"/assets/createLucideIcon-DkWbMhVc.js",
			"/assets/SiteShell-DIy__-3_.js",
			"/assets/hand-coins-BKB5jhnV.js",
			"/assets/house-CnSKq-v7.js",
			"/assets/users-P61xlGv8.js",
			"/assets/Reveal-CsE1F7EZ.js",
			"/assets/PageHero-Chl8O1C7.js",
			"/assets/SectionHeading-fmoyDt_U.js",
			"/assets/blocks-Cj5_MwKD.js",
			"/assets/format-B6qeKsoW.js"
		]
	},
	"/how-it-works": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/how-it-works.tsx",
		children: void 0,
		preloads: [
			"/assets/how-it-works-BaP2OAuB.js",
			"/assets/createLucideIcon-DkWbMhVc.js",
			"/assets/SiteShell-DIy__-3_.js",
			"/assets/gavel-DcBTAS09.js",
			"/assets/search-DXYgOeO2.js",
			"/assets/send-CtOtihK0.js",
			"/assets/shield-check-CKqJmURg.js",
			"/assets/secure-digital-DqBI9dpa.js",
			"/assets/Reveal-CsE1F7EZ.js",
			"/assets/PageHero-Chl8O1C7.js",
			"/assets/SectionHeading-fmoyDt_U.js",
			"/assets/blocks-Cj5_MwKD.js",
			"/assets/claims-7V0aedky.js"
		]
	},
	"/loans": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-cEJ03XTX.js",
			"/assets/createLucideIcon-DkWbMhVc.js",
			"/assets/SiteShell-DIy__-3_.js",
			"/assets/house-CnSKq-v7.js",
			"/assets/life-buoy-CnHXK-3z.js",
			"/assets/Reveal-CsE1F7EZ.js",
			"/assets/PageHero-Chl8O1C7.js",
			"/assets/SectionHeading-fmoyDt_U.js",
			"/assets/blocks-Cj5_MwKD.js",
			"/assets/secure-banking-C-fJMjdg.js"
		]
	},
	"/login": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-uxv1Qh3A.js",
			"/assets/loader-circle-Bek7o8H0.js",
			"/assets/lock-Bk53cM7B.js",
			"/assets/map-pin-C8l1jbxq.js",
			"/assets/scale-Chnt1ket.js",
			"/assets/shield-check-CKqJmURg.js",
			"/assets/sun-moon-BM1JZlXF.js",
			"/assets/AuthCard-BIwfwLy6.js"
		]
	},
	"/personal-banking": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/personal-banking.tsx",
		children: void 0,
		preloads: [
			"/assets/personal-banking-CZ0Wwpo7.js",
			"/assets/createLucideIcon-DkWbMhVc.js",
			"/assets/bell-Bd7wWMvv.js",
			"/assets/SiteShell-DIy__-3_.js",
			"/assets/piggy-bank-BfIz-O6f.js",
			"/assets/secure-digital-DqBI9dpa.js",
			"/assets/Reveal-CsE1F7EZ.js",
			"/assets/PageHero-Chl8O1C7.js",
			"/assets/SectionHeading-fmoyDt_U.js",
			"/assets/blocks-Cj5_MwKD.js"
		]
	},
	"/privacy": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/privacy.tsx",
		children: void 0,
		preloads: [
			"/assets/privacy-DdD6DNMs.js",
			"/assets/SiteShell-DIy__-3_.js",
			"/assets/PageHero-Chl8O1C7.js",
			"/assets/blocks-Cj5_MwKD.js"
		]
	},
	"/register": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/register.tsx",
		children: void 0,
		preloads: [
			"/assets/register-Bf7f1RDB.js",
			"/assets/loader-circle-Bek7o8H0.js",
			"/assets/sun-moon-BM1JZlXF.js",
			"/assets/team-office-BqXICvdz.js",
			"/assets/AuthCard-BIwfwLy6.js"
		]
	},
	"/reset-password": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-Mr41Dlc8.js",
			"/assets/loader-circle-Bek7o8H0.js",
			"/assets/AuthCard-BIwfwLy6.js"
		]
	},
	"/terms": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/terms.tsx",
		children: void 0,
		preloads: [
			"/assets/terms-CWXBfa70.js",
			"/assets/SiteShell-DIy__-3_.js",
			"/assets/PageHero-Chl8O1C7.js",
			"/assets/blocks-Cj5_MwKD.js",
			"/assets/secure-banking-C-fJMjdg.js"
		]
	},
	"/admin/claims": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/admin.claims.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.claims-BTZ35Tto.js",
			"/assets/log-out-2cBCrz1s.js",
			"/assets/AdminShell-DuxBSX8F.js",
			"/assets/search-DXYgOeO2.js",
			"/assets/claims-7V0aedky.js",
			"/assets/format-B6qeKsoW.js"
		]
	},
	"/admin/members": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/admin.members.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.members-BmTe4Zef.js",
			"/assets/log-out-2cBCrz1s.js",
			"/assets/AdminShell-DuxBSX8F.js"
		]
	},
	"/admin/settings": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/admin.settings.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.settings-BwUmLUZd.js",
			"/assets/log-out-2cBCrz1s.js",
			"/assets/AdminShell-DuxBSX8F.js"
		]
	},
	"/claims/new": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/claims.new.tsx",
		children: void 0,
		preloads: [
			"/assets/claims.new-C8vHnTra.js",
			"/assets/check-jj-1xQqf.js",
			"/assets/SiteShell-DIy__-3_.js",
			"/assets/loader-circle-Bek7o8H0.js",
			"/assets/shield-check-CKqJmURg.js",
			"/assets/utils-Dk_44zMo.js",
			"/assets/PageHero-Chl8O1C7.js",
			"/assets/claims-7V0aedky.js"
		]
	},
	"/claims/track": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/claims.track.tsx",
		children: void 0,
		preloads: [
			"/assets/claims.track-WK8Dngrk.js",
			"/assets/SiteShell-DIy__-3_.js",
			"/assets/Reveal-CsE1F7EZ.js",
			"/assets/PageHero-Chl8O1C7.js",
			"/assets/blocks-Cj5_MwKD.js",
			"/assets/claims-7V0aedky.js",
			"/assets/ClaimLookup-XmOi4OJ8.js"
		]
	},
	"/admin/": {
		filePath: "D:/Freelancing/Restitute banking/Restitute Banking/src/routes/admin.index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.index-C8AdA3_T.js",
			"/assets/log-out-2cBCrz1s.js",
			"/assets/AdminShell-DuxBSX8F.js",
			"/assets/claims-7V0aedky.js",
			"/assets/format-B6qeKsoW.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
