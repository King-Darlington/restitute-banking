import { i as require_jsx_runtime, r as useQueryClient, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { t as supabase } from "./client-C6aK345z.mjs";
import { n as AdminShell, t as AdminCard } from "./AdminShell-DfqDGwjx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.settings-BHenvuzA.js
var import_jsx_runtime = require_jsx_runtime();
function AdminSettings() {
	const queryClient = useQueryClient();
	const { data } = useQuery({
		queryKey: ["admin", "settings"],
		queryFn: async () => {
			const { data: rows } = await supabase.from("site_settings").select("*").order("grouping").order("label");
			return rows ?? [];
		}
	});
	const rows = data ?? [];
	const groups = [...new Set(rows.map((row) => row.grouping))];
	async function save(key, value) {
		await supabase.from("site_settings").update({ value }).eq("key", key);
		await queryClient.invalidateQueries({ queryKey: ["admin", "settings"] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminShell, {
		title: "Settings",
		subtitle: "Numbers and contact details published across the public site.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminCard, {
				title: group,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3",
					children: rows.filter((row) => row.grouping === group).map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium text-muted-foreground",
							children: row.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							defaultValue: row.value,
							onBlur: (e) => save(row.key, e.target.value),
							className: "mt-1 w-full rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
						})]
					}, row.key))
				})
			}, group))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-xs text-muted-foreground",
			children: "Changes save when you leave a field and appear on the public site immediately."
		})]
	});
}
//#endregion
export { AdminSettings as component };
