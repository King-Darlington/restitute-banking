import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/client-C6aK345z.js
function isNewSupabaseApiKey(value) {
	return value.startsWith("sb_publishable_") || value.startsWith("sb_secret_");
}
function createSupabaseFetch(supabaseKey) {
	return (input, init) => {
		const headers = new Headers(typeof Request !== "undefined" && input instanceof Request ? input.headers : void 0);
		if (init?.headers) new Headers(init.headers).forEach((value, key) => headers.set(key, value));
		if (isNewSupabaseApiKey(supabaseKey) && headers.get("Authorization") === `Bearer ${supabaseKey}`) headers.delete("Authorization");
		headers.set("apikey", supabaseKey);
		return fetch(input, {
			...init,
			headers
		});
	};
}
function createFallbackSupabaseClient() {
	const error = /* @__PURE__ */ new Error("Supabase is not configured. Set VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY for auth and database features.");
	const response = Promise.resolve({
		data: null,
		error
	});
	const chainable = {
		select: () => chainable,
		insert: () => chainable,
		update: () => chainable,
		delete: () => chainable,
		upsert: () => chainable,
		eq: () => chainable,
		order: () => chainable,
		limit: () => chainable,
		in: () => chainable,
		maybeSingle: () => chainable,
		single: () => chainable,
		returns: () => chainable,
		then: (resolve) => response.then(resolve),
		catch: (resolve) => response.catch(resolve)
	};
	return new Proxy({
		auth: {
			onAuthStateChange: () => ({
				data: { subscription: { unsubscribe: () => {} } },
				error: null
			}),
			getSession: () => Promise.resolve({
				data: { session: null },
				error: null
			}),
			signInWithPassword: () => response,
			signUp: () => response,
			signOut: () => Promise.resolve({
				data: null,
				error: null
			}),
			resetPasswordForEmail: () => response,
			updateUser: () => response
		},
		from: () => chainable,
		rpc: () => response,
		storage: { from: () => ({
			createBucket: () => response,
			list: () => response
		}) }
	}, { get(target, prop) {
		if (prop in target) return target[prop];
		return () => response;
	} });
}
function createSupabaseClient() {
	const SUPABASE_URL = {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_SUPABASE_PROJECT_ID": "dkxrgiylxekhtyftuchc",
		"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_poPVETN2ZYANmWCi8ZtkNg_XsFQ6hQC",
		"VITE_SUPABASE_URL": "https://dkxrgiylxekhtyftuchc.supabase.co"
	}["VITE_SUPABASE_URL"] || process.env["SUPABASE_URL"];
	const SUPABASE_PUBLISHABLE_KEY = {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_SUPABASE_PROJECT_ID": "dkxrgiylxekhtyftuchc",
		"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_poPVETN2ZYANmWCi8ZtkNg_XsFQ6hQC",
		"VITE_SUPABASE_URL": "https://dkxrgiylxekhtyftuchc.supabase.co"
	}["VITE_SUPABASE_PUBLISHABLE_KEY"] || process.env["SUPABASE_PUBLISHABLE_KEY"];
	if (!SUPABASE_URL || !SUPABASE_PUBLISHABLE_KEY) {
		const message = `Missing Supabase environment variable(s): ${[...!SUPABASE_URL ? ["SUPABASE_URL"] : [], ...!SUPABASE_PUBLISHABLE_KEY ? ["SUPABASE_PUBLISHABLE_KEY"] : []].join(", ")}.`;
		console.warn(`[Supabase] ${message}`);
		return createFallbackSupabaseClient();
	}
	return createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
		global: { fetch: createSupabaseFetch(SUPABASE_PUBLISHABLE_KEY) },
		auth: {
			storage: typeof window !== "undefined" ? localStorage : void 0,
			persistSession: true,
			autoRefreshToken: true
		}
	});
}
var _supabase;
var supabase = new Proxy({}, { get(_, prop, receiver) {
	if (!_supabase) _supabase = createSupabaseClient();
	return Reflect.get(_supabase, prop, receiver);
} });
//#endregion
export { supabase as t };
