import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Reveal } from "./Reveal-ogx-87vx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/SectionHeading-Bpr_dcs8.js
var import_jsx_runtime = require_jsx_runtime();
function SectionHeading({ eyebrow, title, intro, align = "center", tone = "light" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("max-w-3xl", align === "center" && "mx-auto text-center"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("inline-flex items-center gap-2 rounded-full border px-3 py-1 text-[0.68rem] font-semibold uppercase tracking-[0.2em] animate-pulse", tone === "dark" ? "border-ink-foreground/20 bg-ink-foreground/5 text-ink-foreground/75" : "border-primary/20 bg-primary-soft text-primary-deep"),
				children: eyebrow
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 90,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: cn("mt-5 text-3xl font-extrabold leading-tight sm:text-4xl", tone === "dark" ? "text-ink-foreground" : "text-foreground"),
					children: title
				})
			}),
			intro ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 170,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("mt-4 text-base leading-relaxed", tone === "dark" ? "text-ink-foreground/70" : "text-muted-foreground"),
					children: intro
				})
			}) : null
		]
	});
}
//#endregion
export { SectionHeading as t };
