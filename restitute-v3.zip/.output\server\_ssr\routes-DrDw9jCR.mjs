import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Route$23 } from "./router-R_2ReNa2.mjs";
import { A as MapPin, B as HandCoins, C as Quote, D as PhoneCall, F as LifeBuoy, L as Landmark, Q as Clock3, T as PiggyBank, U as Gauge, Y as CreditCard, Z as Clock, j as Mail, lt as Bell, m as ShieldCheck, mt as ArrowRight, pt as ArrowUpRight, r as WifiOff, s as TrendingUp, st as Briefcase, tt as Check, u as Star, ut as Banknote } from "../_libs/lucide-react.mjs";
import { t as SiteShell } from "./SiteShell-D04mdz6U.mjs";
import { t as Reveal } from "./Reveal-ogx-87vx.mjs";
import { t as SectionHeading } from "./SectionHeading-Bpr_dcs8.mjs";
import { t as team_office_default } from "./team-office-DtTFGU89.mjs";
import { i as RECOVERY_STAGES } from "./claims-B4EsFPLl.mjs";
import { t as compactMoney } from "./format--W0ZbsWV.mjs";
import { t as ClaimLookup } from "./ClaimLookup-HT1xnjmb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DrDw9jCR.js
var import_jsx_runtime = require_jsx_runtime();
var hero_recovery_default = "/assets/hero-recovery-C1nrZNmz.jpg";
function Hero({ settings }) {
	const recovered = compactMoney(Number(settings["recovered_total"] ?? 0));
	const resolved = Number(settings["claims_resolved"] ?? 0).toLocaleString("en-US");
	const stats = [
		{
			icon: Landmark,
			title: "Routing number",
			body: settings["routing_number"] ?? "251480576",
			accent: "bg-primary/15 text-primary"
		},
		{
			icon: Clock3,
			title: "Recovery desk",
			body: "Mon–Fri 8AM–8PM · Sat 9AM–1PM",
			accent: "bg-action/15 text-action"
		},
		{
			icon: ShieldCheck,
			title: "24/7 fraud line",
			body: settings["support_phone"] ?? "1-800-RESTITUTE",
			accent: "bg-violet-500/15 text-violet-300"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "surface-ink relative min-h-screen overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-0 lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: hero_recovery_default,
					alt: "",
					"aria-hidden": "true",
					className: "h-full w-full object-cover object-center"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-ink/92 via-ink/88 to-ink/95" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-grid text-ink-foreground/40 opacity-20" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "float-slower pointer-events-none absolute -left-24 top-10 h-72 w-72 rounded-full blur-3xl",
				style: {
					background: "var(--gradient-brand)",
					opacity: .28
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "float-slow pointer-events-none absolute -bottom-28 right-10 h-80 w-80 rounded-full blur-3xl",
				style: {
					background: "var(--gradient-action)",
					opacity: .2
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto grid max-w-7xl items-center gap-14 px-4 py-16 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:py-24",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-2 rounded-full border border-action/30 bg-action/10 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] text-action",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-3.5 w-3.5" }), "Refund recovery, done properly"]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 90,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-6 text-4xl font-extrabold leading-[1.05] text-ink-foreground sm:text-5xl lg:text-[3.65rem]",
							children: ["Money that left wrongly", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-action",
								children: "belongs back with you."
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 170,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-xl text-base leading-relaxed text-ink-foreground/75 sm:text-lg",
							children: "Restitute Banking pairs everyday accounts with a dedicated recovery desk. File a claim in five minutes, watch every stage in real time, and pay nothing until your funds are actually returned."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 250,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-9 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/claims/new",
								className: "shine pulse-action inline-flex items-center gap-2 rounded-xl bg-action px-6 py-3.5 text-sm font-semibold text-action-foreground transition-transform hover:-translate-y-0.5",
								children: ["Request a refund", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/claims/track",
								className: "inline-flex items-center gap-2 rounded-xl border border-ink-foreground/25 px-6 py-3.5 text-sm font-semibold text-ink-foreground transition-colors hover:bg-ink-foreground/10",
								children: "Track an existing claim"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 330,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
							className: "mt-12 grid max-w-lg grid-cols-3 gap-6 border-t border-ink-foreground/15 pt-8",
							children: [
								{
									value: recovered,
									label: "Recovered for members"
								},
								{
									value: `${resolved}+`,
									label: "Claims resolved"
								},
								{
									value: `${settings["recovery_rate"] ?? "87"}%`,
									label: "Success rate"
								}
							].map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-2xl font-extrabold text-ink-foreground sm:text-3xl",
								children: stat.value
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-xs leading-snug text-ink-foreground/60",
								children: stat.label
							})] }, stat.label))
						})
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					direction: "scale",
					delay: 200,
					className: "relative hidden lg:block",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative overflow-hidden rounded-3xl border border-ink-foreground/15 shadow-lift",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: hero_recovery_default,
									alt: "A Restitute Banking member reviewing a completed refund on a laptop",
									width: 1600,
									height: 1104,
									className: "h-[22rem] w-full object-cover sm:h-[26rem]"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/15 to-transparent" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute inset-x-4 bottom-4 rounded-2xl border border-white/15 bg-ink/70 p-4 backdrop-blur-xl",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-xs text-ink-foreground/70",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono tracking-widest",
												children: "CLAIM RB-104217"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full bg-action/20 px-2 py-0.5 font-semibold text-action",
												children: "Funds returned"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-2xl font-extrabold text-ink-foreground",
											children: "$8,420.00"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-3 h-1.5 overflow-hidden rounded-full bg-ink-foreground/15",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-full rounded-full bg-action" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-[0.7rem] text-ink-foreground/60",
											children: "Recovered in 14 days · Unauthorised card transaction"
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "float-slow absolute -left-4 top-8 hidden rounded-2xl border border-white/15 bg-ink/75 px-4 py-3 backdrop-blur-xl lg:block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-2 text-xs font-semibold text-ink-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "h-4 w-4 text-action" }),
									"Avg. ",
									settings["avg_days"] ?? "19",
									" days to resolution"
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "float-slower absolute -right-4 bottom-24 hidden rounded-2xl border border-white/15 bg-ink/75 px-4 py-3 backdrop-blur-xl lg:block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-2 text-xs font-semibold text-ink-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-4 w-4 text-action" }), "No win, no fee"]
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute bottom-6 left-1/2 z-10 -translate-x-1/2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-10 w-6 items-start justify-center rounded-full border border-white/80",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 inline-block h-2.5 w-2.5 rounded-full bg-white animate-bounce" })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative border-t border-ink-foreground/12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid max-w-7xl gap-px px-4 sm:px-6 md:grid-cols-3",
					children: stats.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						delay: index * 90,
						className: "group flex items-center gap-4 rounded-3xl bg-ink/95 p-6 transition-transform duration-300 hover:-translate-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `flex h-11 w-11 items-center justify-center rounded-xl ${item.accent}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "h-5 w-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[0.68rem] font-semibold uppercase tracking-[0.18em] text-ink-foreground/50",
							children: item.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-sm font-semibold text-ink-foreground",
							children: item.body
						})] })]
					}, item.title))
				})
			})
		]
	});
}
function RateBoard({ settings }) {
	const rates = [
		{
			value: `${settings["rate_savings_apy"] ?? "3.75"}%`,
			unit: "APY*",
			caption: "High yield savings",
			note: "Recovered funds start earning the day they land.",
			tag: "Featured"
		},
		{
			value: `${settings["rate_certificate_apy"] ?? "3.65"}%`,
			unit: "APY*",
			caption: "18 month certificate",
			note: "Lock a rate while your claim is in negotiation.",
			tag: "Savings"
		},
		{
			value: `${settings["rate_card_apr"] ?? "4.00"}%`,
			unit: "APR*",
			caption: "Restitute credit card",
			note: "Freeze, dispute and refund from one screen.",
			tag: "Credit"
		},
		{
			value: `${settings["rate_loan_apr"] ?? "15.49"}%`,
			unit: "APR*",
			caption: "Standard loan rate",
			note: "Bridge finance against an approved claim.",
			tag: "Lending"
		}
	];
	const ticker = [
		"No upfront fees on any recovery claim",
		"Median resolution 19 days",
		"Regulated dispute filing under scheme rules",
		"Ombudsman escalation included",
		"Funds insured to the federal limit"
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden bg-background py-16 lg:py-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-mesh opacity-70" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto max-w-7xl px-4 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
						eyebrow: "Restitute rates",
						title: "Rates published in the open, updated by our team",
						intro: "Every figure below is managed from our staff console, so what you see here is what our specialists see."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4",
						children: rates.map((rate, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: index * 90,
							direction: "scale",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "lift group relative h-full overflow-hidden rounded-3xl border border-border bg-card p-6 shadow-soft transition-all duration-300 hover:-translate-y-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "absolute right-5 top-5 rounded-full bg-primary-soft px-2.5 py-1 text-[0.62rem] font-bold uppercase tracking-[0.14em] text-primary-deep",
										children: rate.tag
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-baseline gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-4xl font-extrabold text-gradient-brand",
											children: rate.value
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-semibold text-muted-foreground",
											children: rate.unit
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-4 text-sm font-bold uppercase tracking-[0.12em] text-foreground",
										children: rate.caption
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-muted-foreground",
										children: rate.note
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-6 block h-1 w-12 rounded-full bg-primary transition-all duration-500 group-hover:w-20" })
								]
							})
						}, rate.caption))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-center text-xs text-muted-foreground",
						children: "*Annual Percentage Yield / Rate. Rates are subject to change. Terms and conditions apply."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mt-14 overflow-hidden border-y border-border bg-card/70 py-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "marquee-track flex w-max gap-10 whitespace-nowrap",
					children: [...ticker, ...ticker].map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-3 text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-action" }), item]
					}, `${item}-${index}`))
				})
			})
		]
	});
}
function Recovery() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "relative overflow-hidden bg-secondary py-16 lg:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "How recovery works",
					title: "Six stages. No black box.",
					intro: "Most recovery services go quiet after you sign. We publish the stage your claim sits in, who owns it, and what happens next."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3",
					children: RECOVERY_STAGES.map((stage, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: index * 80,
						direction: index % 2 ? "right" : "left",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "lift group relative h-full rounded-3xl border border-border bg-card p-7 shadow-soft transition-all duration-300 hover:-translate-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex h-11 w-11 items-center justify-center rounded-2xl bg-primary text-sm font-extrabold text-primary-foreground shadow-[0_0_12px_var(--primary_/_0.3)]",
									children: String(index + 1).padStart(2, "0")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-5 text-lg font-bold text-foreground",
									children: stage.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-muted-foreground",
									children: stage.body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute bottom-6 right-6 text-primary opacity-0 transition-all duration-300 group-hover:opacity-100",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "h-5 w-5" })
								})
							]
						})
					}, stage.title))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: 120,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 flex justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/how-it-works",
							className: "inline-flex items-center gap-2 rounded-xl border border-primary/30 bg-card px-6 py-3 text-sm font-semibold text-primary-deep shadow-soft transition-all hover:-translate-y-0.5 hover:bg-primary-soft",
							children: ["Read the full recovery playbook", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "h-4 w-4" })]
						})
					})
				})
			]
		})
	});
}
var services = [
	{
		icon: LifeBuoy,
		title: "Refund recovery",
		body: "Our core desk. Unauthorised payments, undelivered goods, wire fraud and broker losses, filed under the right scheme.",
		to: "/claims/new",
		span: "lg:col-span-2 lg:row-span-2",
		feature: true
	},
	{
		icon: PiggyBank,
		title: "Deposit accounts",
		body: "High-yield savings and everyday checking with instant dispute buttons on every line.",
		to: "/personal-banking"
	},
	{
		icon: CreditCard,
		title: "Cards",
		body: "Freeze, unfreeze and dispute in one tap, with chargeback paperwork prefilled.",
		to: "/cards"
	},
	{
		icon: Banknote,
		title: "Loans & credit",
		body: "Bridge finance against an approved claim so life does not stall while we recover.",
		to: "/loans"
	},
	{
		icon: Briefcase,
		title: "Business banking",
		body: "Merchant-side chargeback defence, evidence packs and settlement reporting.",
		to: "/business-banking"
	},
	{
		icon: HandCoins,
		title: "Grants & aid",
		body: "Hardship grants for members waiting on a recovery, paid within five working days.",
		to: "/grants"
	}
];
function Services() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "surface-ink relative overflow-hidden py-16 lg:py-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-grid text-ink-foreground/40 opacity-20" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto max-w-7xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "Our services",
				title: "How can we help you today?",
				intro: "A full-service bank wrapped around a recovery desk — so the institution holding your money is the same one fighting to get it back.",
				tone: "dark"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-4",
				children: services.map((service, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: index * 70,
					direction: "scale",
					className: service.span ?? "",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: service.to,
						className: `lift group relative overflow-hidden flex h-full flex-col rounded-3xl border border-ink-foreground/12 bg-ink-foreground/[0.06] p-7 backdrop-blur-sm transition-all duration-300 hover:-translate-y-2 hover:border-action/40 ${service.feature ? "justify-between" : ""}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 transition-transform duration-700 group-hover:translate-x-full group-hover:opacity-100" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex h-12 w-12 items-center justify-center rounded-2xl bg-action/15 text-action transition-transform duration-500 group-hover:scale-110",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(service.icon, { className: "h-6 w-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: service.feature ? "mt-10" : "mt-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: `font-bold text-ink-foreground ${service.feature ? "text-2xl" : "text-lg"}`,
										children: service.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `mt-2 leading-relaxed text-ink-foreground/70 ${service.feature ? "text-base" : "text-sm"}`,
										children: service.body
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mt-5 inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-[0.16em] text-action",
										children: ["Explore", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "transition-transform duration-300 group-hover:translate-x-1",
											children: "→"
										})]
									})
								]
							})
						]
					})
				}, service.title))
			})]
		})]
	});
}
var points = [
	"No upfront fee — our fee comes out of what we recover, never out of your pocket",
	"A named specialist and a written plan within one business day",
	"Every filing deadline tracked for you, including ombudsman windows",
	"Plain-English updates at each stage, never legal fog"
];
function Promise$1() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "relative overflow-hidden bg-background py-16 lg:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl items-center gap-14 px-4 sm:px-6 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				direction: "left",
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative overflow-hidden rounded-3xl border border-border shadow-lift",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: team_office_default,
						alt: "Restitute Banking recovery specialists reviewing a claim file together",
						loading: "lazy",
						width: 1600,
						height: 1008,
						className: "h-[24rem] w-full object-cover"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute -bottom-6 left-6 right-6 rounded-2xl border border-border bg-card p-5 shadow-lift sm:right-auto sm:w-72",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground",
							children: "Recovery guarantee"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-2xl font-extrabold text-foreground",
							children: "$0 if we fail"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs leading-relaxed text-muted-foreground",
							children: "You are only ever invoiced from funds that actually reach your account."
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				direction: "right",
				delay: 120,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "inline-flex items-center gap-2 rounded-full border border-action/25 bg-action-soft px-3 py-1 text-[0.68rem] font-semibold uppercase tracking-[0.2em] text-action",
						children: "The Restitute promise"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 text-3xl font-extrabold leading-tight text-foreground sm:text-4xl",
						children: "Built for the moment you realise the money is gone."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-base leading-relaxed text-muted-foreground",
						children: "Losing money is stressful enough without a maze of hold music and reference numbers. We replaced all of it with one file, one specialist and one honest status line you can read at any hour."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-8 space-y-4",
						children: points.map((point, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
							delay: index * 80,
							as: "li",
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-action/15 text-action",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm leading-relaxed text-foreground/85",
								children: point
							})]
						}, point))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/claims/new",
							className: "shine rounded-xl bg-action px-6 py-3.5 text-sm font-semibold text-action-foreground shadow-soft transition-transform hover:-translate-y-0.5",
							children: "Start my claim"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/register",
							className: "rounded-xl border border-border px-6 py-3.5 text-sm font-semibold text-foreground transition-colors hover:border-primary/40 hover:bg-primary-soft hover:text-primary-deep",
							children: "Open an account"
						})]
					})
				]
			})]
		})
	});
}
var mobile_app_default = "/assets/mobile-app-RmK3IKJy.jpg";
var features = [
	{
		icon: WifiOff,
		title: "Works offline",
		body: "Your claim file travels with you"
	},
	{
		icon: Gauge,
		title: "Instant loading",
		body: "Native speed, no app store"
	},
	{
		icon: Bell,
		title: "Stage alerts",
		body: "Pinged the moment status moves"
	},
	{
		icon: ShieldCheck,
		title: "Bank-grade security",
		body: "Biometric unlock and device binding"
	}
];
function AppShowcase() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "surface-ink relative overflow-hidden py-16 lg:py-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-grid text-ink-foreground/40 opacity-20" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto grid max-w-7xl items-center gap-14 px-4 sm:px-6 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				direction: "left",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "inline-flex items-center gap-2 rounded-full border border-ink-foreground/20 bg-ink-foreground/5 px-3 py-1 text-[0.68rem] font-semibold uppercase tracking-[0.2em] text-ink-foreground/75",
						children: "Get our mobile app"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 text-3xl font-extrabold leading-tight text-ink-foreground sm:text-4xl",
						children: "Your claim, your balance, your evidence — in one pocket."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-base leading-relaxed text-ink-foreground/70",
						children: "Restitute is a progressive web app: install it straight from the browser, get native performance, and keep working on your claim even when the signal drops."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-9 grid gap-4 sm:grid-cols-2",
						children: features.map((feature, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: index * 80,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3 rounded-2xl border border-ink-foreground/12 bg-ink-foreground/[0.06] p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex h-9 w-9 items-center justify-center rounded-xl bg-action/15 text-action",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(feature.icon, { className: "h-4.5 w-4.5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold text-ink-foreground",
									children: feature.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 text-xs text-ink-foreground/60",
									children: feature.body
								})] })]
							})
						}, feature.title))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/app",
							className: "shine rounded-xl bg-action px-6 py-3.5 text-sm font-semibold text-action-foreground transition-transform hover:-translate-y-0.5",
							children: "Install the app"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							className: "rounded-xl border border-ink-foreground/25 px-6 py-3.5 text-sm font-semibold text-ink-foreground transition-colors hover:bg-ink-foreground/10",
							children: "Open web banking"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				direction: "right",
				delay: 140,
				className: "relative",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "float-slow relative mx-auto max-w-sm overflow-hidden rounded-[2.5rem] border border-ink-foreground/15 shadow-lift",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: mobile_app_default,
							alt: "The Restitute Banking mobile app open on a phone",
							loading: "lazy",
							width: 1200,
							height: 1200,
							className: "h-full w-full object-cover"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "float-slower absolute left-0 top-10 hidden w-56 rounded-2xl border border-white/15 bg-ink/80 p-4 backdrop-blur-xl sm:block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[0.65rem] uppercase tracking-[0.18em] text-ink-foreground/55",
								children: "Available balance"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xl font-extrabold text-ink-foreground",
								children: "$12,847.50"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[0.65rem] text-ink-foreground/50",
								children: "•••• 1234"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "float-slow absolute bottom-8 right-0 hidden w-52 rounded-2xl border border-white/15 bg-ink/80 p-4 backdrop-blur-xl sm:block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[0.65rem] uppercase tracking-[0.18em] text-ink-foreground/55",
								children: "Claim update"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm font-semibold text-action",
								children: "Recovery approved"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[0.65rem] text-ink-foreground/50",
								children: "RB-104219 · 2 min ago"
							})
						]
					})
				]
			})]
		})]
	});
}
var stories = [
	{
		quote: "£4,300 vanished to a fake invoice. Restitute filed the dispute the same afternoon and I had the money back inside three weeks.",
		name: "Sarah Morris",
		role: "Verified member · Wire fraud claim",
		amount: "£4,300 recovered"
	},
	{
		quote: "As a merchant I used to lose every chargeback by default. Their evidence packs flipped that — we now win about four in five.",
		name: "John Davis",
		role: "Business banking · Chargeback defence",
		amount: "78% win rate"
	},
	{
		quote: "Someone cloned my card on holiday. The app froze it in a tap and the claim opened itself. I never sat on hold once.",
		name: "Emily Johnson",
		role: "Personal banking · Card claim",
		amount: "$1,180 recovered"
	}
];
function Stories() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "relative bg-background py-16 lg:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "Member outcomes",
				title: "Hear from people who got their money back",
				intro: "Every quote below comes from a member whose claim reached the funds-returned stage."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-14 grid gap-6 md:grid-cols-3",
				children: stories.map((story, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: index * 110,
					direction: "scale",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
						className: "lift relative flex h-full flex-col rounded-3xl border border-border bg-card p-7 shadow-soft",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quote, { className: "h-7 w-7 text-primary/25" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
								className: "mt-4 flex-1 text-sm leading-relaxed text-foreground/85",
								children: [
									"“",
									story.quote,
									"”"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-6 flex gap-1 text-warn",
								children: Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-3.5 w-3.5 fill-current" }, i))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
								className: "mt-4 border-t border-border pt-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-bold text-foreground",
										children: story.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-0.5 text-xs text-muted-foreground",
										children: story.role
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 inline-flex rounded-full bg-action-soft px-2.5 py-1 text-[0.65rem] font-bold uppercase tracking-[0.12em] text-action",
										children: story.amount
									})
								]
							})
						]
					})
				}, story.name))
			})]
		})
	});
}
function ContactStrip({ settings }) {
	const items = [
		{
			icon: Clock,
			title: "Recovery desk hours",
			lines: [
				"Mon–Fri: 8AM–8PM",
				"Sat: 9AM–1PM",
				"Sun: Closed"
			]
		},
		{
			icon: PhoneCall,
			title: "Phone support",
			lines: [
				"Available 24/7",
				settings["support_phone"] ?? "1-800-RESTITUTE",
				"Intl: +1-555-0123"
			]
		},
		{
			icon: Mail,
			title: "Email support",
			lines: ["Response within 24hrs", settings["support_email"] ?? "claims@restitutebanking.com"]
		},
		{
			icon: MapPin,
			title: "Visit us",
			lines: [
				"118 Recovery Row",
				"Financial District",
				"New York, NY 10001"
			]
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-secondary py-14",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto grid max-w-7xl gap-6 px-4 sm:grid-cols-2 sm:px-6 lg:grid-cols-4",
			children: items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: index * 80,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lift h-full rounded-2xl border border-border bg-card p-6 shadow-soft",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex h-11 w-11 items-center justify-center rounded-xl bg-primary-soft text-primary-deep",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "h-5 w-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-4 text-sm font-bold text-foreground",
							children: item.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 space-y-1 text-sm text-muted-foreground",
							children: item.lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, line))
						})
					]
				})
			}, item.title))
		})
	});
}
function HomePage() {
	const settings = Route$23.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, { settings }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "relative bg-background py-16 lg:py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl items-center gap-10 px-4 sm:px-6 lg:grid-cols-[1fr_1.05fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					align: "left",
					eyebrow: "Already filed?",
					title: "Check exactly where your money is.",
					intro: "No login needed. Your reference code and the email on the claim are enough to see the live stage, the amount recovered so far and every note we have published."
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					direction: "right",
					delay: 120,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClaimLookup, {})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RateBoard, { settings }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Recovery, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Services, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Promise$1, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShowcase, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stories, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactStrip, { settings })
	] });
}
//#endregion
export { HomePage as component };
