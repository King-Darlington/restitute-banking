import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as supabase } from "./client-C6aK345z.mjs";
import { t as useAuth } from "./useAuth-Doc0DxK3.mjs";
import { M as LogOut, P as LoaderCircle, mt as ArrowRight } from "../_libs/lucide-react.mjs";
import { t as SiteShell } from "./SiteShell-D04mdz6U.mjs";
import { a as statusMeta } from "./claims-B4EsFPLl.mjs";
import { n as money } from "./format--W0ZbsWV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-CDbw_0fe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DashboardPage() {
	const { user, loading } = useAuth();
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		if (!loading && !user) navigate({ to: "/login" });
	}, [
		loading,
		user,
		navigate
	]);
	const { data } = useQuery({
		queryKey: [
			"member",
			"claims",
			user?.email
		],
		enabled: Boolean(user?.email),
		queryFn: async () => {
			const { data: claims } = await supabase.from("claims").select("*").eq("claimant_email", user.email.toLowerCase()).order("created_at", { ascending: false });
			return claims ?? [];
		}
	});
	if (loading || !user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-[60vh] items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-6 w-6 animate-spin text-primary" })
	}) });
	const claims = data ?? [];
	const recovered = claims.reduce((sum, c) => sum + Number(c.recovered_amount ?? 0), 0);
	const inPlay = claims.filter((c) => !["disbursed", "declined"].includes(c.status)).reduce((sum, c) => sum + Number(c.amount ?? 0), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "surface-ink relative overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-grid text-ink-foreground/40 opacity-20" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto max-w-6xl px-4 py-12 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.2em] text-ink-foreground/50",
						children: "Recovery dashboard"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 truncate text-3xl font-extrabold text-ink-foreground",
						children: user.email
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => supabase.auth.signOut().then(() => navigate({ to: "/" })),
					className: "inline-flex shrink-0 items-center gap-2 rounded-xl border border-ink-foreground/25 px-4 py-2 text-sm font-semibold text-ink-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4" }), " Sign out"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
				className: "mt-8 grid gap-4 sm:grid-cols-3",
				children: [
					{
						label: "Claims filed",
						value: claims.length.toLocaleString("en-US")
					},
					{
						label: "Recovered for you",
						value: money(recovered)
					},
					{
						label: "Currently in play",
						value: money(inPlay)
					}
				].map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-ink-foreground/15 bg-ink-foreground/5 p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-[0.65rem] uppercase tracking-[0.16em] text-ink-foreground/50",
						children: stat.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-2 text-2xl font-extrabold text-ink-foreground",
						children: stat.value
					})]
				}, stat.label))
			})]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-background py-12",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "truncate text-xl font-bold text-foreground",
					children: "Your claims"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/claims/new",
					className: "shine inline-flex shrink-0 items-center gap-2 rounded-xl bg-action px-4 py-2.5 text-sm font-semibold text-action-foreground",
					children: ["File a new claim ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 space-y-3",
				children: [claims.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-2xl border border-border bg-card p-6 text-sm text-muted-foreground",
					children: "No claims yet. File one and it will appear here with live tracking."
				}) : null, claims.map((claim) => {
					const meta = statusMeta[claim.status];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-2xl border border-border bg-card p-5 shadow-soft",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-mono text-xs text-primary-deep",
											children: claim.reference
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 truncate text-lg font-bold text-foreground",
											children: money(Number(claim.amount), claim.currency)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-sm text-muted-foreground",
											children: meta.blurb
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `shrink-0 rounded-full border px-3 py-1 text-[0.65rem] font-semibold ${meta.tone}`,
									children: meta.label
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 h-1.5 overflow-hidden rounded-full bg-secondary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-action transition-all duration-700",
									style: { width: `${meta.step / 6 * 100}%` }
								})
							}),
							Number(claim.recovered_amount) > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-xs font-semibold text-action",
								children: [money(Number(claim.recovered_amount), claim.currency), " recovered so far"]
							}) : null
						]
					}, claim.id);
				})]
			})]
		})
	})] });
}
//#endregion
export { DashboardPage as component };
