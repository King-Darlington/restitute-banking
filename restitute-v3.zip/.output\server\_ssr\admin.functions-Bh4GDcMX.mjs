import { r as createServerFn } from "./server-BLyHOJXt.mjs";
import { t as createServerRpc } from "./createServerRpc-B5mxSC4N.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.functions-Bh4GDcMX.js
var seedBuiltInAdmin_createServerFn_handler = createServerRpc({
	id: "dc05c40b28178cbc350567c3e6230b26297116d267f074ebd50c28c8bf789019",
	name: "seedBuiltInAdmin",
	filename: "src/lib/admin.functions.ts"
}, (opts) => seedBuiltInAdmin.__executeServer(opts));
var seedBuiltInAdmin = createServerFn({ method: "POST" }).handler(seedBuiltInAdmin_createServerFn_handler, async () => {
	const { ensureBuiltInAdmin } = await import("./admin.server-DzW-acye.mjs");
	return ensureBuiltInAdmin();
});
var checkBuiltInAdmin_createServerFn_handler = createServerRpc({
	id: "4b5157e99b9dee35de1101f03188daa3465c981f242a18d2cf4445a443f89c0d",
	name: "checkBuiltInAdmin",
	filename: "src/lib/admin.functions.ts"
}, (opts) => checkBuiltInAdmin.__executeServer(opts));
var checkBuiltInAdmin = createServerFn({ method: "POST" }).handler(checkBuiltInAdmin_createServerFn_handler, async () => {
	const { adminAccountExists } = await import("./admin.server-DzW-acye.mjs");
	return { exists: await adminAccountExists() };
});
//#endregion
export { checkBuiltInAdmin_createServerFn_handler, seedBuiltInAdmin_createServerFn_handler };
