import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useTheme, o as PageLoader } from "./router-R_2ReNa2.mjs";
import { P as LoaderCircle, c as SunMoon, d as Sparkles } from "../_libs/lucide-react.mjs";
import { t as team_office_default } from "./team-office-DtTFGU89.mjs";
import { n as authInput, r as authLabel } from "./AuthCard-BKtXiDZ8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/register-jp9SwNfO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RegisterPage() {
	const [form, setForm] = (0, import_react.useState)({
		first_name: "",
		last_name: "",
		email: "",
		phone: "",
		password: "",
		confirm_password: ""
	});
	const navigate = useNavigate();
	const { dark, toggleTheme } = useTheme();
	const [step, setStep] = (0, import_react.useState)(1);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [stepLoading, setStepLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [acceptedTerms, setAcceptedTerms] = (0, import_react.useState)(false);
	const set = (key, value) => setForm((prev) => ({
		...prev,
		[key]: value
	}));
	const stepLabels = [
		"Account details",
		"Secure verification",
		"Review & submit"
	];
	function validateStep() {
		if (step === 1) {
			if (!form.first_name.trim() || !form.last_name.trim() || !form.email.trim()) {
				setError("Please fill in your name and email to continue.");
				return false;
			}
			return true;
		}
		if (step === 2) {
			if (!form.phone.trim() || form.password.length < 8 || form.password !== form.confirm_password) {
				if (!form.phone.trim()) setError("A phone number is required for secure verification.");
				else if (form.password.length < 8) setError("Password must be at least 8 characters.");
				else setError("Passwords do not match.");
				return false;
			}
			return true;
		}
		if (step === 3) {
			if (!acceptedTerms) {
				setError("You must agree to the terms and privacy policy before continuing.");
				return false;
			}
			return true;
		}
		return true;
	}
	async function onSubmit(event) {
		event.preventDefault();
		setError(null);
		if (step < 3) {
			if (!validateStep()) return;
			setStepLoading(true);
			window.setTimeout(() => {
				setStep((currentStep) => currentStep + 1);
				setStepLoading(false);
			}, 260);
			return;
		}
		setLoading(true);
		try {
			navigate({ to: "/dashboard" });
			return;
		} finally {
			setLoading(false);
		}
	}
	function back() {
		setError(null);
		setStep(step - 1);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-screen bg-background text-foreground",
		children: [
			stepLoading || loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageLoader, { durationMs: loading ? 1e4 : 800 }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: toggleTheme,
				className: "fixed right-4 top-4 z-30 inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-border bg-background/90 text-foreground shadow-lg shadow-black/5 backdrop-blur-md transition hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-primary/40 dark:bg-slate-950/90 dark:border-slate-700",
				"aria-label": "Toggle dark mode",
				children: dark ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SunMoon, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-5 w-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex min-h-screen flex-col lg:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "relative hidden w-full overflow-hidden px-6 py-10 text-white lg:flex lg:w-1/2 lg:flex-col",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: team_office_default,
							alt: "Team working",
							"aria-hidden": true,
							className: "absolute inset-0 h-full w-full object-cover object-center"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-ink/88 via-ink/84 to-ink/92 opacity-92" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(255,255,255,0.12),transparent_18%),radial-gradient(circle_at_80%_25%,rgba(255,255,255,0.06),transparent_18%)] opacity-70" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-10 top-16 h-64 w-64 rounded-full bg-white/10 blur-3xl" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute right-12 top-28 h-44 w-44 rounded-full bg-white/5 blur-2xl" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-24 bottom-16 h-52 w-52 rounded-full bg-white/10 blur-3xl" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative z-10 flex grow flex-col justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm uppercase tracking-[0.28em] text-white/70",
									children: "Restitute Banking"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "mt-6 max-w-lg text-3xl font-extrabold leading-tight text-white sm:text-4xl lg:mt-8 lg:text-5xl",
									children: "Secure onboarding with recovery-grade protection."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 max-w-xl text-sm leading-relaxed text-white/75 sm:mt-6 lg:text-base",
									children: "We verify your identity, lock your account with a strong password, and send a secure confirmation link so you can manage claims with confidence."
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 grid gap-3 sm:mt-8 sm:grid-cols-3 lg:space-y-4 lg:grid-cols-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-[1.2rem] border border-white/20 bg-white/10 p-4 backdrop-blur-xl",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-sm font-semibold text-white",
											children: "Step 1"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-xs text-white/75",
											children: "Create your account with a verified email."
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-[1.2rem] border border-white/20 bg-white/10 p-4 backdrop-blur-xl",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-sm font-semibold text-white",
											children: "Step 2"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-xs text-white/75",
											children: "Add phone verification and a strong password."
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-[1.2rem] border border-white/20 bg-white/10 p-4 backdrop-blur-xl",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-sm font-semibold text-white",
											children: "Step 3"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-xs text-white/75",
											children: "Review and activate access for live claim tracking."
										})]
									})
								]
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex w-full items-center justify-center px-4 py-12 sm:px-6 lg:w-1/2 lg:px-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-full max-w-md rounded-[2rem] border border-gray-200/50 bg-white/90 p-8 shadow-2xl shadow-slate-900/10 backdrop-blur-xl dark:border-slate-700/50 dark:bg-slate-950/90",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-8",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold uppercase tracking-[0.24em] text-muted-foreground",
										children: "Secure account setup"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-3 text-3xl font-extrabold text-foreground",
										children: "Register in three secure steps"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm leading-relaxed text-muted-foreground",
										children: "Build a secure Restitute account for recovery tracking, dispute management and card protection."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex w-full justify-center gap-2 rounded-3xl bg-background px-3 py-2 shadow-sm md:hidden overflow-hidden",
										children: stepLabels.map((_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `inline-flex h-8 w-8 flex-none items-center justify-center rounded-full text-xs font-semibold ${step === index + 1 ? "bg-primary text-primary-foreground" : "border border-border bg-background text-muted-foreground"}`,
											children: index + 1
										}, index))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-0 hidden rounded-3xl border border-border bg-background p-4 md:block",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex items-center justify-between gap-4",
											children: stepLabels.map((label, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex-1 text-center",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: `mb-2 inline-flex h-10 w-10 items-center justify-center rounded-full mx-auto text-sm font-semibold ${step === index + 1 ? "bg-primary text-primary-foreground" : "border border-border bg-background text-muted-foreground"}`,
													children: index + 1
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
													children: label
												})]
											}, label))
										})
									}),
									stepLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-4 rounded-3xl border border-border bg-background/80 p-4 text-sm text-muted-foreground backdrop-blur",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Loading next step…" })]
										})
									}) : null
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit,
								noValidate: true,
								className: "space-y-4",
								children: [
									step === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "block",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: authLabel,
												children: ["First name ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-destructive ml-1",
													children: "*"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												className: `${authInput} mt-2`,
												value: form.first_name,
												onChange: (e) => set("first_name", e.target.value),
												required: true
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "block",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: authLabel,
												children: ["Last name ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-destructive ml-1",
													children: "*"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												className: `${authInput} mt-2`,
												value: form.last_name,
												onChange: (e) => set("last_name", e.target.value),
												required: true
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "block",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: authLabel,
												children: ["Email ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-destructive ml-1",
													children: "*"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "email",
												className: `${authInput} mt-2`,
												value: form.email,
												onChange: (e) => set("email", e.target.value),
												required: true
											})]
										})
									] }) : step === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "block",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: authLabel,
												children: ["Phone number ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-destructive ml-1",
													children: "*"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "tel",
												className: `${authInput} mt-2`,
												value: form.phone,
												onChange: (e) => set("phone", e.target.value),
												placeholder: "+1 555 123 4567",
												required: true
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "block",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: authLabel,
												children: ["Password ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-destructive ml-1",
													children: "*"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "password",
												minLength: 8,
												className: `${authInput} mt-2`,
												value: form.password,
												onChange: (e) => set("password", e.target.value),
												required: true
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "block",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: authLabel,
												children: ["Confirm password ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-destructive ml-1",
													children: "*"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "password",
												minLength: 8,
												className: `${authInput} mt-2`,
												value: form.confirm_password,
												onChange: (e) => set("confirm_password", e.target.value),
												required: true
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-3xl border border-border bg-secondary/60 p-4 text-sm text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-semibold text-foreground",
												children: "Security guidance"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
												className: "mt-3 space-y-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Use at least 8 characters" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Do not reuse passwords from other sites" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "We will send a verification link to your email" })
												]
											})]
										})
									] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-3xl border border-border bg-secondary/50 p-5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-semibold text-foreground",
												children: "Review your details"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
												className: "mt-4 grid gap-3 text-sm text-muted-foreground",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
														className: "font-medium text-foreground",
														children: "Name"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [
														form.first_name,
														" ",
														form.last_name
													] })] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
														className: "font-medium text-foreground",
														children: "Email"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: form.email })] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
														className: "font-medium text-foreground",
														children: "Phone"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: form.phone || "Not provided" })] })
												]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "flex items-start gap-3 rounded-3xl border border-border bg-background p-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "checkbox",
												checked: acceptedTerms,
												onChange: (e) => setAcceptedTerms(e.target.checked),
												className: "mt-1 h-4 w-4 rounded border-border text-primary focus:ring-primary"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-sm leading-relaxed text-muted-foreground",
												children: "I agree to the terms and privacy policy so Restitute can securely manage my account."
											})]
										})]
									}),
									error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "rounded-3xl border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive",
										children: error
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
										children: [step > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: back,
											className: "inline-flex w-full items-center justify-center rounded-3xl border border-border bg-background px-6 py-3 text-sm font-semibold text-foreground transition hover:-translate-y-0.5 sm:w-auto",
											children: "Back"
										}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "submit",
											disabled: loading,
											className: "shine inline-flex w-full items-center justify-center gap-2 rounded-3xl bg-action px-6 py-3 text-sm font-semibold text-action-foreground shadow-soft transition hover:-translate-y-0.5 disabled:opacity-60 sm:w-auto",
											children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : null, step < 3 ? "Continue" : "Create account"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-6 text-center text-sm leading-relaxed text-muted-foreground",
										children: [
											"Already registered? ",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/login",
												className: "font-semibold text-primary hover:underline",
												children: "Sign in"
											})
										]
									})
								]
							})
						]
					})
				})]
			})
		]
	});
}
//#endregion
export { RegisterPage as component };
