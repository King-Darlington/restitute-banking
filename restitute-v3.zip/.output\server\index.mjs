globalThis.__nitro_main__ = import.meta.url;
import { i as serve, r as NodeResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
import { a as defineLazyEventHandler, i as defineHandler, n as HTTPError, o as toEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-08-10T23:34:52.799Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"169-IQhEVcZgFQU8BLpisBsltg7Lwrg\"",
		"mtime": "2026-08-10T23:34:52.797Z",
		"size": 361,
		"path": "../public/favicon.svg"
	},
	"/assets/about-CEvc5lPE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1640-j77s6ybzb4PcUBItlAgjZwCp3O0\"",
		"mtime": "2026-08-12T09:40:38.742Z",
		"size": 5696,
		"path": "../public/assets/about-CEvc5lPE.js"
	},
	"/assets/admin-LJdym-AG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"107c-DgNWJYzgoSOsLkmloWvCtmzB7JI\"",
		"mtime": "2026-08-12T09:40:38.746Z",
		"size": 4220,
		"path": "../public/assets/admin-LJdym-AG.js"
	},
	"/assets/admin.claims-BTZ35Tto.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1592-VH9zGQCIgQ49BmS6Oni94puB4mU\"",
		"mtime": "2026-08-12T09:40:38.748Z",
		"size": 5522,
		"path": "../public/assets/admin.claims-BTZ35Tto.js"
	},
	"/assets/admin.index-C8AdA3_T.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c7b-YJa8booFnW/e1wJq08JkVA8j1rw\"",
		"mtime": "2026-08-12T09:40:38.750Z",
		"size": 3195,
		"path": "../public/assets/admin.index-C8AdA3_T.js"
	},
	"/assets/admin.members-BmTe4Zef.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"75a-AiccrdbH61uzwpbUKi/+OwgPHFE\"",
		"mtime": "2026-08-12T09:40:38.755Z",
		"size": 1882,
		"path": "../public/assets/admin.members-BmTe4Zef.js"
	},
	"/assets/admin.settings-BwUmLUZd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"580-Lbt4++wzkysfm6v98SUFmh9V36Q\"",
		"mtime": "2026-08-12T09:40:38.757Z",
		"size": 1408,
		"path": "../public/assets/admin.settings-BwUmLUZd.js"
	},
	"/assets/AdminShell-DuxBSX8F.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13c5-+ZsGynxYlQCzvKt3Z5TE6ZDlk2s\"",
		"mtime": "2026-08-12T09:40:38.668Z",
		"size": 5061,
		"path": "../public/assets/AdminShell-DuxBSX8F.js"
	},
	"/assets/app-1tpzRcbt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1584-s2fZF235YbDi/ADciVB76UePly8\"",
		"mtime": "2026-08-12T09:40:38.759Z",
		"size": 5508,
		"path": "../public/assets/app-1tpzRcbt.js"
	},
	"/assets/arrow-right-xUn83Vfs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-tpb8w0XEYuDryjJCdg3desGlqzg\"",
		"mtime": "2026-08-12T09:40:38.765Z",
		"size": 165,
		"path": "../public/assets/arrow-right-xUn83Vfs.js"
	},
	"/assets/AuthCard-BIwfwLy6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9d2-X7IeIG8/QDWNxKwc1quM+/0sis4\"",
		"mtime": "2026-08-12T09:40:38.668Z",
		"size": 2514,
		"path": "../public/assets/AuthCard-BIwfwLy6.js"
	},
	"/assets/bell-Bd7wWMvv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"122-3mq5yWrOe6QHp18q0t9EgeRS3yI\"",
		"mtime": "2026-08-12T09:40:38.765Z",
		"size": 290,
		"path": "../public/assets/bell-Bd7wWMvv.js"
	},
	"/assets/blocks-Cj5_MwKD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13f0-Hc8j9kLheJ2kemcS2aJlrJj+kDU\"",
		"mtime": "2026-08-12T09:40:38.767Z",
		"size": 5104,
		"path": "../public/assets/blocks-Cj5_MwKD.js"
	},
	"/assets/Brand-BgLcF2_Y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"436-IZ6fwTgoWu65dFdPAvWlzXSAvl8\"",
		"mtime": "2026-08-12T09:40:38.670Z",
		"size": 1078,
		"path": "../public/assets/Brand-BgLcF2_Y.js"
	},
	"/assets/business-banking-DAb9Dp-z.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1904-wtKRM/5Mkf+2OLbWDfedXRRsTG8\"",
		"mtime": "2026-08-12T09:40:38.767Z",
		"size": 6404,
		"path": "../public/assets/business-banking-DAb9Dp-z.js"
	},
	"/assets/business-banking-Doc7A7D8.jpg": {
		"type": "image/jpeg",
		"etag": "\"600e-xS0JVZTzXFLA8h1mS/cise2eZSc\"",
		"mtime": "2026-08-12T09:40:39.820Z",
		"size": 24590,
		"path": "../public/assets/business-banking-Doc7A7D8.jpg"
	},
	"/assets/cards-DImocxg3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19dd-034aVZQJVF65Ssv/icjAdhjzbyg\"",
		"mtime": "2026-08-12T09:40:38.767Z",
		"size": 6621,
		"path": "../public/assets/cards-DImocxg3.js"
	},
	"/assets/check-jj-1xQqf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c-DY8qMKwQVHHjPdEiJ4xziakyglo\"",
		"mtime": "2026-08-12T09:40:38.777Z",
		"size": 124,
		"path": "../public/assets/check-jj-1xQqf.js"
	},
	"/assets/card-payment-CL4PRqNa.jpg": {
		"type": "image/jpeg",
		"etag": "\"8422-nmr1f1DvL+6w7jsJUTGm7UBJKO8\"",
		"mtime": "2026-08-12T09:40:39.830Z",
		"size": 33826,
		"path": "../public/assets/card-payment-CL4PRqNa.jpg"
	},
	"/assets/ClaimLookup-XmOi4OJ8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1359-pbh9bXp3dZ03mGpl1rHNHKkZ/Ks\"",
		"mtime": "2026-08-12T09:40:38.685Z",
		"size": 4953,
		"path": "../public/assets/ClaimLookup-XmOi4OJ8.js"
	},
	"/assets/claims-7V0aedky.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"aaf-7kMMW7OO4lojm1QmX31yfR+gCrE\"",
		"mtime": "2026-08-12T09:40:38.779Z",
		"size": 2735,
		"path": "../public/assets/claims-7V0aedky.js"
	},
	"/assets/claims.new-C8vHnTra.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24ec-ZUyYGGWQHdvRFfTa03CqaZrP3uE\"",
		"mtime": "2026-08-12T09:40:38.779Z",
		"size": 9452,
		"path": "../public/assets/claims.new-C8vHnTra.js"
	},
	"/assets/clock-3-tkYi195m.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a9-nMr+ukr0IWXHs8NBErf9iObSkHM\"",
		"mtime": "2026-08-12T09:40:38.806Z",
		"size": 169,
		"path": "../public/assets/clock-3-tkYi195m.js"
	},
	"/assets/claims.track-WK8Dngrk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8f0-6vvJ7+jhJCfHLv9JrELuCyURPdQ\"",
		"mtime": "2026-08-12T09:40:38.783Z",
		"size": 2288,
		"path": "../public/assets/claims.track-WK8Dngrk.js"
	},
	"/assets/contact-D7eN_E_u.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"876-TlRrTZr6gqVZtWbwwBzGWxjPwEA\"",
		"mtime": "2026-08-12T09:40:38.806Z",
		"size": 2166,
		"path": "../public/assets/contact-D7eN_E_u.js"
	},
	"/assets/createLucideIcon-DkWbMhVc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4a8-qvom5vBJxQHl7v8ScHf0f8RnTw0\"",
		"mtime": "2026-08-12T09:40:38.808Z",
		"size": 1192,
		"path": "../public/assets/createLucideIcon-DkWbMhVc.js"
	},
	"/assets/createServerFn-cfNI5Xxw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9678-0s/kW85NcdNi3Tgf1/MnsOtAnTo\"",
		"mtime": "2026-08-12T09:40:38.815Z",
		"size": 38520,
		"path": "../public/assets/createServerFn-cfNI5Xxw.js"
	},
	"/assets/community-grant-B3MYxf-7.jpg": {
		"type": "image/jpeg",
		"etag": "\"3129-ut+dLhbSKDFs76q7AKglis1hjbo\"",
		"mtime": "2026-08-12T09:40:39.859Z",
		"size": 12585,
		"path": "../public/assets/community-grant-B3MYxf-7.jpg"
	},
	"/assets/credit-card-dvUeqdRd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cf-UZ6wK8V656laTdaVFWA0NBj9hRM\"",
		"mtime": "2026-08-12T09:40:38.847Z",
		"size": 207,
		"path": "../public/assets/credit-card-dvUeqdRd.js"
	},
	"/assets/dashboard-H0jCPXuu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1212-bMti9syG/hodvyZQKSX4RSlK8ss\"",
		"mtime": "2026-08-12T09:40:38.847Z",
		"size": 4626,
		"path": "../public/assets/dashboard-H0jCPXuu.js"
	},
	"/assets/forgot-password-B1qaXp5v.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6dc-T4rjUAsXBkV7ZbHsv6tw2KrfPME\"",
		"mtime": "2026-08-12T09:40:38.855Z",
		"size": 1756,
		"path": "../public/assets/forgot-password-B1qaXp5v.js"
	},
	"/assets/customer-support-BRGBlAD6.jpg": {
		"type": "image/jpeg",
		"etag": "\"68e4-z5hZzd+Z0nUWo/WnC8GCVI+cMcQ\"",
		"mtime": "2026-08-12T09:40:39.861Z",
		"size": 26852,
		"path": "../public/assets/customer-support-BRGBlAD6.jpg"
	},
	"/assets/format-B6qeKsoW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2b5-9juxaDCtVIsdaJO41D8sKreEblo\"",
		"mtime": "2026-08-12T09:40:38.864Z",
		"size": 693,
		"path": "../public/assets/format-B6qeKsoW.js"
	},
	"/assets/gavel-DcBTAS09.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13c-2Qy5W6Fs6K1bgijn/YqCQgJtD0I\"",
		"mtime": "2026-08-12T09:40:38.864Z",
		"size": 316,
		"path": "../public/assets/gavel-DcBTAS09.js"
	},
	"/assets/grants-B0ooabgh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"188c-CEHfKYPg8Ad15tt5lzrqdVp7Idk\"",
		"mtime": "2026-08-12T09:40:38.864Z",
		"size": 6284,
		"path": "../public/assets/grants-B0ooabgh.js"
	},
	"/assets/hand-coins-BKB5jhnV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19f-r5+ugSzPyEAeCKzT/nx2LlSUeQk\"",
		"mtime": "2026-08-12T09:40:39.260Z",
		"size": 415,
		"path": "../public/assets/hand-coins-BKB5jhnV.js"
	},
	"/assets/house-CnSKq-v7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"119-c4SYGsefa+fQT55nd0prIzHscIo\"",
		"mtime": "2026-08-12T09:40:39.262Z",
		"size": 281,
		"path": "../public/assets/house-CnSKq-v7.js"
	},
	"/assets/how-it-works-BaP2OAuB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"185b-IWg7SnoszeGop6pxWYqxdg4FFKQ\"",
		"mtime": "2026-08-12T09:40:39.264Z",
		"size": 6235,
		"path": "../public/assets/how-it-works-BaP2OAuB.js"
	},
	"/assets/life-buoy-CnHXK-3z.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17d-7RHRo8zPSO1o4s9k/fDbH3e07ks\"",
		"mtime": "2026-08-12T09:40:39.266Z",
		"size": 381,
		"path": "../public/assets/life-buoy-CnHXK-3z.js"
	},
	"/assets/link-XeYqOrFb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e6c-DyBpwlMUGVVOQSgWqBKY5p2lRWk\"",
		"mtime": "2026-08-12T09:40:39.267Z",
		"size": 7788,
		"path": "../public/assets/link-XeYqOrFb.js"
	},
	"/assets/data-privacy--x5ijWny.jpg": {
		"type": "image/jpeg",
		"etag": "\"6364-A78p0to1dqLYzivBzCOMqwxpCZk\"",
		"mtime": "2026-08-12T09:40:39.861Z",
		"size": 25444,
		"path": "../public/assets/data-privacy--x5ijWny.jpg"
	},
	"/assets/loader-circle-Bek7o8H0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"90-DyT4mhcwllWNtdprSLqpfpN7X2Q\"",
		"mtime": "2026-08-12T09:40:39.310Z",
		"size": 144,
		"path": "../public/assets/loader-circle-Bek7o8H0.js"
	},
	"/assets/loans-cEJ03XTX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18b5-PtUy/+ve6NfTOB6q5S8UaL86xi8\"",
		"mtime": "2026-08-12T09:40:39.349Z",
		"size": 6325,
		"path": "../public/assets/loans-cEJ03XTX.js"
	},
	"/assets/hero-recovery-C1nrZNmz.jpg": {
		"type": "image/jpeg",
		"etag": "\"22497-E0mPAw9t8/Ylslb6AZnSFmfZexA\"",
		"mtime": "2026-08-12T09:40:39.865Z",
		"size": 140439,
		"path": "../public/assets/hero-recovery-C1nrZNmz.jpg"
	},
	"/assets/lock-Bk53cM7B.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ce-P4SCTVykBrY/9SXhO41sIAPeJSU\"",
		"mtime": "2026-08-12T09:40:39.349Z",
		"size": 206,
		"path": "../public/assets/lock-Bk53cM7B.js"
	},
	"/assets/index-P8QXxMCQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"86045-Q794ZjQ5yUvxq096nfdrzDRLNjI\"",
		"mtime": "2026-08-12T09:40:38.668Z",
		"size": 548933,
		"path": "../public/assets/index-P8QXxMCQ.js"
	},
	"/assets/log-out-2cBCrz1s.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2331-bNSKskRKZV4ohaBWEj/fbarAcIg\"",
		"mtime": "2026-08-12T09:40:39.397Z",
		"size": 9009,
		"path": "../public/assets/log-out-2cBCrz1s.js"
	},
	"/assets/login-uxv1Qh3A.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a89-jBZr50nsQ37qRCBn1I4H+JUaJyQ\"",
		"mtime": "2026-08-12T09:40:39.399Z",
		"size": 6793,
		"path": "../public/assets/login-uxv1Qh3A.js"
	},
	"/assets/financial-recovery-BKu6k0Lz.jpg": {
		"type": "image/jpeg",
		"etag": "\"6677-zyz95CxtT9kjv+ObCdYBbXYtqqc\"",
		"mtime": "2026-08-12T09:40:39.863Z",
		"size": 26231,
		"path": "../public/assets/financial-recovery-BKu6k0Lz.jpg"
	},
	"/assets/matchContext-BRN1Rnka.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8b-bGUpzGXSqvjmPwpJuCN0euLUXeg\"",
		"mtime": "2026-08-12T09:40:39.410Z",
		"size": 139,
		"path": "../public/assets/matchContext-BRN1Rnka.js"
	},
	"/assets/PageHero-Chl8O1C7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"99c-uNRi8H2M+gZRHCwp7JD71EQ0XR0\"",
		"mtime": "2026-08-12T09:40:38.726Z",
		"size": 2460,
		"path": "../public/assets/PageHero-Chl8O1C7.js"
	},
	"/assets/personal-banking-CZ0Wwpo7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1917-rD0etKn3jhpwp2T7GHigxFo5ma8\"",
		"mtime": "2026-08-12T09:40:39.447Z",
		"size": 6423,
		"path": "../public/assets/personal-banking-CZ0Wwpo7.js"
	},
	"/assets/piggy-bank-BfIz-O6f.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"199-gFecj6ybXOItGxpLZsbn4Qyi+CI\"",
		"mtime": "2026-08-12T09:40:39.472Z",
		"size": 409,
		"path": "../public/assets/piggy-bank-BfIz-O6f.js"
	},
	"/assets/privacy-DdD6DNMs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"711-CAnD3iYT5IKqAMHmaR7YfCJphg4\"",
		"mtime": "2026-08-12T09:40:39.479Z",
		"size": 1809,
		"path": "../public/assets/privacy-DdD6DNMs.js"
	},
	"/assets/mobile-banking-BUzDrwXn.jpg": {
		"type": "image/jpeg",
		"etag": "\"5783-89ObR7IYGbvUg3prafl+0VmiLHI\"",
		"mtime": "2026-08-12T09:40:39.869Z",
		"size": 22403,
		"path": "../public/assets/mobile-banking-BUzDrwXn.jpg"
	},
	"/assets/register-Bf7f1RDB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2e57-21sqmoH0UI8HMN5oPxWABtWZQuw\"",
		"mtime": "2026-08-12T09:40:39.508Z",
		"size": 11863,
		"path": "../public/assets/register-Bf7f1RDB.js"
	},
	"/assets/reset-password-Mr41Dlc8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"682-YBYHVw2qf8uA1nr+2aO0LQjfDBo\"",
		"mtime": "2026-08-12T09:40:39.510Z",
		"size": 1666,
		"path": "../public/assets/reset-password-Mr41Dlc8.js"
	},
	"/assets/Reveal-CsE1F7EZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"368-L9x57gi10SVbnINso4AAEP4zqbM\"",
		"mtime": "2026-08-12T09:40:38.730Z",
		"size": 872,
		"path": "../public/assets/Reveal-CsE1F7EZ.js"
	},
	"/assets/routes-BzYvAYi4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"714f-TFoe1wxxQ8A+KAkdtIEVZbO2rQQ\"",
		"mtime": "2026-08-12T09:40:39.519Z",
		"size": 29007,
		"path": "../public/assets/routes-BzYvAYi4.js"
	},
	"/assets/scale-Chnt1ket.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14c-gB851fR2lB9TmAO8iwooZqvRsho\"",
		"mtime": "2026-08-12T09:40:39.549Z",
		"size": 332,
		"path": "../public/assets/scale-Chnt1ket.js"
	},
	"/assets/search-DXYgOeO2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-Sr/gde2QCPalxjcltYRhKBbNb7A\"",
		"mtime": "2026-08-12T09:40:39.549Z",
		"size": 174,
		"path": "../public/assets/search-DXYgOeO2.js"
	},
	"/assets/SectionHeading-fmoyDt_U.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3f0-NoYImw5a0QqZ/0cK5o1pKZcDmPQ\"",
		"mtime": "2026-08-12T09:40:38.732Z",
		"size": 1008,
		"path": "../public/assets/SectionHeading-fmoyDt_U.js"
	},
	"/assets/map-pin-C8l1jbxq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a3-90BjSBYuHJZKFffv0YiFmDbpEn4\"",
		"mtime": "2026-08-12T09:40:39.408Z",
		"size": 419,
		"path": "../public/assets/map-pin-C8l1jbxq.js"
	},
	"/assets/secure-banking-C-fJMjdg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3b-xvDGs4NdhjTnImuP+o/pCcsz8JM\"",
		"mtime": "2026-08-12T09:40:39.549Z",
		"size": 59,
		"path": "../public/assets/secure-banking-C-fJMjdg.js"
	},
	"/assets/secure-digital-DqBI9dpa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"152-RQChzvAdNjB0RHkBoT4lTBhQaNI\"",
		"mtime": "2026-08-12T09:40:39.557Z",
		"size": 338,
		"path": "../public/assets/secure-digital-DqBI9dpa.js"
	},
	"/assets/refund-dispute-DqmKKRpA.png": {
		"type": "image/png",
		"etag": "\"4f82-xOl//vOClaO1E6anOfINR54ZmUw\"",
		"mtime": "2026-08-12T09:40:39.874Z",
		"size": 20354,
		"path": "../public/assets/refund-dispute-DqmKKRpA.png"
	},
	"/assets/secure-banking-Al-U6jUg.jpg": {
		"type": "image/jpeg",
		"etag": "\"6dec-zanx7sSo6QkVhLxIkuwF0UjYBSs\"",
		"mtime": "2026-08-12T09:40:39.876Z",
		"size": 28140,
		"path": "../public/assets/secure-banking-Al-U6jUg.jpg"
	},
	"/assets/mobile-app-RmK3IKJy.jpg": {
		"type": "image/jpeg",
		"etag": "\"18924-v8/Khg8KMjM+FfF/QTKADtZZ4C4\"",
		"mtime": "2026-08-12T09:40:39.867Z",
		"size": 100644,
		"path": "../public/assets/mobile-app-RmK3IKJy.jpg"
	},
	"/assets/secure-digital-KTjhxEjx.jpg": {
		"type": "image/jpeg",
		"etag": "\"6bd0-9gG692Q1DUUmOnHSy2GcXIDusK0\"",
		"mtime": "2026-08-12T09:40:39.878Z",
		"size": 27600,
		"path": "../public/assets/secure-digital-KTjhxEjx.jpg"
	},
	"/assets/send-CtOtihK0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"122-04SfSJ63lrd8uezk0sq4pj/dEJw\"",
		"mtime": "2026-08-12T09:40:39.609Z",
		"size": 290,
		"path": "../public/assets/send-CtOtihK0.js"
	},
	"/assets/shield-check-CKqJmURg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"140-9XGYw/DS/W3BebbYmHWTL3YGUGM\"",
		"mtime": "2026-08-12T09:40:39.609Z",
		"size": 320,
		"path": "../public/assets/shield-check-CKqJmURg.js"
	},
	"/assets/SiteShell-DIy__-3_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"338d-9OD8x02h2qvb/ZH4k1eWvGxoAkg\"",
		"mtime": "2026-08-12T09:40:38.735Z",
		"size": 13197,
		"path": "../public/assets/SiteShell-DIy__-3_.js"
	},
	"/assets/styles-DB4o_B8W.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1e412-7q5vHKeAzLIy9v+9o/Co3nm2XSA\"",
		"mtime": "2026-08-12T09:40:39.880Z",
		"size": 123922,
		"path": "../public/assets/styles-DB4o_B8W.css"
	},
	"/assets/sun-moon-BM1JZlXF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"340-4MztkIwRrUjSpzN1WEju7AVrbJU\"",
		"mtime": "2026-08-12T09:40:39.609Z",
		"size": 832,
		"path": "../public/assets/sun-moon-BM1JZlXF.js"
	},
	"/assets/team-office-BqXICvdz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"38-KZdCPZBMZ73f4Whj0E5t+17ohgc\"",
		"mtime": "2026-08-12T09:40:39.617Z",
		"size": 56,
		"path": "../public/assets/team-office-BqXICvdz.js"
	},
	"/assets/team-office-DvTFFPbt.jpg": {
		"type": "image/jpeg",
		"etag": "\"2558d-gdRpTUerPIVBbdsFLptzrqosBW8\"",
		"mtime": "2026-08-12T09:40:39.882Z",
		"size": 152973,
		"path": "../public/assets/team-office-DvTFFPbt.jpg"
	},
	"/assets/terms-CWXBfa70.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6ed-YHl3lWxt+9YZo8JX1NN3PTOKAEA\"",
		"mtime": "2026-08-12T09:40:39.681Z",
		"size": 1773,
		"path": "../public/assets/terms-CWXBfa70.js"
	},
	"/assets/useAuth-CuHPcBTx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"30c-fDoaMz0R9WCY7exFpe/1aJMc5SA\"",
		"mtime": "2026-08-12T09:40:39.683Z",
		"size": 780,
		"path": "../public/assets/useAuth-CuHPcBTx.js"
	},
	"/assets/users-P61xlGv8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132-4BkiOlweO6m0DmMebXcy2fndkwA\"",
		"mtime": "2026-08-12T09:40:39.817Z",
		"size": 306,
		"path": "../public/assets/users-P61xlGv8.js"
	},
	"/assets/useStore-B9WcefOa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6ba9-DyLG3MsOxLBofb+Ep/+VkQIRI0g\"",
		"mtime": "2026-08-12T09:40:39.693Z",
		"size": 27561,
		"path": "../public/assets/useStore-B9WcefOa.js"
	},
	"/assets/utils-Dk_44zMo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6a77-huRZku0xw3taBmoFyibw55TbbUY\"",
		"mtime": "2026-08-12T09:40:39.819Z",
		"size": 27255,
		"path": "../public/assets/utils-Dk_44zMo.js"
	},
	"/assets/x-DbG4QNMb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"122-jzZmcoKHS+OwRUXr1qE3bs9kzsY\"",
		"mtime": "2026-08-12T09:40:39.820Z",
		"size": 290,
		"path": "../public/assets/x-DbG4QNMb.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_PglbQZ = defineLazyEventHandler(() => import("./_chunks/renderer-template.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_PglbQZ
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
