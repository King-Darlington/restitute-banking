import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as supabase } from "./client-C6aK345z.mjs";
import { P as LoaderCircle, m as ShieldCheck, tt as Check } from "../_libs/lucide-react.mjs";
import { t as SiteShell } from "./SiteShell-D04mdz6U.mjs";
import { n as PageHero } from "./PageHero-BCURtH2L.mjs";
import { n as CURRENCIES, r as LOSS_TYPES } from "./claims-B4EsFPLl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/claims.new-CNWO0LHX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var refund_dispute_default = "/assets/refund-dispute-DqmKKRpA.png";
var STEPS = [
	"Your details",
	"The loss",
	"Evidence",
	"Review"
];
var initialState = {
	claimant_name: "",
	claimant_email: "",
	claimant_phone: "",
	country: "United States",
	loss_type: "unauthorized_transaction",
	amount: "",
	currency: "USD",
	incident_date: "",
	counterparty: "",
	description: "",
	consent: false
};
var inputClass = "w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-foreground outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/20";
var labelClass = "block text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground";
function NewClaimPage() {
	const [step, setStep] = (0, import_react.useState)(0);
	const [form, setForm] = (0, import_react.useState)(initialState);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [reference, setReference] = (0, import_react.useState)(null);
	const set = (key, value) => setForm((prev) => ({
		...prev,
		[key]: value
	}));
	const canContinue = () => {
		if (step === 0) return form.claimant_name.trim().length > 1 && /.+@.+\..+/.test(form.claimant_email);
		if (step === 1) return Number(form.amount) > 0;
		if (step === 2) return form.description.trim().length > 10;
		return form.consent;
	};
	async function onSubmit(event) {
		event.preventDefault();
		setLoading(true);
		setError(null);
		const { data, error: insertError } = await supabase.from("claims").insert({
			claimant_name: form.claimant_name.trim(),
			claimant_email: form.claimant_email.trim().toLowerCase(),
			claimant_phone: form.claimant_phone.trim() || null,
			country: form.country || null,
			loss_type: form.loss_type,
			amount: Number(form.amount),
			currency: form.currency,
			incident_date: form.incident_date || null,
			counterparty: form.counterparty.trim() || null,
			description: form.description.trim()
		}).select("reference").single();
		if (insertError || !data) setError("We could not file that claim just now. Please try again or call the recovery desk.");
		else setReference(data.reference);
		setLoading(false);
	}
	if (reference) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-background py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-2xl px-4 text-center sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-action-soft text-action",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-8 w-8" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-6 text-3xl font-extrabold text-foreground",
					children: "Your claim is filed"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted-foreground",
					children: [
						"Keep this reference safe — you can track your recovery with it at any time, and a specialist will contact you at ",
						form.claimant_email,
						" within one business day."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 rounded-2xl border border-border bg-card px-6 py-5 font-mono text-2xl font-bold tracking-[0.2em] text-primary-deep shadow-soft",
					children: reference
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-wrap justify-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/claims/track",
						className: "shine rounded-xl bg-action px-6 py-3.5 text-sm font-semibold text-action-foreground",
						children: "Track this claim"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/register",
						className: "rounded-xl border border-border px-6 py-3.5 text-sm font-semibold text-foreground",
						children: "Create an account"
					})]
				})
			]
		})
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		image: refund_dispute_default,
		eyebrow: "Refund claim",
		title: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "File your claim in five minutes." }),
		intro: "No account needed, no upfront fee, and nothing to pay unless we recover your money. Everything you enter is encrypted in transit and at rest.",
		breadcrumb: "File a claim"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-background py-14 lg:py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "grid grid-cols-4 gap-2",
				children: STEPS.map((label, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("h-1.5 rounded-full transition-colors duration-500", index <= step ? "bg-action" : "bg-border") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("mt-2 text-[0.65rem] font-semibold uppercase tracking-[0.12em]", index <= step ? "text-foreground" : "text-muted-foreground"),
					children: label
				})] }, label))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "mt-8 rounded-3xl border border-border bg-card p-6 shadow-soft sm:p-8",
				children: [
					step === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: labelClass,
									children: "Full name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: cn(inputClass, "mt-2"),
									value: form.claimant_name,
									onChange: (e) => set("claimant_name", e.target.value),
									placeholder: "Jordan Rivera",
									required: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: labelClass,
								children: "Email"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "email",
								className: cn(inputClass, "mt-2"),
								value: form.claimant_email,
								onChange: (e) => set("claimant_email", e.target.value),
								placeholder: "you@example.com",
								required: true
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: labelClass,
								children: "Phone (optional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: cn(inputClass, "mt-2"),
								value: form.claimant_phone,
								onChange: (e) => set("claimant_phone", e.target.value),
								placeholder: "+1 555 0100"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: labelClass,
									children: "Country"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: cn(inputClass, "mt-2"),
									value: form.country,
									onChange: (e) => set("country", e.target.value)
								})]
							})
						]
					}) : null,
					step === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: labelClass,
									children: "What happened?"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									className: cn(inputClass, "mt-2"),
									value: form.loss_type,
									onChange: (e) => set("loss_type", e.target.value),
									children: LOSS_TYPES.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: option.value,
										children: option.label
									}, option.value))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: labelClass,
								children: "Amount lost"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: "1",
								step: "0.01",
								className: cn(inputClass, "mt-2"),
								value: form.amount,
								onChange: (e) => set("amount", e.target.value),
								placeholder: "2500",
								required: true
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: labelClass,
								children: "Currency"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: cn(inputClass, "mt-2"),
								value: form.currency,
								onChange: (e) => set("currency", e.target.value),
								children: CURRENCIES.map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: code,
									children: code
								}, code))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: labelClass,
								children: "Date of incident"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "date",
								className: cn(inputClass, "mt-2"),
								value: form.incident_date,
								onChange: (e) => set("incident_date", e.target.value)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: labelClass,
								children: "Who received the money?"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: cn(inputClass, "mt-2"),
								value: form.counterparty,
								onChange: (e) => set("counterparty", e.target.value),
								placeholder: "Merchant, bank or platform"
							})] })
						]
					}) : null,
					step === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: labelClass,
						children: "Tell us the story"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						rows: 7,
						className: cn(inputClass, "mt-2 resize-y"),
						value: form.description,
						onChange: (e) => set("description", e.target.value),
						placeholder: "Dates, amounts, what you were told, and anything you have already tried.",
						required: true
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 rounded-2xl border border-border bg-secondary px-4 py-3 text-xs leading-relaxed text-muted-foreground",
						children: "Do not attach documents yet. Once your file is open, your specialist will list the exact evidence that strengthens your case — and nothing you do not need."
					})] }) : null,
					step === 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "grid gap-3 text-sm sm:grid-cols-2",
						children: [
							["Name", form.claimant_name],
							["Email", form.claimant_email],
							["Phone", form.claimant_phone || "—"],
							["Country", form.country],
							["Loss type", LOSS_TYPES.find((l) => l.value === form.loss_type)?.label ?? ""],
							["Amount", `${form.currency} ${form.amount || "0"}`],
							["Incident date", form.incident_date || "—"],
							["Counterparty", form.counterparty || "—"]
						].map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-border bg-secondary px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[0.65rem] font-semibold uppercase tracking-[0.14em] text-muted-foreground",
								children: key
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-semibold text-foreground",
								children: value
							})]
						}, key))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-6 flex items-start gap-3 text-sm text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							className: "mt-1 h-4 w-4 rounded border-border",
							checked: form.consent,
							onChange: (e) => set("consent", e.target.checked)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"I confirm the details are accurate and authorise Restitute Banking to act as my representative in recovering these funds under the",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/terms",
								className: "font-semibold text-primary underline",
								children: "terms of service"
							}),
							"."
						] })]
					})] }) : null,
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 rounded-xl border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setStep((s) => Math.max(0, s - 1)),
							disabled: step === 0,
							className: "rounded-xl border border-border px-5 py-3 text-sm font-semibold text-foreground disabled:opacity-40",
							children: "Back"
						}), step < 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => canContinue() && setStep((s) => s + 1),
							disabled: !canContinue(),
							className: "shine rounded-xl bg-action px-6 py-3 text-sm font-semibold text-action-foreground disabled:opacity-50",
							children: "Continue"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "submit",
							disabled: !canContinue() || loading,
							className: "shine inline-flex items-center gap-2 rounded-xl bg-action px-6 py-3 text-sm font-semibold text-action-foreground disabled:opacity-50",
							children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-4 w-4" }), "Submit claim"]
						})]
					})
				]
			})]
		})
	})] });
}
//#endregion
export { NewClaimPage as component };
