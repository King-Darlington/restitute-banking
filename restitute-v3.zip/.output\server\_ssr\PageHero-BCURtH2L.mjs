import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Reveal } from "./Reveal-ogx-87vx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/PageHero-BCURtH2L.js
var import_jsx_runtime = require_jsx_runtime();
function PageHero({ eyebrow, title, intro, children, breadcrumb, image }) {
	const hasImage = Boolean(image);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("relative overflow-hidden", hasImage ? "bg-primary/5" : "surface-ink"),
		children: [
			image ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0 z-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: image,
						alt: "",
						className: "w-full h-full object-cover object-center opacity-100"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-slate-950/20 via-slate-950/10 to-transparent" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-primary/15" })
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute -right-24 -top-24 h-80 w-80 rounded-full blur-3xl",
				style: {
					background: "var(--gradient-action)",
					opacity: .12
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-20 mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-24",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("inline-flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em]", hasImage ? "border-white/20 bg-white/10 text-white/80" : "border-ink-foreground/20 bg-ink-foreground/5 text-ink-foreground/75"),
						children: eyebrow
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 80,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: cn("mt-6 max-w-3xl text-4xl font-extrabold leading-[1.08] sm:text-5xl lg:text-[3.4rem]", hasImage ? "text-white" : "text-ink-foreground"),
							children: title
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 160,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("mt-5 max-w-2xl text-base leading-relaxed sm:text-lg", hasImage ? "text-white/80" : "text-ink-foreground/75"),
							children: intro
						})
					}),
					children ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: 240,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children
						})
					}) : null,
					breadcrumb ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: cn("mt-10 text-xs uppercase tracking-[0.2em]", hasImage ? "text-white/60" : "text-ink-foreground/45"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								className: cn("hover:text-current", hasImage ? "text-white" : "text-ink-foreground"),
								children: "Home"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "px-2",
								children: "/"
							}),
							breadcrumb
						]
					}) : null
				]
			})
		]
	});
}
function CtaButton({ to, children, variant = "action" }) {
	const base = "inline-flex items-center justify-center rounded-xl px-5 py-3 text-sm font-semibold transition-all duration-300";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		className: variant === "action" ? `${base} shine bg-action text-action-foreground shadow-soft hover:-translate-y-0.5` : `${base} border border-ink-foreground/25 text-ink-foreground hover:bg-ink-foreground/10`,
		children
	});
}
//#endregion
export { PageHero as n, CtaButton as t };
